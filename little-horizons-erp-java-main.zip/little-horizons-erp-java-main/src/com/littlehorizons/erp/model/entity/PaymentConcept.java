package com.littlehorizons.erp.model.entity;

/**
 * Domain entity representing a payment concept (e.g., Tuition, Monthly Fee, Uniform).
 * Maps to the MySQL table 'conceptos_pago'.
 */
public class PaymentConcept {

    private Integer idConcept;
    private String conceptCode;
    private String conceptName;
    private String description;
    private double baseAmount;
    private boolean isRecurring;
    private boolean isActive;

    public PaymentConcept() {
    }

    public PaymentConcept(Integer idConcept, String conceptCode, String conceptName, 
                          String description, double baseAmount, boolean isRecurring, boolean isActive) {
        this.idConcept = idConcept;
        this.conceptCode = conceptCode;
        this.conceptName = conceptName;
        this.description = description;
        this.baseAmount = baseAmount;
        this.isRecurring = isRecurring;
        this.isActive = isActive;
    }

    public Integer getIdConcept() {
        return idConcept;
    }

    public void setIdConcept(Integer idConcept) {
        this.idConcept = idConcept;
    }

    public String getConceptCode() {
        return conceptCode;
    }

    public void setConceptCode(String conceptCode) {
        this.conceptCode = conceptCode;
    }

    public String getConceptName() {
        return conceptName;
    }

    public void setConceptName(String conceptName) {
        this.conceptName = conceptName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getBaseAmount() {
        return baseAmount;
    }

    public void setBaseAmount(double baseAmount) {
        this.baseAmount = baseAmount;
    }

    public boolean isRecurring() {
        return isRecurring;
    }

    public void setRecurring(boolean recurring) {
        isRecurring = recurring;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public String toString() {
        return String.format("[%s] %-22s | Base: $%,10.2f | Recurrente: %s",
                conceptCode, conceptName, baseAmount, isRecurring ? "Si" : "No");
    }
}
