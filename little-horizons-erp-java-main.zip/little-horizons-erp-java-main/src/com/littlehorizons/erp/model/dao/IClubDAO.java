package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Club;
import com.littlehorizons.erp.model.entity.ClubMembership;

import java.time.LocalDate;
import java.util.List;

/**
 * Data Access Object interface for Clubs and Club Memberships.
 */
public interface IClubDAO {

    List<Club> findAll();

    List<Club> findActive();

    Club findById(int idClub);

    Club findByName(String name);

    void create(Club club);

    void update(Club club);

    int countActiveMembers(int idClub);

    void registerMembership(ClubMembership membership);

    void withdrawMembership(int idMembership, LocalDate withdrawalDate, String reason);

    List<ClubMembership> findMembershipsByClub(int idClub);

    List<ClubMembership> findMembershipsByStudent(int idStudent);

    ClubMembership findMembershipById(int idMembership);

    boolean isStudentActiveMember(int idStudent, int idClub);
}
