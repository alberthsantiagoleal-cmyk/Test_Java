package com.littlehorizons.erp.service.billing;

/**
 * Strategy representing a 50% scholarship discount for high-performing or subsidized students.
 */
public class ScholarshipDiscountStrategy implements FeeCalculationStrategy {

    private static final double DISCOUNT_PERCENTAGE = 50.0;

    @Override
    public double calculateFee(double baseAmount) {
        double discounted = baseAmount * (1.0 - (DISCOUNT_PERCENTAGE / 100.0));
        return Math.max(0.0, discounted);
    }

    @Override
    public String getStrategyName() {
        return "Beca Academica Parcial (50%)";
    }

    @Override
    public double getDiscountPercentage() {
        return DISCOUNT_PERCENTAGE;
    }
}
