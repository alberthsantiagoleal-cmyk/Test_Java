package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Grade;
import java.util.List;

public interface IGradeDAO {
    List<Grade> findAll();
    boolean existsById(int id);
}
