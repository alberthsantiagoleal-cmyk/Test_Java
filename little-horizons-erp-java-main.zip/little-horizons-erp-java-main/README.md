# Little Horizons ERP - Sistema de Planificación de Recursos Educativos

[![Java](https://img.shields.io/badge/Java-17%20%7C%2021-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)](https://www.oracle.com/java/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0+-4479A1?style=for-the-badge&logo=mysql&logoColor=white)](https://www.mysql.com/)
[![Architecture](https://img.shields.io/badge/Architecture-MVC%20%2B%20DAO-blue?style=for-the-badge)](#8-estructura-del-proyecto)

Sistema integral de gestión académica, administrativa y financiera diseñado a la medida para el **Colegio Internacional "Little Horizons"**.

---

## 2. Descripción

### Resumen del Propósito
El Colegio Internacional "Little Horizons" atiende a más de 500 estudiantes desde preescolar hasta grado 11°. Con más de 40 profesores, diversos clubes extracurriculares y préstamos de recursos de laboratorio y biblioteca, la institución requería una solución centralizada y robusta que sustituyera las hojas de cálculo dispersas y registros físicos. 

Este ERP actúa como el núcleo operacional del colegio, automatizando el ciclo de vida del estudiante, el seguimiento docente, la evaluación periódica, el control de inventario de recursos y la facturación electrónica bajo normativa colombiana.

### Problemas que Resuelve
* **Pérdida de Información Académica:** Historial seguro y digital de notas con cálculo transparente de promedios ponderados y por período.
* **Desorganización Extracurricular:** Control automatizado de cupos máximos por club y registro histórico de participantes y premiaciones en eventos.
* **Caos en la Facturación:** Emisión de recibos y facturas electrónicas en formato PDF con CUFE y QR simulados conforme a directrices de la DIAN.
* **Pérdida de Recursos:** Seguimiento estricto de inventario diferenciando préstamos a estudiantes y profesores con detección de préstamos vencidos.
* **Inasistencia Crítica:** Monitoreo preventivo de asistencia diaria para detectar patrones de ausencias injustificadas.

### Funcionalidades Principales
1. **Gestión Académica:** Registro de estudiantes, asignación de acudientes (1 a N), matrículas, directorio docente, asignación de materias, calificaciones (escala 0.0 a 5.0) y asistencia diaria.
2. **Actividades Extracurriculares:** Administración de clubes con aforo limitado y calendario de eventos con posiciones de competencia.
3. **Gestión Financiera:** Catálogo de conceptos de cobro, descuentos por hermanos o becas (patrón Strategy), registro de pagos y generación de facturas electrónicas en PDF.
4. **Gestión de Recursos:** Inventario categorizado (libros, tecnología, laboratorios) y préstamos separados para estudiantes y docentes.
5. **Reportes con Stream API:** Estadísticas de promedios por curso, morosos, estudiantes con ausencias críticas y préstamos vencidos.

---

## 3. Autores

* **Estudiante 1:** Alberth Santiago Leal (`alberthsantiagoleal@gmail.com`)
* **Estudiante 2:** Fabian Camilo Aguilera Jimenez (`fcaguileraj7@gmail.com`)
* **Institucion:** Campuslands - Ruta de Desarrollo Java

---

## 4. Tecnologías Utilizadas

* **Lenguaje de Programación:** Java (JDK 17 / JDK 21 LTS).
* **IDEs Soportados:** IntelliJ IDEA & Apache NetBeans (compatibilidad cruzada garantizada).
* **Base de Datos:** MySQL Server 8.0 o superior (con soporte para `CHECK constraints` e integridad referencial `InnoDB`).
* **Conector de Base de Datos:** MySQL Connector/J `9.1.0`.
* **Generación de Archivos:** API de Streams, manipulación de archivos nativa y utilidades PDF.
* **Control de Versiones:** Git y GitHub.

---

## 5. Requerimientos Previos

Para compilar y ejecutar este proyecto se requiere:
1. **Java Development Kit (JDK):** Versión 17 o 21 LTS instalada y configurada en la variable de entorno `JAVA_HOME`.
2. **MySQL Server:** **Versión 8.0 o superior** (Requerido obligatoriamente para la ejecución de constraints de validación `CHECK`).
3. **IDE:** Apache NetBeans 18+ o IntelliJ IDEA 2023+.
4. **Git:** Para clonar el repositorio.

---

## 6. Configuración de la Base de Datos

### 6.1. Creación de la Base de Datos
El proyecto incluye el script completo con la definición de tablas (DDL) y datos de prueba realistas (DML):
1. Abra su cliente MySQL preferido (MySQL Workbench, DBeaver o terminal).
2. Ejecute el archivo ubicado en `docs/database.sql`:
   ```bash
   mysql -u root -p < docs/database.sql
   ```
   *Esto creará la base de datos `erp_little_horizons` e insertará los registros iniciales.*

### 6.2. Configuración de Credenciales
Abra la clase `DatabaseConnection.java` en `src/com/littlehorizons/erp/util/` y ajuste las credenciales según su entorno local:
```java
private static final String URL = "jdbc:mysql://localhost:3306/erp_little_horizons?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
private static final String USER = "root";       // Su usuario de MySQL
private static final String PASSWORD = "password"; // Su contraseña de MySQL
```

### 6.3. Instalación del Driver JDBC
El conector `mysql-connector-j-9.1.0.jar` se encuentra en la carpeta `lib/` del proyecto.
* **En IntelliJ IDEA:** Clic derecho sobre `lib/mysql-connector-j-9.1.0.jar` ➔ **Add as Library...** ➔ OK.
* **En Apache NetBeans:** Clic derecho en el nodo **Libraries** del proyecto ➔ **Add JAR/Folder...** ➔ Seleccionar el archivo de la carpeta `lib/`.

---

## 7. Instalación y Ejecución

### 7.1. Clonar el Repositorio
```bash
git clone https://github.com/fcaguileraj7-camp/little-horizons-erp-java.git
cd little-horizons-erp-java
```

### 7.2. Abrir el Proyecto en el IDE
* **IntelliJ IDEA:** `File` ➔ `Open` ➔ Seleccionar la carpeta raíz del proyecto.
* **Apache NetBeans:** Seleccione `File` ➔ `Open Project` y abra la carpeta raíz que contiene `build.xml`. El repositorio ya está configurado como proyecto Java with Ant, con `src` como carpeta de fuentes, `com.littlehorizons.erp.Main` como clase principal y `lib/mysql-connector-j-9.1.0.jar` en el classpath. No es necesario crear un proyecto nuevo ni agregar el JAR manualmente.
* En NetBeans, confirme que el proyecto use JDK 21: clic derecho en el proyecto ➔ **Properties** ➔ **Libraries** ➔ **Java Platform**. Si no aparece una plataforma, agréguela desde **Tools** ➔ **Java Platforms**.

### 7.3. Compilar
Asegúrese de compilar el proyecto a través de NetBeans con **Run** ➔ **Clean and Build Project** (o **Shift+F11**), o por línea de comandos:
```bash
ant clean compile
```

### 7.4. Ejecutar
Ejecute el proyecto en NetBeans con **Run Project** (o **F6**). La clase principal configurada es `com.littlehorizons.erp.Main`; también puede hacer clic derecho en `Main.java` y seleccionar **Run File**.

Las opciones **1**, **2** y **3** del menú principal abren el módulo académico; la opción **7** abre sus reportes. Las funciones que consultan o guardan información requieren que MySQL esté iniciado, que se haya ejecutado `docs/database.sql` y que las credenciales locales de `DatabaseConnection.java` correspondan con el servidor. Las opciones de recursos y actividades extracurriculares todavía muestran el aviso de módulo en desarrollo.

---

## 8. Estructura del Proyecto

El sistema adopta estrictamente la arquitectura **Modelo-Vista-Controlador (MVC)** desacoplada con el patrón **DAO (Data Access Object)**:

```text
little-horizons-erp/
├── docs/
│   ├── database.sql           # DDL completo + DML con datos de prueba
│   └── WORK_PLAN.md           # Plan de trabajo y asignación por pareja
├── invoices/                  # Carpeta de salida para las facturas PDF generadas
├── lib/                       # Librerías externas (.jar)
│   └── mysql-connector-j-9.1.0.jar
├── src/
│   └── com/littlehorizons/erp/
│       ├── Main.java          # Punto de entrada de la aplicación
│       ├── model/
│       │   ├── entity/        # Modelos del dominio (POJOs en inglés)
│       │   │   ├── Student.java, Teacher.java, Subject.java, etc.
│       │   └── dao/           # Contratos de acceso a datos (Interfaces)
│       │       ├── IStudentDAO.java, IPaymentDAO.java, etc.
│       │       └── impl/      # Implementaciones JDBC con PreparedStatement
│       ├── controller/        # Validaciones de negocio y orquestación
│       │   ├── AcademicController.java
│       │   ├── FinancialController.java
│       │   ├── ResourceController.java
│       │   └── ExtracurricularController.java
│       ├── view/              # Interfaces de consola estructuradas
│       │   ├── MainMenuView.java
│       │   ├── AcademicView.java
│       │   ├── FinancialView.java
│       │   └── ResourceView.java
│       ├── service/           # Lógica especializada de negocio
│       │   ├── billing/       # Estrategias de cálculo de pagos
│       │   ├── invoice/       # Generación de facturas DIAN (PDF, CUFE, QR)
│       │   └── report/        # Consultas y procesamiento con Stream API
│       └── util/              # Utilidades transversales
│           ├── DatabaseConnection.java  # Singleton JDBC
│           ├── ScannerHelper.java       # Singleton de lectura con validación
│           ├── LoggerHelper.java        # Escritura de logs en error_log.txt
│           └── ConsoleUI.java           # Formateo visual y marcos de consola
├── error_log.txt              # Registro centralizado de excepciones en runtime
├── .gitignore
└── README.md
```

---

## 9. Principios y Patrones de Diseño Aplicados

### 9.1. Principios SOLID
* **Single Responsibility Principle (SRP):** Cada clase tiene una única razón de cambio. Las vistas solo interactúan con el usuario, los controladores validan reglas de negocio, los DAOs se encargan exclusivamente de la persistencia SQL y `LoggerHelper` se encarga únicamente del registro en disco.
* **Open/Closed Principle (OCP):** El sistema de liquidación de pagos permite agregar nuevos tipos de subsidios o convenios extendiendo la interfaz `FeeCalculationStrategy` sin modificar el código de liquidación existente.
* **Liskov Substitution Principle (LSP):** Todas las implementaciones de DAO (`StudentDAOImpl`, etc.) implementan sus interfaces base (`IStudentDAO`), garantizando que cualquier componente que dependa de la abstracción pueda sustituirse sin alterar el comportamiento.
* **Interface Segregation Principle (ISP):** Interfaces DAO específicas y atómicas en lugar de un repositorio genérico masivo.
* **Dependency Inversion Principle (DIP):** Los controladores dependen de interfaces abstractas (`IStudentDAO`, `IPaymentDAO`) y no de implementaciones concretas de MySQL.

### 9.2. Patrones de Diseño
* **Singleton:**
  * `DatabaseConnection`: Garantiza una única instancia compartida de conexión hacia MySQL, optimizando recursos y evitando fugas de memoria.
  * `ScannerHelper`: Evita conflictos de concurrencia y fugas de buffer al mantener una sola instancia de `Scanner(System.in)`.
* **DAO (Data Access Object):** Separa completamente la lógica de negocio de las sentencias SQL JDBC, facilitando el mantenimiento y las pruebas.
* **Strategy:** Empleado en el módulo financiero (`FeeCalculationStrategy`) para liquidar montos: tarifa estándar, descuento para hermanos y becas académicas.
* **Builder:** Utilizado para la construcción fluida y segura de facturas electrónicas y entidades complejas con múltiples atributos opcionales.

---

## 10. Funcionalidades Principales

### Módulo Académico
* Registro de estudiantes con vinculación de acudientes y parentesco.
* Matrícula por grado (Preescolar a 11°) e inscripción en asignaturas.
* Directorio de profesores y asignación de materias por sección.
* Ingreso de calificaciones por período con validación estricta de rango (0.0 a 5.0).
* Registro diario de asistencia y cálculo de inasistencias acumuladas.

### Módulo Extracurricular
* Catálogo de clubes con control estricto de cupo máximo.
* Calendario de eventos y registro de participantes con asignación de lugares competitivos.

### Módulo Financiero y Facturación DIAN
* Liquidación de pagos con descuentos diferenciados.
* Consulta de historial por estudiante y acudiente.
* Emisión automática de facturas electrónicas en PDF con:
  * Consecutivo y datos institucionales.
  * Cálculo de CUFE simulado (Hash criptográfico).
  * Código QR simulado con metadatos del pago.
  * Resolución DIAN simulada.

### Módulo de Recursos
* Control de inventario de laboratorio, biblioteca y deportes.
* Préstamos segregados para estudiantes (`prestamos_estudiante`) y docentes (`prestamos_profesor`).
* Control de devoluciones y alerta de préstamos vencidos.

---

## 11. Manejo de Errores y Logs

* **Estrategia de Excepciones:** Todas las operaciones de entrada/salida y SQL están protegidas mediante bloques `try-catch` y `try-with-resources`.
* **Archivo de Logs:** Las excepciones no controladas se capturan y registran en `error_log.txt` con fecha, hora, mensaje descriptivo y traza de error, evitando la interrupción abrupta de la experiencia de usuario.

---

## 12. Capturas de Pantalla y Flujos de Ejecucion

### Menu Principal del Sistema ERP
```text
================================================================================
           SISTEMA DE PLANIFICACION DE RECURSOS (ERP) - LITTLE HORIZONS         
================================================================================
  1. Gestion de Estudiantes y Acudientes
  2. Gestion Academica (Materias, Notas y Asistencia)
  3. Gestion de Profesores y Carga Academica
  4. Actividades Extracurriculares (Clubes y Eventos)
  5. Gestion Financiera y Facturacion DIAN
  6. Gestion de Recursos (Biblioteca y Laboratorios)
  7. Reportes y Estadisticas del Sistema
  8. Salir
--------------------------------------------------------------------------------
Seleccione una opcion [1-8]: 
```

### Liquidacion Financiera con Patron Strategy y Facturacion DIAN
```text
[RESUMEN] Resumen de Liquidacion:
   Monto Base: $  500,000.00
   Estrategia: Descuento por Hermanos (15% de descuento)
   TOTAL A PAGAR: $  425,000.00

[OK] Pago registrado exitosamente!
   ID Pago:          1
   Numero de Recibo: REC-2026-100001
   Monto Cobrado:    $425,000.00
   Fecha de Pago:    2026-01-20
-------------------------------------------------------------
Desea generar la Factura Electronica DIAN en PDF? (S/N): S
[OK] Factura Electronica DIAN generada exitosamente!
   Factura No.:     FE-000001
   CUFE:            e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
   Archivo PDF:     invoices/factura_FE-000001.pdf
```

### Tabla Oficial de Commits y Entregables (Hashes SHA)

| Modulo / Hito | Hash SHA | Descripcion |
| :--- | :--- | :--- |
| **Arquitectura Base** | `189cc09` | Estructura de paquetes, DDL base y documentacion inicial |
| **Nucleo y Utilidades** | `ba1b5cc` | Singletons (`DatabaseConnection`, `ScannerHelper`), `LoggerHelper` y `ConsoleUI` |
| **Modulo Financiero** | `5b89d86` | Entidades, DAOs y Patron Strategy (4 politicas de cobro) |
| **Configuracion NetBeans** | `4c237b3` | Scripts Ant (`build.xml`) para compatibilidad NetBeans / IntelliJ |
| **Modulo Academico** | `43eb27b` | Estudiantes, notas, asistencias y promedios con Stream API |
| **Integracion Academica** | `887dd4b` | Merge e integracion de la rama `feat/academic-module` |
| **Modulo de Recursos** | `1bcf5dd` | Inventario, prestamos polimorficos (`Loan`) y reporte de mora |
| **Modulo Extracurricular** | `8530d77` | Clubes con cupo maximo y eventos con clasificaciones competitivas |
| **Facturacion DIAN PDF** | `5a14f21` | Generador nativo PDF-1.4, hash CUFE (SHA-256) y codigo QR vectorial |
| **Dataset DML (>= 30 reg.)** | `b37172f` | Poblacion completa de 30+ registros por tabla en `database.sql` |

---

## 13. Problemas Conocidos y Limitaciones
* La consola integrada de Apache NetBeans puede no interpretar secuencias de escape ANSI de limpieza de pantalla; el sistema cuenta con un fallback automatico de saltos de linea visuales.
* La representacion de caracteres especiales se ha mantenido en ASCII puro para garantizar visualizacion identica sin distorsiones en cualquier terminal de Windows, Linux y macOS.

---

## 14. Futuras Mejoras
* Interfaz grafica de usuario con JavaFX o Swing.
* Integracion con servicio web REST para consulta de calificaciones via web.

---

## 15. Licencia
Este proyecto es de uso academico para la evaluacion del modulo de Java en Campuslands.

---

## 16. Contacto y Autores
* **Fabian Camilo Aguilera Jimenez** - [fcaguileraj7@gmail.com](mailto:fcaguileraj7@gmail.com) | GitHub: [@fcaguileraj7](https://github.com/fcaguileraj7)
* **Alberth Santiago Leal** - [alberthsantiagoleal@gmail.com](mailto:alberthsantiagoleal@gmail.com) | GitHub: [@alberthsantiagoleal-cmyk](https://github.com/alberthsantiagoleal-cmyk)

---

## 17. Guía de Ejecución y Solución de Casos - Test Final (NetBeans + DBeaver en Linux)

Esta sección contiene el protocolo paso a paso para montar el entorno en máquinas Linux de Campuslands y las plantillas de código para resolver con rapidez los casos típicos solicitados en la prueba final.

```text
                                  MAPA DE RUTA EN EL TEST FINAL
                                  
  [1. DESCARGA Y ENTORNO]       [2. BASE DE DATOS]            [3. VERIFICACIÓN]            [4. RESOLUCIÓN DE CASOS]
  • Clonar o ZIP en Linux       • Conexión MySQL en DBeaver   • Libraries (JAR MySQL)      • Caso 1: Nuevo Módulo CRUD
  • Abrir en NetBeans           • Cargar script del Drive     • Run (F6) en NetBeans       • Caso 2: Nuevo Descuento (Strategy)
  • Verificar JDK 17/21         • Ejecutar con Alt + X        • Validar mensaje [INFO]     • Caso 3: Reporte Stream / Lambdas
                                                                                           • Caso 4: Transacción ACID
```

---

### 17.1. Protocolo de Despliegue Rápido (Primeros 10 Minutos)

#### Paso 1: Clonar o Descargar el Proyecto
* **En NetBeans:** `Team` ➔ `Git` ➔ `Clone...` ➔ URL: `https://github.com/fcaguileraj7-camp/little-horizons-erp-java.git` ➔ Rama `main` ➔ `Open Project`.
* **Alternativa Navegador:** Entrar a GitHub ➔ Botón verde `Code` ➔ `Download ZIP` ➔ Extraer ➔ En NetBeans: `File` ➔ `Open Project`.

#### Paso 2: Crear y Poblar la Base de Datos en DBeaver
1. Abrir **DBeaver** ➔ Crear nueva conexión **MySQL** (`Host: localhost`, `Port: 3306`, `User: root` o `campus2023`).
2. Probar conexión (**Test Connection**) y guardar.
3. Descargar el archivo `.sql` provisto en el Google Drive.
4. En DBeaver: `SQL Editor` ➔ `Open SQL Script` (`Ctrl + O`) ➔ Seleccionar el archivo descargado.
5. **Comando Clave de Ejecución:** Presionar **`Alt + X`** (o clic en el ícono **Execute SQL Script** con varias hojas superpuestas). *No usar `Ctrl + Enter` porque solo corre una sola línea.*
6. En el panel izquierdo de DBeaver, presionar `F5` sobre Databases y verificar que `little_horizons_db` contenga las tablas y datos.

#### Paso 3: Verificación en NetBeans ("Luz Verde")
1. Desplegar el proyecto ➔ carpeta **Libraries**. Verificar que `mysql-connector-j-9.1.0.jar` no tenga advertencia amarilla. Si la tiene: Clic derecho en `Libraries` ➔ `Add JAR/Folder...` ➔ buscarlo dentro de la carpeta `lib/` del proyecto.
2. Presionar **`F6`** (Run Project). Confirmar en la consola integrada:
   ```text
   [INFO] Conexión establecida exitosamente con MySQL.
   ```
3. Probar opción `1. Gestión de Estudiantes` ➔ `Listar`. Si lista registros, el entorno está 100% listo.

---

### 17.2. Plantillas de Solución para Casos del Test

---

#### CASO 1: Creación de un Nuevo Módulo CRUD Completo
*(Ejemplo común: Crear módulo de "Transporte Escolar", "Cafetería" o "Seguimiento de Convivencia")*

##### Paso 1: Crear la tabla en DBeaver
```sql
CREATE TABLE IF NOT EXISTS transportes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ruta VARCHAR(50) NOT NULL,
    conductor VARCHAR(100) NOT NULL,
    capacidad INT NOT NULL,
    placa VARCHAR(10) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

##### Paso 2: Crear la Entidad (`model.entity.Transport.java`)
```java
package com.littlehorizons.erp.model.entity;

public class Transport {
    private int id;
    private String ruta;
    private String conductor;
    private int capacidad;
    private String placa;

    public Transport() {}

    public Transport(int id, String ruta, String conductor, int capacidad, String placa) {
        this.id = id;
        this.ruta = ruta;
        this.conductor = conductor;
        this.capacidad = capacidad;
        this.placa = placa;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getRuta() { return ruta; }
    public void setRuta(String ruta) { this.ruta = ruta; }
    public String getConductor() { return conductor; }
    public void setConductor(String conductor) { this.conductor = conductor; }
    public int getCapacidad() { return capacidad; }
    public void setCapacidad(int capacidad) { this.capacidad = capacidad; }
    public String getPlaca() { return placa; }
    public void setPlaca(String placa) { this.placa = placa; }
}
```

##### Paso 3: Crear la Interfaz DAO (`model.dao.ITransportDAO.java`)
```java
package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Transport;
import java.util.List;
import java.util.Optional;

public interface ITransportDAO {
    boolean save(Transport transport);
    Optional<Transport> findById(int id);
    List<Transport> findAll();
    boolean update(Transport transport);
    boolean delete(int id);
}
```

##### Paso 4: Implementar el DAO (`model.dao.impl.TransportDAOImpl.java`)
```java
package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.ITransportDAO;
import com.littlehorizons.erp.model.entity.Transport;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TransportDAOImpl implements ITransportDAO {
    private final Connection connection;

    public TransportDAOImpl() {
        this.connection = DatabaseConnection.getInstance().getConnection();
    }

    @Override
    public boolean save(Transport t) {
        String sql = "INSERT INTO transportes (ruta, conductor, capacidad, placa) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, t.getRuta());
            stmt.setString(2, t.getConductor());
            stmt.setInt(3, t.getCapacidad());
            stmt.setString(4, t.getPlaca());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) t.setId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error al guardar transporte", e);
        }
        return false;
    }

    @Override
    public List<Transport> findAll() {
        List<Transport> list = new ArrayList<>();
        String sql = "SELECT * FROM transportes ORDER BY id ASC";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(new Transport(
                    rs.getInt("id"),
                    rs.getString("ruta"),
                    rs.getString("conductor"),
                    rs.getInt("capacidad"),
                    rs.getString("placa")
                ));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error al listar transportes", e);
        }
        return list;
    }

    @Override
    public Optional<Transport> findById(int id) {
        String sql = "SELECT * FROM transportes WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Transport(
                        rs.getInt("id"),
                        rs.getString("ruta"),
                        rs.getString("conductor"),
                        rs.getInt("capacidad"),
                        rs.getString("placa")
                    ));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error al buscar transporte por ID", e);
        }
        return Optional.empty();
    }

    @Override
    public boolean update(Transport t) {
        String sql = "UPDATE transportes SET ruta = ?, conductor = ?, capacidad = ?, placa = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, t.getRuta());
            stmt.setString(2, t.getConductor());
            stmt.setInt(3, t.getCapacidad());
            stmt.setString(4, t.getPlaca());
            stmt.setInt(5, t.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LoggerHelper.logError("Error al actualizar transporte", e);
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM transportes WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            LoggerHelper.logError("Error al eliminar transporte", e);
            return false;
        }
    }
}
```

##### Paso 5: Controlador y Conexión con la Vista
* En `controller.TransportController.java`: Instancia `new TransportDAOImpl()` y expone métodos de lógica de negocio.
* En `view.MainMenuView.java`: Se añade la opción al menú principal para interactuar por consola.

---

#### CASO 2: Nueva Regla de Negocio o Descuento (Patrón Strategy)
*(Ejemplo: Crear una "Beca Deportiva" con 40% de descuento o "Descuento por Pronto Pago" con 10%)*

##### Paso 1: Crear la nueva clase en `service.billing`
```java
package com.littlehorizons.erp.service.billing;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class SportsScholarshipStrategy implements FeeCalculationStrategy {
    private static final BigDecimal DISCOUNT_RATE = new BigDecimal("0.40"); // 40% de descuento

    @Override
    public BigDecimal calculateFee(BigDecimal baseAmount) {
        BigDecimal discount = baseAmount.multiply(DISCOUNT_RATE);
        return baseAmount.subtract(discount).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public String getStrategyName() {
        return "Beca Deportiva (40% de descuento)";
    }
}
```

##### Paso 2: Registrar la Estrategia en la Vista (`view.FinancialView.java`)
```java
System.out.println("4. Beca Deportiva (40%)");
// En la selección:
case 4 -> strategy = new SportsScholarshipStrategy();
```
*Cumple al 100% el principio Abierto/Cerrado (OCP de SOLID): nuevo comportamiento sin modificar clases existentes.*

---

#### CASO 3: Nuevo Reporte con Java Stream API y Lambdas
*(Ejemplo: Filtrar registros en memoria, calcular métricas o agrupar datos)*

```java
// 1. Filtrar pagos de alto valor ordenados descendentemente
List<Payment> highValuePayments = paymentDAO.findAll().stream()
    .filter(p -> p.getMonto().compareTo(new BigDecimal("300000")) >= 0)
    .sorted((p1, p2) -> p2.getMonto().compareTo(p1.getMonto()))
    .collect(Collectors.toList());

// 2. Calcular promedio numérico con mapToDouble (previene división por cero con orElse)
double subjectAverage = gradeDAO.findAll().stream()
    .filter(g -> g.getMateriaId() == targetMateriaId)
    .mapToDouble(Grade::getCalificacion)
    .average()
    .orElse(0.0);

// 3. Agrupación por clave (ejemplo: estudiantes agrupados por grado_id)
Map<Integer, List<Student>> studentsByGrade = studentDAO.findAll().stream()
    .collect(Collectors.groupingBy(Student::getGradoId));
```

---

#### CASO 4: Transacción Combinada / Consistencia ACID
*(Ejemplo: Matricular a un estudiante y generar su cobro en un solo paso atómico e indivisible)*

```java
Connection conn = DatabaseConnection.getInstance().getConnection();
boolean previousAutoCommit = true;

try {
    previousAutoCommit = conn.getAutoCommit();
    conn.setAutoCommit(false); // Inicia la transacción atómica

    // Operación 1: Insertar matrícula
    String sqlMatricula = "INSERT INTO matriculas (estudiante_id, grado_id, ano_academico, estado) VALUES (?, ?, ?, ?)";
    try (PreparedStatement stmt1 = conn.prepareStatement(sqlMatricula)) {
        stmt1.setInt(1, studentId);
        stmt1.setInt(2, gradeId);
        stmt1.setString(3, "2026");
        stmt1.setString(4, "Activa");
        stmt1.executeUpdate();
    }

    // Operación 2: Insertar cobro o factura asociada
    String sqlCobro = "INSERT INTO cobros (estudiante_id, concepto, monto, fecha_limite) VALUES (?, ?, ?, ?)";
    try (PreparedStatement stmt2 = conn.prepareStatement(sqlCobro)) {
        stmt2.setInt(1, studentId);
        stmt2.setString(2, "Matrícula Anual 2026");
        stmt2.setBigDecimal(3, new BigDecimal("500000.00"));
        stmt2.setDate(4, Date.valueOf(LocalDate.now().plusDays(15)));
        stmt2.executeUpdate();
    }

    // Si ambas sentencias tuvieron éxito:
    conn.commit();
    ConsoleUI.printSuccess("Transacción completada exitosamente.");

} catch (SQLException e) {
    try {
        conn.rollback(); // Deshacer cambios en caso de cualquier falla
        ConsoleUI.printError("Error en la transacción. Se ejecutó Rollback: " + e.getMessage());
    } catch (SQLException rollbackEx) {
        LoggerHelper.logError("Error crítico al ejecutar rollback", rollbackEx);
    }
} finally {
    try {
        conn.setAutoCommit(previousAutoCommit); // Restaurar auto-commit
    } catch (SQLException e) {
        LoggerHelper.logError("Error restaurando auto-commit", e);
    }
}
```

---

### 17.3. Checklist de Diagnóstico Rápido en Linux

| Síntoma en Linux | Causa Raíz | Solución Inmediata |
| :--- | :--- | :--- |
| `Table 'db.Estudiantes' doesn't exist` | Linux es **sensible a mayúsculas/minúsculas**. La tabla en DBeaver está como `estudiantes` en minúscula. | En la consulta SQL de tu DAO, escribe el nombre exactamente igual que en DBeaver (en minúsculas). |
| `ClassNotFoundException: com.mysql.cj.jdbc.Driver` | NetBeans no tiene el JAR en el classpath de ejecución. | Clic derecho en **Libraries** ➔ **Add JAR/Folder** ➔ Seleccionar `lib/mysql-connector-j-9.1.0.jar`. |
| `Access denied for user 'root'@'localhost'` | Contraseña de MySQL local diferente en la máquina del campus. | `DatabaseConnection.java` auto-negocia contraseñas comunes, pero si tiene una clave única (ej. `campus2023`), agrégala en el arreglo de contraseñas de `DatabaseConnection.java`. |
| `java.nio.file.InvalidPathException` | Ruta de archivos con barras invertidas `\` de Windows. | Usar siempre barras normales `/` o `File.separator` para rutas de facturas y logs. |
| DBeaver solo ejecutó la primera tabla | Se ejecutó con `Ctrl + Enter` en vez de procesar el archivo completo. | Abrir el script en el editor y presionar **`Alt + X`** (**Execute SQL Script**). |


---

### 17.4. Mapeo Rápido: "¿Qué te piden? ➔ ¿Qué plantilla usar?"

Utiliza esta tabla para no perder tiempo pensando cómo estructurar el código en el examen. Todo lo que te puedan pedir ya tiene un hermano gemelo funcionando en el proyecto:

| Si en el Test te piden... | Archivos Plantilla a Abrir y Copiar | ¿Por qué esta plantilla? |
| :--- | :--- | :--- |
| **CRUD simple de una tabla independiente**<br>*(ej. Rutas de Bus, Proveedores, Sedes, Categorías, Espacios)* | **Entidad:** `model/entity/Club.java`<br>**Interfaz DAO:** `model/dao/IClubDAO.java`<br>**Implementación:** `model/dao/impl/ClubDAOImpl.java`<br>**Controlador:** `controller/ExtracurricularController.java` | Es el CRUD más limpio y conciso del proyecto. Tiene `save`, `findById`, `findAll`, `update` y `delete` con JDBC puro y `try-with-resources`. |
| **CRUD con Clave Foránea / Relación 1 a N**<br>*(ej. Asignar estudiante a ruta, Registrar falta disciplinaria, Asignar tutor)* | **Entidad:** `model/entity/Attendance.java` o `Grade.java`<br>**DAO:** `model/dao/impl/AttendanceDAOImpl.java` o `GradeDAOImpl.java` | Muestra cómo recibir IDs foráneos, ejecutar `INSERT` con llaves foráneas y hacer consultas con `JOIN` para traer datos descriptivos del estudiante/materia. |
| **Nueva Regla de Cobro, Beca o Descuento**<br>*(ej. Beca deportiva 40%, Descuento por pago anticipado, Recargo por mora)* | **Estrategia:** `service/billing/SiblingDiscountStrategy.java`<br>**Contrato:** `service/billing/FeeCalculationStrategy.java`<br>**Menú:** `view/FinancialView.java` | Patrón **Strategy** puro. Creas una sola clase, implementas el método de cálculo y agregas la opción en el switch de la vista. Cero modificaciones a la lógica central (OCP). |
| **Nuevo Reporte con Stream API y Lambdas**<br>*(ej. Promedio general, Estudiantes en riesgo, Top profesores con más materias)* | **Servicio:** `service/report/AcademicReportService.java`<br>**Controlador:** `controller/ExtracurricularController.java` (`getClubsNearCapacity`) | Contiene pipelines funcionales listos con `.filter()`, `.mapToDouble()`, `.average()`, `.collect(Collectors.groupingBy(...))` y ordenamientos comparativos. |
| **Herencia o Polimorfismo**<br>*(ej. Dos tipos de usuarios, dos modalidades de préstamo o dos tipos de matrículas)* | **Clase Base:** `model/entity/Loan.java`<br>**Clases Hijas:** `model/entity/StudentLoan.java` y `TeacherLoan.java`<br>**DAO:** `model/dao/impl/ResourceDAOImpl.java` | Demuestra LSP (Liskov Substitution Principle). Persiste en tablas especializadas según el subtipo de la entidad. |
| **Transacción Atómica (2 o más tablas)**<br>*(ej. Matricular + Cobrar, o Prestar recurso + Descontar unidades)* | **Guía:** Sección `17.2 (Caso 4)` de este mismo `README.md` | Manejo de `conn.setAutoCommit(false)`, `commit()` y `rollback()` para asegurar consistencia ACID ante fallos. |
| **Capturar datos por consola sin errores**<br>*(ej. Pedir enteros, decimales, fechas `YYYY-MM-DD` o textos obligatorios)* | **Utilidad:** `util/ScannerHelper.java` | Usa `readInt()`, `readPositiveDouble()`, `readLocalDate()` y `readNonEmptyString()`. Ya tienen validación en bucle y nunca lanzan `InputMismatchException`. |
| **Dar formato profesional a la salida**<br>*(ej. Títulos enmarcados, alertas verdes/rojas, tablas de texto)* | **Utilidad:** `util/ConsoleUI.java` | Usa `ConsoleUI.printHeader(...)`, `ConsoleUI.printSuccess(...)`, `ConsoleUI.printError(...)` o `ConsoleUI.printTable(...)` para mantener la estética del sistema. |


---

### 17.5. Creación y Ejecución de la Clase de Prueba Aislada (`test`)

En evaluaciones prácticas de Campuslands, el evaluador suele pedir crear un paquete o archivo aislado llamado `test` para resolver requerimientos de Java puro (Streams, Colecciones, POO, lógica funcional) sin alterar los menús del ERP:

1. **Crear el Paquete en NetBeans:**
   * Clic derecho en `Source Packages` ➔ `com.littlehorizons.erp` ➔ **New** ➔ **Java Package...**
   * Nombre: `com.littlehorizons.erp.test`
2. **Crear la Clase de Evaluación:**
   * Clic derecho en `com.littlehorizons.erp.test` ➔ **New** ➔ **Java Class...**
   * Nombre: `EvaluacionTest.java` (o el nombre que indique el docente).
3. **Atajos de Teclado Imprescindibles en NetBeans (Linux):**
   * **`psvm` + Tab:** Genera instantáneamente el método `public static void main(String[] args) {}`.
   * **`sout` + Tab:** Genera `System.out.println("");`.
   * **`Shift + F6` (Run File):** **EL MÁS IMPORTANTE.** Ejecuta exclusivamente tu clase `EvaluacionTest.java` en 1 segundo, sin tener que navegar por todo el menú del ERP.
   * **`Ctrl + Shift + I` (Fix Imports):** Resuelve e importa automáticamente todas las clases faltantes (`List`, `Collectors`, `BigDecimal`, etc.).
   * **`Alt + Shift + F`:** Indenta y formatea el código automáticamente.

---

### 17.6. Plantilla Base para `EvaluacionTest.java` (Consumo Directo de Datos)

Esta plantilla ya deja instanciados los DAOs existentes para consultar inmediatamente los datos cargados desde el script del Drive:

```java
package com.littlehorizons.erp.test;

import com.littlehorizons.erp.model.dao.impl.*;
import com.littlehorizons.erp.model.entity.*;
import com.littlehorizons.erp.service.report.AcademicReportService;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class EvaluacionTest {

    public static void main(String[] args) {
        System.out.println("====================================================");
        System.out.println("          INICIANDO PRUEBA EVALUATIVA JAVA         ");
        System.out.println("====================================================");

        // 1. Instanciar los DAOs existentes (ya conectados a MySQL)
        StudentDAOImpl studentDAO = new StudentDAOImpl();
        GradeDAOImpl gradeDAO = new GradeDAOImpl();
        PaymentDAOImpl paymentDAO = new PaymentDAOImpl();
        TeacherDAOImpl teacherDAO = new TeacherDAOImpl();
        AttendanceDAOImpl attendanceDAO = new AttendanceDAOImpl();
        AcademicReportService reportService = new AcademicReportService();

        // 2. Cargar listas de la base de datos
        List<Student> estudiantes = studentDAO.findAll();
        List<Grade> calificaciones = gradeDAO.findAll();
        List<Payment> pagos = paymentDAO.findAll();
        List<Teacher> profesores = teacherDAO.findAll();

        System.out.println("[INFO] Estudiantes en BD: " + estudiantes.size());
        System.out.println("[INFO] Calificaciones en BD: " + calificaciones.size());
        System.out.println("[INFO] Pagos en BD: " + pagos.size());
        System.out.println("----------------------------------------------------\n");

        // ==========================================================
        //  ESPACIO PARA DESARROLLAR EL REQUERIMIENTO DEL EVALUADOR
        // ==========================================================
        
        // Ejecutar con Shift + F6 en NetBeans
    }
}
```

---

### 17.7. Ejercicios Típicos de Java y Stream API (Plantillas Listas)

Si el profesor pide resolver consultas o transformaciones en Java sobre los datos de la base de datos, utiliza estos patrones exactos:

#### 1. Buscar Máximo / Mínimo (`max` / `min` con `Comparator`)
*Ejemplo: Encontrar la calificación más alta o el pago de mayor monto.*
```java
// Calificación más alta registrada:
Grade mejorNota = calificaciones.stream()
    .max(Comparator.comparingDouble(Grade::getCalificacion))
    .orElse(null);

if (mejorNota != null) {
    System.out.printf("Nota más alta: %.2f (Estudiante ID: %d, Materia ID: %d)%n",
        mejorNota.getCalificacion(), mejorNota.getEstudianteId(), mejorNota.getMateriaId());
}
```

#### 2. Top N Elementos Ordenados (`sorted` + `limit`)
*Ejemplo: Obtener los 3 pagos más altos registrados.*
```java
List<Payment> top3Pagos = pagos.stream()
    .sorted((p1, p2) -> p2.getMonto().compareTo(p1.getMonto())) // Orden descendente
    .limit(3)
    .collect(Collectors.toList());

System.out.println("--- TOP 3 PAGOS ---");
top3Pagos.forEach(p -> System.out.println("Recibo: " + p.getNumeroRecibo() + " | Monto: $" + p.getMonto()));
```

#### 3. Conteo según Criterio (`filter` + `count`)
*Ejemplo: Contar cuántas notas están reprobadas (< 3.0) o aprobadas (>= 3.0).*
```java
long aprobadas = calificaciones.stream()
    .filter(g -> g.getCalificacion() >= 3.0)
    .count();

long reprobadas = calificaciones.stream()
    .filter(g -> g.getCalificacion() < 3.0)
    .count();

System.out.println("Aprobadas: " + aprobadas + " | Reprobadas: " + reprobadas);
```

#### 4. Agrupación por Clave (`Collectors.groupingBy`)
*Ejemplo: Agrupar asistencias según el estado (Presente, Ausente, Justificada).*
```java
Map<String, List<Attendance>> asistenciasPorEstado = attendanceDAO.findAll().stream()
    .collect(Collectors.groupingBy(Attendance::getEstado));

asistenciasPorEstado.forEach((estado, lista) -> {
    System.out.println("Estado: " + estado + " -> Cantidad: " + lista.size());
});
```

#### 5. Transformación y Mapeo de Atributos (`map` + `distinct`)
*Ejemplo: Obtener una lista única de los correos de todos los estudiantes o nombres de profesores.*
```java
List<String> emailsEstudiantes = estudiantes.stream()
    .map(Student::getEmail)
    .filter(Objects::nonNull)
    .distinct()
    .collect(Collectors.toList());
```

#### 6. Búsqueda de un Elemento Específico (`findFirst` / `findAny`)
*Ejemplo: Buscar un estudiante por número de documento de forma funcional.*
```java
String docBuscado = "1098765432";
Optional<Student> encontrado = estudiantes.stream()
    .filter(e -> docBuscado.equals(e.getNumeroDocumento()))
    .findFirst();

encontrado.ifPresentOrElse(
    est -> System.out.println("Encontrado: " + est.getNombre() + " " + est.getApellido()),
    () -> System.out.println("Estudiante no registrado con documento: " + docBuscado)
);
```

---

### 17.8. Protocolo de Entrega Final y Git en Linux

Cuando finalices el requerimiento y el evaluador dé el visto bueno, sigue estos pasos para asegurar tu entrega en el repositorio remoto:

1. **Configurar identidad en la máquina de Campus (si no está configurada):**
   ```bash
   git config --global user.name "Fabian Aguilera"
   git config --global user.email "fcaguileraj7@gmail.com"
   ```

2. **Revisar cambios generados:**
   ```bash
   git status
   ```
   *(Verás el nuevo paquete `src/com/littlehorizons/erp/test/` marcado en rojo).*

3. **Agregar, confirmar y enviar a GitHub:**
   ```bash
   git add .
   git commit -m "feat: prueba final - paquete test y evaluacion practica"
   git push origin main
   ```

> [!TIP]
> **Autenticación con GitHub en Linux:**
> Si al hacer `git push` la terminal te solicita `Username` y `Password`:
> * **Username:** Tu usuario de GitHub (`fcaguileraj7` o `fcaguileraj7-camp`).
> * **Password:** Tu **Personal Access Token (PAT)** con permisos de `repo` (GitHub ya no acepta contraseñas normales por consola HTTPS). Ten tu token a la mano en un bloc de notas o gestor.
