package com.littlehorizons.erp.controller;

import com.littlehorizons.erp.model.dao.*;
import com.littlehorizons.erp.model.dao.impl.*;
import com.littlehorizons.erp.model.entity.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public class AcademicController {
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private static final Set<String> STUDENT_DOCUMENT_TYPES = Set.of("TI", "CC", "CE", "Pasaporte");
    private static final Set<String> ADULT_DOCUMENT_TYPES = Set.of("CC", "CE", "Pasaporte");
    private static final Set<String> GENDERS = Set.of("M", "F", "Otro");
    private static final Set<String> PERIODS = Set.of("I", "II", "III", "IV", "Final");
    private static final Set<String> ATTENDANCE_STATUSES = Set.of("Presente", "Ausente", "Tardanza", "Excusa Médica");

    private final IStudentDAO studentDAO;
    private final IGuardianDAO guardianDAO;
    private final ITeacherDAO teacherDAO;
    private final ISubjectDAO subjectDAO;
    private final IGradeDAO gradeDAO;
    private final IEnrollmentDAO enrollmentDAO;
    private final IAcademicRecordDAO academicRecordDAO;
    private final IAttendanceDAO attendanceDAO;

    public AcademicController() {
        this(new StudentDAOImpl(), new GuardianDAOImpl(), new TeacherDAOImpl(), new SubjectDAOImpl(),
                new GradeDAOImpl(), new EnrollmentDAOImpl(), new AcademicRecordDAOImpl(), new AttendanceDAOImpl());
    }

    public AcademicController(IStudentDAO studentDAO, IGuardianDAO guardianDAO, ITeacherDAO teacherDAO,
            ISubjectDAO subjectDAO, IGradeDAO gradeDAO, IEnrollmentDAO enrollmentDAO,
            IAcademicRecordDAO academicRecordDAO, IAttendanceDAO attendanceDAO) {
        this.studentDAO = studentDAO;
        this.guardianDAO = guardianDAO;
        this.teacherDAO = teacherDAO;
        this.subjectDAO = subjectDAO;
        this.gradeDAO = gradeDAO;
        this.enrollmentDAO = enrollmentDAO;
        this.academicRecordDAO = academicRecordDAO;
        this.attendanceDAO = attendanceDAO;
    }

    public void registerStudent(Student student) {
        require(student != null, "Debe proporcionar los datos del estudiante.");
        requireText(student.getDocumentType(), "El tipo de documento");
        require(STUDENT_DOCUMENT_TYPES.contains(student.getDocumentType()), "Tipo de documento de estudiante no válido.");
        requireText(student.getDocumentNumber(), "El número de documento");
        requireText(student.getFirstName(), "El primer nombre");
        requireText(student.getFirstSurname(), "El primer apellido");
        require(student.getBirthDate() != null && !student.getBirthDate().isAfter(LocalDate.now()),
                "La fecha de nacimiento debe ser válida y no futura.");
        require(GENDERS.contains(student.getGender()), "El género debe ser M, F u Otro.");
        require(student.getAdmissionDate() != null, "La fecha de ingreso es obligatoria.");
        if (hasText(student.getEmail())) validateEmail(student.getEmail());
        require(student.getStatus() == null
                        || Set.of("Activo", "Graduado", "Retirado", "Suspendido").contains(student.getStatus()),
                "El estado del estudiante no es válido.");
        require(!studentDAO.existsByDocument(student.getDocumentNumber().trim()),
                "Ya existe un estudiante con ese número de documento.");
        student.setDocumentNumber(student.getDocumentNumber().trim());
        if (hasText(student.getEmail())) student.setEmail(student.getEmail().trim());
        student.setStatus(student.getStatus() == null ? "Activo" : student.getStatus());
        studentDAO.create(student);
    }

    public Student getStudent(int id) {
        requireId(id, "estudiante");
        Student student = studentDAO.findById(id);
        require(student != null, "No se encontró el estudiante con ID " + id + ".");
        return student;
    }

    public List<Student> getStudents() { return studentDAO.findAll(); }

    public void registerGuardian(Guardian guardian) {
        require(guardian != null, "Debe proporcionar los datos del acudiente.");
        require(ADULT_DOCUMENT_TYPES.contains(guardian.getDocumentType()), "Tipo de documento de acudiente no válido.");
        requireText(guardian.getDocumentNumber(), "El número de documento");
        requireText(guardian.getFirstName(), "El primer nombre");
        requireText(guardian.getFirstSurname(), "El primer apellido");
        requireText(guardian.getRelationship(), "El parentesco");
        requireText(guardian.getPrimaryPhone(), "El teléfono principal");
        if (hasText(guardian.getEmail())) validateEmail(guardian.getEmail());
        require(!guardianDAO.existsByDocument(guardian.getDocumentNumber().trim()),
                "Ya existe un acudiente con ese número de documento.");
        guardian.setDocumentNumber(guardian.getDocumentNumber().trim());
        if (hasText(guardian.getEmail())) guardian.setEmail(guardian.getEmail().trim());
        guardianDAO.create(guardian);
    }

    public Guardian getGuardian(int id) {
        requireId(id, "acudiente");
        Guardian guardian = guardianDAO.findById(id);
        require(guardian != null, "No se encontró el acudiente con ID " + id + ".");
        return guardian;
    }

    public List<Guardian> getGuardians() { return guardianDAO.findAll(); }

    public List<Guardian> getGuardiansForStudent(int studentId) {
        getStudent(studentId);
        return guardianDAO.findByStudentId(studentId);
    }

    public void linkGuardianToStudent(int studentId, int guardianId, boolean primary, boolean emergencyContact) {
        getStudent(studentId);
        getGuardian(guardianId);
        studentDAO.linkGuardian(studentId, guardianId, primary, emergencyContact);
    }

    public void registerTeacher(Teacher teacher) {
        require(teacher != null, "Debe proporcionar los datos del profesor.");
        require(ADULT_DOCUMENT_TYPES.contains(teacher.getDocumentType()), "Tipo de documento de profesor no válido.");
        requireText(teacher.getDocumentNumber(), "El número de documento");
        requireText(teacher.getFirstName(), "El primer nombre");
        requireText(teacher.getFirstSurname(), "El primer apellido");
        requireText(teacher.getEmail(), "El correo electrónico");
        validateEmail(teacher.getEmail());
        require(teacher.getHireDate() != null && !teacher.getHireDate().isAfter(LocalDate.now()),
                "La fecha de contratación debe ser válida y no futura.");
        require(teacher.getStatus() == null
                        || Set.of("Activo", "Inactivo", "Licencia").contains(teacher.getStatus()),
                "El estado del profesor no es válido.");
        require(!teacherDAO.existsByDocument(teacher.getDocumentNumber().trim()),
                "Ya existe un profesor con ese documento.");
        require(!teacherDAO.existsByEmail(teacher.getEmail().trim()),
                "Ya existe un profesor con ese correo electrónico.");
        teacher.setDocumentNumber(teacher.getDocumentNumber().trim());
        teacher.setEmail(teacher.getEmail().trim());
        teacher.setStatus(teacher.getStatus() == null ? "Activo" : teacher.getStatus());
        teacherDAO.create(teacher);
    }

    public List<Teacher> getTeachers() { return teacherDAO.findAll(); }

    public void registerSubject(Subject subject) {
        require(subject != null, "Debe proporcionar los datos de la materia.");
        requireText(subject.getCode(), "El código de materia");
        requireText(subject.getName(), "El nombre de materia");
        requireId(subject.getGradeId(), "grado");
        require(gradeDAO.existsById(subject.getGradeId()), "El grado indicado no existe.");
        require(subject.getWeeklyHours() == null || subject.getWeeklyHours() > 0,
                "Las horas semanales deben ser mayores que cero.");
        boolean duplicateCode = subjectDAO.findAll().stream()
                .anyMatch(existing -> existing.getCode().equalsIgnoreCase(subject.getCode().trim()));
        require(!duplicateCode, "Ya existe una materia con ese código.");
        subject.setCode(subject.getCode().trim());
        subjectDAO.create(subject);
    }

    public List<Subject> getSubjects() { return subjectDAO.findAll(); }
    public List<Subject> getSubjectsForGrade(int gradeId) {
        require(gradeDAO.existsById(gradeId), "El grado indicado no existe.");
        return subjectDAO.findByGradeId(gradeId);
    }
    public List<Grade> getGrades() { return gradeDAO.findAll(); }

    public void registerEnrollment(Enrollment enrollment) {
        require(enrollment != null, "Debe proporcionar los datos de la matrícula.");
        getStudent(enrollment.getStudentId());
        require(gradeDAO.existsById(enrollment.getGradeId()), "El grado indicado no existe.");
        require(enrollment.getAcademicYear() >= 2000, "El año académico no es válido.");
        require(enrollment.getEnrollmentDate() != null
                        && !enrollment.getEnrollmentDate().isAfter(LocalDate.now()),
                "La fecha de matrícula debe ser válida y no futura.");
        require(!enrollmentDAO.existsForStudentAndYear(enrollment.getStudentId(), enrollment.getAcademicYear()),
                "El estudiante ya tiene matrícula registrada para ese año académico.");
        enrollment.setStatus(enrollment.getStatus() == null ? "Activa" : enrollment.getStatus());
        require(Set.of("Activa", "Completada", "Retirada").contains(enrollment.getStatus()),
                "El estado de matrícula no es válido.");
        enrollmentDAO.create(enrollment);
    }

    public List<Enrollment> getEnrollments() { return enrollmentDAO.findAll(); }
    public List<Enrollment> getEnrollmentsForStudent(int studentId) {
        getStudent(studentId);
        return enrollmentDAO.findByStudentId(studentId);
    }

    public void registerAcademicRecord(AcademicRecord record) {
        require(record != null, "Debe proporcionar los datos de la calificación.");
        getStudent(record.getStudentId());
        Subject subject = subjectDAO.findById(record.getSubjectId());
        require(subject != null, "La materia indicada no existe.");
        require(teacherDAO.findById(record.getTeacherId()) != null, "El profesor indicado no existe.");
        require(record.getAcademicYear() >= 2000, "El año académico no es válido.");
        require(PERIODS.contains(record.getAcademicPeriod()), "El período debe ser I, II, III, IV o Final.");
        BigDecimal grade = record.getGrade();
        require(grade != null && grade.compareTo(BigDecimal.ZERO) >= 0
                        && grade.compareTo(new BigDecimal("5.0")) <= 0,
                "La calificación debe estar entre 0.0 y 5.0.");
        require(grade.stripTrailingZeros().scale() <= 1,
                "La calificación debe tener como máximo un decimal, según el esquema.");
        require(record.getRecordDate() != null && !record.getRecordDate().isAfter(LocalDate.now()),
                "La fecha de registro debe ser válida y no futura.");
        require(isEnrolledInGrade(record.getStudentId(), subject.getGradeId(), record.getAcademicYear()),
                "El estudiante no tiene matrícula activa/completada en el grado de esta materia para ese año.");
        require(!academicRecordDAO.existsForStudentSubjectYearPeriod(record.getStudentId(), record.getSubjectId(),
                        record.getAcademicYear(), record.getAcademicPeriod()),
                "Ya existe una calificación para ese estudiante, materia, año y período.");
        academicRecordDAO.create(record);
    }

    public List<AcademicRecord> getAcademicHistory(int studentId) {
        getStudent(studentId);
        return academicRecordDAO.findByStudentId(studentId);
    }
    public List<AcademicRecord> getAllAcademicRecords() { return academicRecordDAO.findAll(); }

    public void registerAttendance(Attendance attendance) {
        require(attendance != null, "Debe proporcionar los datos de asistencia.");
        getStudent(attendance.getStudentId());
        Subject subject = subjectDAO.findById(attendance.getSubjectId());
        require(subject != null, "La materia indicada no existe.");
        require(attendance.getAttendanceDate() != null
                        && !attendance.getAttendanceDate().isAfter(LocalDate.now()),
                "La fecha de asistencia debe ser válida y no futura.");
        require(ATTENDANCE_STATUSES.contains(attendance.getStatus()), "El estado de asistencia no es válido.");
        if (attendance.getRegisteredBy() != null) {
            require(teacherDAO.findById(attendance.getRegisteredBy()) != null, "El profesor indicado no existe.");
        }
        require(!attendanceDAO.existsForStudentSubjectDate(attendance.getStudentId(), attendance.getSubjectId(),
                        attendance.getAttendanceDate()),
                "Ya existe una asistencia para ese estudiante, materia y fecha.");
        attendanceDAO.create(attendance);
    }

    public List<Attendance> getAttendanceForStudent(int studentId, LocalDate from, LocalDate to) {
        getStudent(studentId);
        require(from != null && to != null && !from.isAfter(to), "El rango de fechas no es válido.");
        return attendanceDAO.findByStudentIdAndDateRange(studentId, from, to);
    }
    public List<Attendance> getAllAttendance() { return attendanceDAO.findAll(); }

    private boolean isEnrolledInGrade(int studentId, int gradeId, int academicYear) {
        return enrollmentDAO.findByStudentId(studentId).stream()
                .anyMatch(enrollment -> enrollment.getGradeId() == gradeId
                        && enrollment.getAcademicYear() == academicYear
                        && !("Retirada".equals(enrollment.getStatus())));
    }

    private static void validateEmail(String email) {
        require(EMAIL_PATTERN.matcher(email.trim()).matches(), "El formato del correo electrónico no es válido.");
    }
    private static void requireId(int id, String name) {
        require(id > 0, "El identificador del " + name + " debe ser mayor que cero.");
    }
    private static void requireText(String text, String field) {
        require(hasText(text), field + " es obligatorio.");
    }
    private static boolean hasText(String value) { return value != null && !value.trim().isEmpty(); }
    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalArgumentException(message);
    }
}
