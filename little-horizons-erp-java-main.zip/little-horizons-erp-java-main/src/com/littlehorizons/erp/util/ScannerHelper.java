package com.littlehorizons.erp.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

/**
 * Singleton utility class to manage user console inputs safely.
 * Prevents application crashes from invalid input formats (e.g., entering letters instead of numbers).
 */
public class ScannerHelper {

    private static ScannerHelper instance = null;
    private final Scanner scanner;

    /**
     * Private constructor enforcing the Singleton pattern.
     */
    private ScannerHelper() {
        this.scanner = new Scanner(System.in);
    }

    /**
     * Retrieves the single instance of ScannerHelper.
     *
     * @return ScannerHelper instance
     */
    public static synchronized ScannerHelper getInstance() {
        if (instance == null) {
            instance = new ScannerHelper();
        }
        return instance;
    }

    /**
     * Reads a required non-empty text string from console.
     *
     * @param prompt Message displayed to the user
     * @return Validated trimmed string
     */
    public String readString(String prompt) {
        while (true) {
            System.out.print(prompt + ": ");
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("[!] El valor no puede estar vacio. Intente nuevamente.");
        }
    }

    /**
     * Reads an optional text string from console (can be empty).
     *
     * @param prompt Message displayed to the user
     * @return Trimmed string (or empty if skipped)
     */
    public String readOptionalString(String prompt) {
        System.out.print(prompt + " (Opcional - Enter para omitir): ");
        return scanner.nextLine().trim();
    }

    /**
     * Safely reads an integer from console, catching formatting errors.
     *
     * @param prompt Message displayed to the user
     * @return Valid integer
     */
    public int readInt(String prompt) {
        while (true) {
            System.out.print(prompt + ": ");
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("[!] Entrada invalida. Debe ingresar un numero entero.");
            }
        }
    }

    /**
     * Safely reads an integer constrained within a specific range [min, max].
     *
     * @param prompt Message displayed to the user
     * @param min    Minimum acceptable value
     * @param max    Maximum acceptable value
     * @return Valid integer within range
     */
    public int readInt(String prompt, int min, int max) {
        while (true) {
            int value = readInt(prompt);
            if (value >= min && value <= max) {
                return value;
            }
            System.out.printf("[!] El valor debe estar entre %d y %d. Intente de nuevo.%n", min, max);
        }
    }

    /**
     * Safely reads a decimal number (double) within a specified range [min, max].
     * Automatically handles comma or dot decimal separators.
     *
     * @param prompt Message displayed to the user
     * @param min    Minimum acceptable value
     * @param max    Maximum acceptable value
     * @return Valid double within range
     */
    public double readDouble(String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt + ": ");
            String input = scanner.nextLine().trim().replace(",", ".");
            try {
                double value = Double.parseDouble(input);
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.printf("[!] El valor debe estar entre %.1f y %.1f.%n", min, max);
            } catch (NumberFormatException e) {
                System.out.println("[!] Entrada invalida. Debe ingresar un numero decimal valido.");
            }
        }
    }

    /**
     * Safely reads a date formatted as YYYY-MM-DD.
     *
     * @param prompt Message displayed to the user
     * @return Valid LocalDate object
     */
    public LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt + " (YYYY-MM-DD): ");
            String input = scanner.nextLine().trim();
            try {
                return LocalDate.parse(input);
            } catch (DateTimeParseException e) {
                System.out.println("[!] Formato de fecha invalido. Debe usar el formato AAAA-MM-DD (ej: 2026-03-15).");
            }
        }
    }

    /**
     * Pauses console flow until the user presses Enter.
     */
    public void pressEnterToContinue() {
        System.out.print("\nPresione Enter para continuar...");
        scanner.nextLine();
    }

    /**
     * Closes the underlying scanner instance.
     */
    public void close() {
        if (scanner != null) {
            scanner.close();
        }
    }
}
