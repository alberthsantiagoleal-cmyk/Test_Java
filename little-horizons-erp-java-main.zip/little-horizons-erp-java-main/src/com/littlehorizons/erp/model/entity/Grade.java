package com.littlehorizons.erp.model.entity;

public class Grade {
    private int idGrade;
    private String name;
    private int numericLevel;

    public int getIdGrade() { return idGrade; }
    public void setIdGrade(int idGrade) { this.idGrade = idGrade; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getNumericLevel() { return numericLevel; }
    public void setNumericLevel(int numericLevel) { this.numericLevel = numericLevel; }
}
