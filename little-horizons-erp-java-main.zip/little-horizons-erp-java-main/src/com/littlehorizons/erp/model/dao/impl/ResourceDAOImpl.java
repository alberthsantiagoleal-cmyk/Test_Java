package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IResourceDAO;
import com.littlehorizons.erp.model.entity.Resource;
import com.littlehorizons.erp.model.entity.ResourceCategory;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of IResourceDAO using PreparedStatements.
 */
public class ResourceDAOImpl implements IResourceDAO {

    private static final String BASE_SELECT =
            "SELECT r.id_recurso, r.codigo_recurso, r.nombre_recurso, r.id_categoria, " +
            "       r.descripcion, r.fecha_adquisicion, r.ubicacion_fisica, r.estado_recurso, " +
            "       c.nombre_categoria " +
            "FROM recursos r " +
            "LEFT JOIN categorias_recurso c ON r.id_categoria = c.id_categoria ";

    @Override
    public List<Resource> findAll() {
        String sql = BASE_SELECT + "ORDER BY r.id_recurso ASC";
        List<Resource> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll resources: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar los recursos del inventario.", e);
        }
        return list;
    }

    @Override
    public List<Resource> findAvailable() {
        String sql = BASE_SELECT + "WHERE r.estado_recurso = 'Disponible' ORDER BY r.id_recurso ASC";
        List<Resource> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAvailable resources: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar recursos disponibles.", e);
        }
        return list;
    }

    @Override
    public Resource findById(int idResource) {
        String sql = BASE_SELECT + "WHERE r.id_recurso = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idResource);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById resource [" + idResource + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar recurso por ID.", e);
        }
        return null;
    }

    @Override
    public Resource findByCode(String code) {
        String sql = BASE_SELECT + "WHERE UPPER(r.codigo_recurso) = UPPER(?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, code);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByCode resource [" + code + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar recurso por codigo.", e);
        }
        return null;
    }

    @Override
    public void create(Resource resource) {
        String sql = "INSERT INTO recursos (codigo_recurso, nombre_recurso, id_categoria, descripcion, " +
                     "fecha_adquisicion, ubicacion_fisica, estado_recurso) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, resource.getResourceCode());
            pst.setString(2, resource.getResourceName());
            pst.setInt(3, resource.getIdCategory());
            pst.setString(4, resource.getDescription());

            if (resource.getAcquisitionDate() != null) {
                pst.setDate(5, Date.valueOf(resource.getAcquisitionDate()));
            } else {
                pst.setDate(5, Date.valueOf(java.time.LocalDate.now()));
            }

            pst.setString(6, resource.getPhysicalLocation());
            pst.setString(7, resource.getResourceStatus());

            pst.executeUpdate();

            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    resource.setIdResource(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in create resource: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar el nuevo recurso en la base de datos.", e);
        }
    }

    @Override
    public void updateStatus(int idResource, String newStatus) {
        String sql = "UPDATE recursos SET estado_recurso = ? WHERE id_recurso = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, newStatus);
            pst.setInt(2, idResource);
            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error in updateStatus resource [" + idResource + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al actualizar el estado del recurso.", e);
        }
    }

    @Override
    public List<ResourceCategory> findAllCategories() {
        String sql = "SELECT id_categoria, nombre_categoria, descripcion FROM categorias_recurso ORDER BY id_categoria ASC";
        List<ResourceCategory> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(new ResourceCategory(
                        rs.getInt("id_categoria"),
                        rs.getString("nombre_categoria"),
                        rs.getString("descripcion")
                ));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAllCategories: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar las categorias de recursos.", e);
        }
        return list;
    }

    private Resource mapResultSetToEntity(ResultSet rs) throws SQLException {
        Date acqDate = rs.getDate("fecha_adquisicion");

        Resource resource = new Resource(
                rs.getInt("id_recurso"),
                rs.getString("codigo_recurso"),
                rs.getString("nombre_recurso"),
                rs.getInt("id_categoria"),
                rs.getString("descripcion"),
                acqDate != null ? acqDate.toLocalDate() : null,
                rs.getString("ubicacion_fisica"),
                rs.getString("estado_recurso")
        );

        resource.setCategoryName(rs.getString("nombre_categoria"));
        return resource;
    }
}
