package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Resource;
import com.littlehorizons.erp.model.entity.ResourceCategory;
import java.util.List;

/**
 * Data Access Object interface for Resource and Inventory catalog management.
 */
public interface IResourceDAO {

    /**
     * Lists all resources registered in the school catalog.
     *
     * @return List of all resources
     */
    List<Resource> findAll();

    /**
     * Lists only resources with status 'Disponible'.
     *
     * @return List of available resources
     */
    List<Resource> findAvailable();

    /**
     * Finds a resource by its database ID.
     *
     * @param idResource Resource ID
     * @return Resource entity if found, null otherwise
     */
    Resource findById(int idResource);

    /**
     * Finds a resource by its unique inventory code.
     *
     * @param code Unique inventory code
     * @return Resource entity if found, null otherwise
     */
    Resource findByCode(String code);

    /**
     * Inserts a new resource item into the catalog.
     *
     * @param resource Resource entity to create
     */
    void create(Resource resource);

    /**
     * Updates the status of a resource ('Disponible', 'Prestado', etc.).
     *
     * @param idResource Resource ID
     * @param newStatus  New status string
     */
    void updateStatus(int idResource, String newStatus);

    /**
     * Lists all resource categories available.
     *
     * @return List of categories
     */
    List<ResourceCategory> findAllCategories();
}
