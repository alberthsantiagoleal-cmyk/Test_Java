package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Student;
import java.util.List;

public interface IStudentDAO {
    void create(Student student);
    Student findById(int id);
    List<Student> findAll();
    void update(Student student);
    boolean existsByDocument(String documentNumber);
    void linkGuardian(int studentId, int guardianId, boolean primary, boolean emergencyContact);
}
