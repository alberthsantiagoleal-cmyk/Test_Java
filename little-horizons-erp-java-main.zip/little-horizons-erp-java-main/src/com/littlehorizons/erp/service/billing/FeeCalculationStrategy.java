package com.littlehorizons.erp.service.billing;

/**
 * Strategy interface defining the contract for calculating payment amounts
 * with different pricing and discount policies (Strategy Pattern).
 * Adheres to the Open/Closed Principle (OCP).
 */
public interface FeeCalculationStrategy {

    /**
     * Calculates the final payable amount from the base price.
     *
     * @param baseAmount Base price of the educational concept
     * @return Final amount after applying discount logic
     */
    double calculateFee(double baseAmount);

    /**
     * Gets the user-friendly name of the strategy.
     *
     * @return Strategy name (e.g., "Tarifa Regular", "Descuento por Hermanos")
     */
    String getStrategyName();

    /**
     * Gets the discount percentage applied by this strategy.
     *
     * @return Discount percentage (0.0 to 100.0)
     */
    double getDiscountPercentage();
}
