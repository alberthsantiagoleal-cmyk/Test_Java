package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.TeacherLoan;
import java.time.LocalDate;
import java.util.List;

/**
 * Data Access Object interface for Teacher resource loans.
 * Maps to 'prestamos_profesor' table.
 */
public interface ITeacherLoanDAO {

    void create(TeacherLoan loan);

    TeacherLoan findById(int idLoan);

    List<TeacherLoan> findActiveLoans();

    List<TeacherLoan> findByTeacherId(int idTeacher);

    void registerReturn(int idLoan, LocalDate returnDate);

    List<TeacherLoan> findAll();
}
