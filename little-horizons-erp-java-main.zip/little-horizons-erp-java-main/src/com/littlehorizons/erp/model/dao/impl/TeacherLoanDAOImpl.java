package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.ITeacherLoanDAO;
import com.littlehorizons.erp.model.entity.TeacherLoan;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of ITeacherLoanDAO using PreparedStatements.
 */
public class TeacherLoanDAOImpl implements ITeacherLoanDAO {

    private static final String BASE_SELECT =
            "SELECT p.id_prestamo, p.id_recurso, p.id_profesor, p.fecha_prestamo, " +
            "       p.fecha_devolucion_esperada, p.fecha_devolucion_real, p.estado_prestamo, p.observaciones, " +
            "       r.nombre_recurso, r.codigo_recurso, " +
            "       CONCAT(pr.primer_nombre, ' ', pr.primer_apellido) AS nombre_profesor " +
            "FROM prestamos_profesor p " +
            "LEFT JOIN recursos r ON p.id_recurso = r.id_recurso " +
            "LEFT JOIN profesores pr ON p.id_profesor = pr.id_profesor ";

    @Override
    public void create(TeacherLoan loan) {
        String sql = "INSERT INTO prestamos_profesor (id_recurso, id_profesor, fecha_prestamo, " +
                     "fecha_devolucion_esperada, estado_prestamo, observaciones) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setInt(1, loan.getIdResource());
            pst.setInt(2, loan.getIdTeacher());
            pst.setDate(3, Date.valueOf(loan.getLoanDate()));
            pst.setDate(4, Date.valueOf(loan.getExpectedReturnDate()));
            pst.setString(5, loan.getLoanStatus());
            pst.setString(6, loan.getObservations());

            pst.executeUpdate();

            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    loan.setIdLoan(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in create teacher loan: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar el prestamo a profesor.", e);
        }
    }

    @Override
    public TeacherLoan findById(int idLoan) {
        String sql = BASE_SELECT + "WHERE p.id_prestamo = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idLoan);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById teacher loan [" + idLoan + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar prestamo de profesor por ID.", e);
        }
        return null;
    }

    @Override
    public List<TeacherLoan> findActiveLoans() {
        String sql = BASE_SELECT + "WHERE p.estado_prestamo = 'Activo' ORDER BY p.fecha_devolucion_esperada ASC";
        List<TeacherLoan> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findActiveLoans teacher: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar prestamos activos de profesores.", e);
        }
        return list;
    }

    @Override
    public List<TeacherLoan> findByTeacherId(int idTeacher) {
        String sql = BASE_SELECT + "WHERE p.id_profesor = ? ORDER BY p.fecha_prestamo DESC";
        List<TeacherLoan> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idTeacher);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByTeacherId [" + idTeacher + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar historial de prestamos del profesor.", e);
        }
        return list;
    }

    @Override
    public void registerReturn(int idLoan, LocalDate returnDate) {
        String sql = "UPDATE prestamos_profesor SET fecha_devolucion_real = ?, estado_prestamo = 'Devuelto' " +
                     "WHERE id_prestamo = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setDate(1, Date.valueOf(returnDate));
            pst.setInt(2, idLoan);
            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error in registerReturn teacher loan [" + idLoan + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar la devolucion del recurso por profesor.", e);
        }
    }

    @Override
    public List<TeacherLoan> findAll() {
        String sql = BASE_SELECT + "ORDER BY p.id_prestamo ASC";
        List<TeacherLoan> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll teacher loans: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar los prestamos a profesores.", e);
        }
        return list;
    }

    private TeacherLoan mapResultSetToEntity(ResultSet rs) throws SQLException {
        Date actualRet = rs.getDate("fecha_devolucion_real");

        TeacherLoan loan = new TeacherLoan(
                rs.getInt("id_prestamo"),
                rs.getInt("id_recurso"),
                rs.getInt("id_profesor"),
                rs.getDate("fecha_prestamo").toLocalDate(),
                rs.getDate("fecha_devolucion_esperada").toLocalDate(),
                actualRet != null ? actualRet.toLocalDate() : null,
                rs.getString("estado_prestamo"),
                rs.getString("observaciones")
        );

        loan.setResourceName(rs.getString("nombre_recurso"));
        loan.setResourceCode(rs.getString("codigo_recurso"));
        loan.setTeacherName(rs.getString("nombre_profesor"));
        return loan;
    }
}
