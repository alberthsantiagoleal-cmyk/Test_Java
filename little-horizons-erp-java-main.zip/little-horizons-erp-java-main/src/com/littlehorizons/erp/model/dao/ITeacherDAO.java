package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Teacher;
import java.util.List;

public interface ITeacherDAO {
    void create(Teacher teacher);
    Teacher findById(int id);
    List<Teacher> findAll();
    void update(Teacher teacher);
    boolean existsByDocument(String documentNumber);
    boolean existsByEmail(String email);
}
