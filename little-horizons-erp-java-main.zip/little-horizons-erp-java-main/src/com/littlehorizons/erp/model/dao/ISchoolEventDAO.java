package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.EventParticipant;
import com.littlehorizons.erp.model.entity.SchoolEvent;

import java.util.List;

/**
 * Data Access Object interface for School Events and Event Participants.
 */
public interface ISchoolEventDAO {

    List<SchoolEvent> findAll();

    List<SchoolEvent> findUpcoming();

    SchoolEvent findById(int idEvent);

    void create(SchoolEvent event);

    void update(SchoolEvent event);

    void registerParticipant(EventParticipant participant);

    void updateParticipantRanking(int idParticipation, String rankingPosition, String remarks);

    List<EventParticipant> findParticipantsByEvent(int idEvent);

    List<EventParticipant> findEventsByStudent(int idStudent);

    EventParticipant findParticipation(int idEvent, int idStudent);

    EventParticipant findParticipationById(int idParticipation);
}
