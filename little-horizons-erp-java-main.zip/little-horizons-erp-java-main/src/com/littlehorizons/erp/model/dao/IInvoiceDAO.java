package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Invoice;
import java.util.List;

/**
 * Data Access Object interface for Electronic Invoices.
 * Handles persistence for DIAN-compliant simulated invoice records.
 */
public interface IInvoiceDAO {

    /**
     * Persists an electronic invoice record.
     *
     * @param invoice Invoice entity to create
     */
    void create(Invoice invoice);

    /**
     * Finds an invoice by its internal database ID.
     *
     * @param idInvoice Primary key
     * @return Invoice if found, null otherwise
     */
    Invoice findById(int idInvoice);

    /**
     * Finds an invoice by its official consecutive number (e.g., 'FE-000101').
     *
     * @param invoiceNumber Consecutive invoice number
     * @return Invoice if found, null otherwise
     */
    Invoice findByInvoiceNumber(String invoiceNumber);

    /**
     * Finds the electronic invoice associated with a specific payment.
     *
     * @param idPayment Payment ID
     * @return Invoice if found, null otherwise
     */
    Invoice findByPaymentId(int idPayment);

    /**
     * Retrieves all issued electronic invoices.
     *
     * @return List of all invoices
     */
    List<Invoice> findAll();

    /**
     * Gets the total count of invoices to generate the next consecutive number.
     *
     * @return Count of existing invoices
     */
    int countInvoices();
}
