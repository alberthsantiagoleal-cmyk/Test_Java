package com.littlehorizons.erp.model.entity;

/**
 * Domain entity representing an extracurricular club.
 * Maps to MySQL table 'clubes'.
 */
public class Club {

    private Integer idClub;
    private String clubName;
    private String description;
    private Integer idTeacherSupervisor;
    private int maxCapacity;
    private String meetingSchedule;
    private boolean active;

    // Descriptive attributes from SQL joins
    private String teacherSupervisorName;
    private int activeMembersCount;

    public Club() {
        this.maxCapacity = 30;
        this.active = true;
    }

    public Club(Integer idClub, String clubName, String description, Integer idTeacherSupervisor,
                int maxCapacity, String meetingSchedule, boolean active) {
        this.idClub = idClub;
        this.clubName = clubName;
        this.description = description;
        this.idTeacherSupervisor = idTeacherSupervisor;
        this.maxCapacity = maxCapacity > 0 ? maxCapacity : 30;
        this.meetingSchedule = meetingSchedule;
        this.active = active;
    }

    public Integer getIdClub() {
        return idClub;
    }

    public void setIdClub(Integer idClub) {
        this.idClub = idClub;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getIdTeacherSupervisor() {
        return idTeacherSupervisor;
    }

    public void setIdTeacherSupervisor(Integer idTeacherSupervisor) {
        this.idTeacherSupervisor = idTeacherSupervisor;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public String getMeetingSchedule() {
        return meetingSchedule;
    }

    public void setMeetingSchedule(String meetingSchedule) {
        this.meetingSchedule = meetingSchedule;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getTeacherSupervisorName() {
        return teacherSupervisorName;
    }

    public void setTeacherSupervisorName(String teacherSupervisorName) {
        this.teacherSupervisorName = teacherSupervisorName;
    }

    public int getActiveMembersCount() {
        return activeMembersCount;
    }

    public void setActiveMembersCount(int activeMembersCount) {
        this.activeMembersCount = activeMembersCount;
    }

    public int getAvailableSlots() {
        return Math.max(0, maxCapacity - activeMembersCount);
    }

    public boolean isFull() {
        return activeMembersCount >= maxCapacity;
    }

    @Override
    public String toString() {
        return "Club{" +
                "idClub=" + idClub +
                ", clubName='" + clubName + '\'' +
                ", maxCapacity=" + maxCapacity +
                ", activeMembers=" + activeMembersCount +
                ", schedule='" + meetingSchedule + '\'' +
                ", active=" + active +
                '}';
    }
}
