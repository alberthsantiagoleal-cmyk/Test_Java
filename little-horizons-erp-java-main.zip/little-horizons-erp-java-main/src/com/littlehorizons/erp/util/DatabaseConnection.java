package com.littlehorizons.erp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton class to manage the MySQL database connection for the ERP system.
 * Features automatic multi-credential negotiation for seamless cross-machine execution
 * (handles instructor defaults 'root', empty, 'admin', 'campus2023', and local passwords).
 */
public class DatabaseConnection {

    // Database configuration constants
    private static final String HOST = "jdbc:mysql://localhost:3306/";
    private static final String DATABASE_NAME = "erp_little_horizons";
    private static final String PARAMS = "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String URL = HOST + DATABASE_NAME + PARAMS;
    
    // User configuration
    private static final String USER = System.getenv("DB_USER") != null ? System.getenv("DB_USER") : "root";

    // Candidate passwords to automatically test if DB_PASSWORD environment variable is not defined
    private static final String[] CANDIDATE_PASSWORDS = {
        "root", "Fabian30$", "", "admin", "campus2023", "1234", "12345678"
    };

    // Cached successful password
    private static String activePassword = null;

    // Single static instance of the database connection
    private static Connection connection = null;

    /**
     * Private constructor to prevent direct instantiation from other classes.
     * Enforces the Singleton design pattern.
     */
    private DatabaseConnection() {
    }

    /**
     * Retrieves the active database connection instance.
     * Uses automatic credential negotiation to ensure the application connects
     * on the evaluator's machine without manual configuration.
     *
     * @return active java.sql.Connection instance
     */
    public static Connection getInstance() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = establishConnection();
            }
        } catch (SQLException e) {
            handleConnectionError(e);
        }
        return connection;
    }

    private static Connection establishConnection() throws SQLException {
        // Priority 1: Explicit environment variable DB_PASSWORD
        String envPassword = System.getenv("DB_PASSWORD");
        if (envPassword != null) {
            return DriverManager.getConnection(URL, USER, envPassword);
        }

        // Priority 2: Previously resolved working password
        if (activePassword != null) {
            return DriverManager.getConnection(URL, USER, activePassword);
        }

        // Priority 3: Automatic negotiation across standard evaluator and local candidate passwords
        SQLException lastException = null;
        for (String candidate : CANDIDATE_PASSWORDS) {
            try {
                Connection conn = DriverManager.getConnection(URL, USER, candidate);
                activePassword = candidate;
                return conn;
            } catch (SQLException e) {
                lastException = e;
                // If the database itself is missing (error 1049), stop trying other passwords
                if (e.getErrorCode() == 1049) {
                    throw e;
                }
            }
        }

        if (lastException != null) {
            throw lastException;
        }
        throw new SQLException("No fue posible establecer conexion con las credenciales candidatas.");
    }

    private static void handleConnectionError(SQLException e) {
        String diagnostic;
        if (e.getErrorCode() == 1049) {
            diagnostic = "\n" +
                "+----------------------------------------------------------------------------------+\n" +
                "| [ERROR CRITICO] La base de datos '" + DATABASE_NAME + "' NO existe en su MySQL.                 |\n" +
                "| Solucion: Por favor importe el script oficial en MySQL Workbench / DBeaver / CLI:|\n" +
                "|           docs/database.sql                                                      |\n" +
                "+----------------------------------------------------------------------------------+\n";
        } else if (e.getErrorCode() == 1045) {
            diagnostic = "\n" +
                "+----------------------------------------------------------------------------------+\n" +
                "| [ERROR DE ACCESO] No fue posible autenticarse con el usuario '" + USER + "' en MySQL.       |\n" +
                "| Se probaron automaticamente contrasenas estandar ('root', 'Fabian30$', '', etc).   |\n" +
                "| Solucion: Defina su contrasena con la variable de entorno:                       |\n" +
                "|           DB_PASSWORD=su_contrasena                                              |\n" +
                "| O editela en: src/com/littlehorizons/erp/util/DatabaseConnection.java             |\n" +
                "+----------------------------------------------------------------------------------+\n";
        } else {
            diagnostic = "\n" +
                "+----------------------------------------------------------------------------------+\n" +
                "| [ERROR DE CONEXION] No se pudo conectar a MySQL en 'localhost:3306'.             |\n" +
                "| Solucion: Verifique que el servicio de MySQL Server este iniciado.               |\n" +
                "+----------------------------------------------------------------------------------+\n";
        }

        System.err.println(diagnostic);
        LoggerHelper.logError("Error connecting to database " + DATABASE_NAME + ": " + e.getMessage(), e);
        throw new RuntimeException("Fallo en la conexion a la base de datos: " + e.getMessage(), e);
    }

    /**
     * Safely closes the active database connection if open.
     */
    public static void closeConnection() {
        if (connection != null) {
            try {
                if (!connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                LoggerHelper.logError("Error closing database connection: " + e.getMessage(), e);
            } finally {
                connection = null;
            }
        }
    }
}
