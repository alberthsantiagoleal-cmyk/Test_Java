package com.littlehorizons.erp.util;

/**
 * Utility class providing professional console formatting, ASCII banners,
 * and cross-IDE display compatibility (IntelliJ IDEA & Apache NetBeans).
 */
public class ConsoleUI {

    private ConsoleUI() {
        // Private constructor for utility class
    }

    /**
     * Clears the console screen safely.
     * Uses ProcessBuilder for native terminals, and provides a multi-line fallback
     * for IDE internal consoles like Apache NetBeans.
     */
    public static void clearScreen() {
        try {
            String os = System.getProperty("os.name");
            if (os != null && os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                new ProcessBuilder("clear").inheritIO().start().waitFor();
            }
        } catch (Exception e) {
            // Fallback for Apache NetBeans internal output console
            for (int i = 0; i < 25; i++) {
                System.out.println();
            }
        }
    }

    /**
     * Prints a stylized main header banner in ASCII.
     *
     * @param title Title text to display inside the box
     */
    public static void printMainHeader(String title) {
        System.out.println("\n+==================================================================+");
        System.out.printf("| %-64s |%n", centerText("COLEGIO INTERNACIONAL LITTLE HORIZONS", 64));
        System.out.printf("| %-64s |%n", centerText(title, 64));
        System.out.println("+==================================================================+\n");
    }

    /**
     * Prints a stylized sub-header section banner.
     *
     * @param sectionTitle Title of the current section/module
     */
    public static void printSectionHeader(String sectionTitle) {
        System.out.println("\n--------------------------------------------------------------------");
        System.out.println("  " + sectionTitle.toUpperCase());
        System.out.println("--------------------------------------------------------------------");
    }

    /**
     * Prints a success message with visual confirmation indicator.
     *
     * @param message Success description
     */
    public static void printSuccess(String message) {
        System.out.println("\n[EXITO] " + message);
    }

    /**
     * Prints an error message with warning indicator.
     *
     * @param message Error description
     */
    public static void printError(String message) {
        System.out.println("\n[ERROR] " + message);
    }

    /**
     * Prints a divider line across the console width.
     */
    public static void printDivider() {
        System.out.println("--------------------------------------------------------------------");
    }

    /**
     * Centers a text string within a specified total width.
     *
     * @param text  Text to center
     * @param width Total target width
     * @return Centered string padded with spaces
     */
    private static String centerText(String text, int width) {
        if (text == null || text.length() >= width) {
            return text;
        }
        int padding = (width - text.length()) / 2;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < padding; i++) {
            sb.append(" ");
        }
        sb.append(text);
        while (sb.length() < width) {
            sb.append(" ");
        }
        return sb.toString();
    }
}
