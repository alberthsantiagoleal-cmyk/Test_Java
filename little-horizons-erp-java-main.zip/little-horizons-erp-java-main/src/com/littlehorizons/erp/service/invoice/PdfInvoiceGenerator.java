package com.littlehorizons.erp.service.invoice;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

/**
 * Native, zero-dependency PDF generator producing 100% standard PDF-1.4 documents
 * for DIAN Electronic Invoices.
 * Compatible with all standard PDF viewers and build tools without external JARs.
 */
public class PdfInvoiceGenerator {

    /**
     * DTO containing all data needed to print a complete DIAN electronic invoice.
     */
    public static class InvoiceData {
        public String invoiceNumber;
        public String issueDate;
        public String receiptNumber;
        public String studentName;
        public String studentDocument;
        public String guardianName;
        public String guardianDocument;
        public String conceptCode;
        public String conceptName;
        public String academicPeriod;
        public int academicYear;
        public double baseAmount;
        public double discountAmount;
        public double totalPaid;
        public String paymentMethod;
        public String notes;
        public String cufe;

        public InvoiceData() {
        }
    }

    /**
     * Generates a DIAN Electronic Invoice PDF file on disk.
     *
     * @param data     Invoice data
     * @param destFile Target file (e.g. invoices/factura_FE-000001.pdf)
     * @throws IOException If file writing fails
     */
    public static void generatePdf(InvoiceData data, File destFile) throws IOException {
        if (destFile.getParentFile() != null && !destFile.getParentFile().exists()) {
            destFile.getParentFile().mkdirs();
        }

        // Build the PDF content stream instructions
        String contentStream = buildContentStream(data);
        byte[] contentBytes = contentStream.getBytes(StandardCharsets.ISO_8859_1);

        // We assemble a 6-object PDF-1.4 document
        // Obj 1: Catalog
        // Obj 2: Pages
        // Obj 3: Page (Letter: 612 x 792 pt)
        // Obj 4: Font Helvetica
        // Obj 5: Font Helvetica-Bold
        // Obj 6: Content Stream

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        List<Long> offsets = new ArrayList<>();
        offsets.add(0L); // Object 0 dummy offset

        writeBytes(out, "%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n");

        // Object 1: Catalog
        offsets.add((long) out.size());
        writeBytes(out, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

        // Object 2: Pages
        offsets.add((long) out.size());
        writeBytes(out, "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");

        // Object 3: Page
        offsets.add((long) out.size());
        writeBytes(out, "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] " +
                "/Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> " +
                "/Contents 6 0 R >>\nendobj\n");

        // Object 4: Font Helvetica
        offsets.add((long) out.size());
        writeBytes(out, "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n");

        // Object 5: Font Helvetica-Bold
        offsets.add((long) out.size());
        writeBytes(out, "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj\n");

        // Object 6: Contents
        offsets.add((long) out.size());
        writeBytes(out, "6 0 obj\n<< /Length " + contentBytes.length + " >>\nstream\n");
        out.write(contentBytes);
        writeBytes(out, "\nendstream\nendobj\n");

        // Cross-reference table (xref)
        long xrefOffset = out.size();
        writeBytes(out, "xref\n0 7\n");
        writeBytes(out, "0000000000 65535 f \n");
        for (int i = 1; i <= 6; i++) {
            writeBytes(out, String.format("%010d 00000 n \n", offsets.get(i)));
        }

        // Trailer
        writeBytes(out, "trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n" + xrefOffset + "\n%%EOF\n");

        try (FileOutputStream fos = new FileOutputStream(destFile)) {
            out.writeTo(fos);
        }
    }

    private static void writeBytes(ByteArrayOutputStream out, String s) throws IOException {
        out.write(s.getBytes(StandardCharsets.ISO_8859_1));
    }

    private static String buildContentStream(InvoiceData data) {
        StringBuilder sb = new StringBuilder();

        // 1. Institutional Header Background Box (Navy Blue)
        sb.append("0.11 0.23 0.38 rg\n"); // Navy blue fill
        sb.append("36 680 540 76 re f\n");

        // White text for Header
        sb.append("1.0 1.0 1.0 rg\n");
        sb.append("BT /F2 18 Tf 50 726 Td (COLEGIO LITTLE HORIZONS) Tj ET\n");
        sb.append("BT /F1 9 Tf 50 710 Td (NIT: 900.543.210-9  |  Resolucion DIAN No. 18764000001 de 2024) Tj ET\n");
        sb.append("BT /F1 9 Tf 50 696 Td (Rango Autorizado: FE-000001 a FE-999999  |  Vigencia: 2024-2027) Tj ET\n");
        sb.append("BT /F1 8 Tf 50 684 Td (Calle 127 # 45-20, Bogota D.C.  |  PBX: (601) 745-0000  |  info@littlehorizons.edu.co) Tj ET\n");

        // 2. Invoice Consecutive Box (Right Top Corner, white box with dark border)
        sb.append("1 1 1 rg\n");
        sb.append("390 686 176 64 re f\n");
        sb.append("0.11 0.23 0.38 RG 1.5 w\n");
        sb.append("390 686 176 64 re S\n");

        sb.append("0.11 0.23 0.38 rg\n");
        sb.append("BT /F2 9 Tf 400 734 Td (FACTURA ELECTRONICA DE VENTA) Tj ET\n");
        sb.append("1.0 0.1 0.1 rg\n");
        sb.append("BT /F2 13 Tf 400 718 Td (No. ").append(escapePdf(data.invoiceNumber)).append(") Tj ET\n");
        sb.append("0.2 0.2 0.2 rg\n");
        sb.append("BT /F1 8 Tf 400 704 Td (Fecha Emision: ").append(escapePdf(data.issueDate)).append(") Tj ET\n");
        sb.append("BT /F1 8 Tf 400 692 Td (Recibo Caja: ").append(escapePdf(data.receiptNumber)).append(") Tj ET\n");

        // 3. Customer & Student Information Box
        sb.append("0.95 0.96 0.98 rg\n"); // Light gray background
        sb.append("36 575 540 92 re f\n");
        sb.append("0.75 0.80 0.88 RG 1 w\n");
        sb.append("36 575 540 92 re S\n");

        sb.append("0.11 0.23 0.38 rg\n");
        sb.append("BT /F2 10 Tf 50 650 Td (DATOS DEL ADQUIRIENTE / ESTUDIANTE) Tj ET\n");

        sb.append("0.15 0.15 0.15 rg\n");
        String guardian = data.guardianName != null ? data.guardianName : "Mismo Estudiante / Acudiente Registrado";
        String guardDoc = data.guardianDocument != null ? data.guardianDocument : "N/A";
        sb.append("BT /F2 9 Tf 50 632 Td (Acudiente / Pagador: ) Tj /F1 9 Tf (").append(escapePdf(guardian)).append(") Tj ET\n");
        sb.append("BT /F2 9 Tf 360 632 Td (Doc. Acudiente: ) Tj /F1 9 Tf (").append(escapePdf(guardDoc)).append(") Tj ET\n");

        sb.append("BT /F2 9 Tf 50 614 Td (Estudiante: ) Tj /F1 9 Tf (").append(escapePdf(data.studentName)).append(") Tj ET\n");
        sb.append("BT /F2 9 Tf 360 614 Td (Doc. Estudiante: ) Tj /F1 9 Tf (").append(escapePdf(data.studentDocument)).append(") Tj ET\n");

        sb.append("BT /F2 9 Tf 50 596 Td (Periodo / Ano: ) Tj /F1 9 Tf (Periodo ").append(escapePdf(data.academicPeriod))
                .append(" - ").append(data.academicYear).append(") Tj ET\n");
        sb.append("BT /F2 9 Tf 360 596 Td (Medio de Pago: ) Tj /F1 9 Tf (").append(escapePdf(data.paymentMethod)).append(") Tj ET\n");

        // 4. Items Table Header
        sb.append("0.11 0.23 0.38 rg\n");
        sb.append("36 545 540 22 re f\n");

        sb.append("1 1 1 rg\n");
        sb.append("BT /F2 9 Tf 46 552 Td (ITEM) Tj ET\n");
        sb.append("BT /F2 9 Tf 90 552 Td (DESCRIPCION DEL CONCEPTO) Tj ET\n");
        sb.append("BT /F2 9 Tf 330 552 Td (VALOR BASE) Tj ET\n");
        sb.append("BT /F2 9 Tf 420 552 Td (DESCUENTO) Tj ET\n");
        sb.append("BT /F2 9 Tf 500 552 Td (SUBTOTAL) Tj ET\n");

        // Items Table Row
        sb.append("0.98 0.98 0.98 rg\n");
        sb.append("36 490 540 55 re f\n");
        sb.append("0.8 0.8 0.8 RG 0.5 w\n");
        sb.append("36 490 540 55 re S\n");

        sb.append("0.1 0.1 0.1 rg\n");
        sb.append("BT /F1 9 Tf 46 525 Td (01) Tj ET\n");
        String fullDesc = (data.conceptCode != null ? "[" + data.conceptCode + "] " : "") +
                (data.conceptName != null ? data.conceptName : "Servicio Educativo");
        sb.append("BT /F2 9 Tf 90 525 Td (").append(escapePdf(fullDesc)).append(") Tj ET\n");

        String notesLine = data.notes != null && !data.notes.isBlank() ? "Detalle: " + data.notes : "Servicio educativo regular";
        if (notesLine.length() > 55) notesLine = notesLine.substring(0, 52) + "...";
        sb.append("BT /F1 8 Tf 90 505 Td (").append(escapePdf(notesLine)).append(") Tj ET\n");

        sb.append("BT /F1 9 Tf 330 525 Td ($ ").append(String.format("%,.2f", data.baseAmount)).append(") Tj ET\n");
        sb.append("BT /F1 9 Tf 420 525 Td ($ ").append(String.format("%,.2f", data.discountAmount)).append(") Tj ET\n");
        sb.append("BT /F2 9 Tf 500 525 Td ($ ").append(String.format("%,.2f", data.totalPaid)).append(") Tj ET\n");

        // 5. Totals & Tax Liquidation Box (Right bottom of table)
        sb.append("0.95 0.96 0.98 rg\n");
        sb.append("330 380 246 100 re f\n");
        sb.append("0.75 0.80 0.88 RG 1 w\n");
        sb.append("330 380 246 100 re S\n");

        sb.append("0.15 0.15 0.15 rg\n");
        sb.append("BT /F1 9 Tf 342 460 Td (Subtotal Servicios: ) Tj /F1 9 Tf 480 460 Td ($ ")
                .append(String.format("%,.2f", data.baseAmount)).append(") Tj ET\n");
        sb.append("BT /F1 9 Tf 342 442 Td (Total Descuentos: ) Tj /F1 9 Tf 480 442 Td ($ ")
                .append(String.format("%,.2f", data.discountAmount)).append(") Tj ET\n");
        sb.append("BT /F1 9 Tf 342 424 Td (IVA (0% - Art. 476 ET): ) Tj /F1 9 Tf 480 424 Td ($ 0.00) Tj ET\n");

        sb.append("0.11 0.23 0.38 rg\n");
        sb.append("330 380 246 32 re f\n");
        sb.append("1 1 1 rg\n");
        sb.append("BT /F2 11 Tf 342 392 Td (TOTAL A PAGAR: ) Tj /F2 12 Tf 465 392 Td ($ ")
                .append(String.format("%,.2f", data.totalPaid)).append(" COP) Tj ET\n");

        // 6. Simulated QR Code Graphic Box (Left side at y=380, x=36)
        sb.append(drawSimulatedQrCode(36, 380, 95, data.cufe));

        // QR details note beside QR
        sb.append("0.2 0.2 0.2 rg\n");
        sb.append("BT /F2 8 Tf 140 460 Td (VALIDACION DIAN EN LINEA) Tj ET\n");
        sb.append("BT /F1 7 Tf 140 446 Td (Consulte este documento escaneando) Tj ET\n");
        sb.append("BT /F1 7 Tf 140 436 Td (el codigo QR o verificando el CUFE) Tj ET\n");
        sb.append("BT /F1 7 Tf 140 426 Td (en https://catalogo-vpfe.dian.gov.co) Tj ET\n");
        sb.append("BT /F1 7 Tf 140 408 Td (Servicio exento de IVA segun) Tj ET\n");
        sb.append("BT /F1 7 Tf 140 398 Td (numeral 6, Art. 476 Estatuto Tributario.) Tj ET\n");

        // 7. DIAN Technical Details & CUFE Box (Footer)
        sb.append("0.92 0.94 0.96 rg\n");
        sb.append("36 270 540 96 re f\n");
        sb.append("0.75 0.80 0.88 RG 1 w\n");
        sb.append("36 270 540 96 re S\n");

        sb.append("0.11 0.23 0.38 rg\n");
        sb.append("BT /F2 8 Tf 46 350 Td (CODIGO UNICO DE FACTURA ELECTRONICA (CUFE):) Tj ET\n");

        sb.append("0.1 0.1 0.1 rg\n");
        String cufeStr = data.cufe != null ? data.cufe : "0000000000000000000000000000000000000000000000000000000000000000";
        sb.append("BT /F1 7 Tf 46 338 Td (").append(escapePdf(cufeStr)).append(") Tj ET\n");

        sb.append("0.3 0.3 0.3 rg\n");
        sb.append("BT /F1 7 Tf 46 322 Td (Firma Digital: Little Horizons Education ERP DIAN Module - Algoritmo SHA-256) Tj ET\n");
        sb.append("BT /F1 7 Tf 46 310 Td (Software Propio: Little Horizons ERP v2.0 | Proveedor Tecnologico: Sistema Institucional Certificado) Tj ET\n");
        sb.append("BT /F1 7 Tf 46 296 Td (Documento emitido conforme al Decreto 2242 de 2015 y Resolucion DIAN 000042 de 2020.) Tj ET\n");
        sb.append("BT /F1 7 Tf 46 282 Td (Esta representacion grafica en formato PDF tiene plena validez juridica y probatoria.) Tj ET\n");

        // Bottom page note
        sb.append("0.5 0.5 0.5 rg\n");
        sb.append("BT /F1 7 Tf 170 245 Td (Colegio Little Horizons - Formando lideres con excelencia academica y valores.) Tj ET\n");

        return sb.toString();
    }

    /**
     * Draws a crisp, authentic simulated 2D QR Code matrix barcode using native PDF vector rectangles.
     */
    private static String drawSimulatedQrCode(int startX, int startY, int size, String cufe) {
        StringBuilder sb = new StringBuilder();
        int matrixSize = 21; // Standard Version 1 QR code size
        double cellSize = (double) size / matrixSize;

        // White background box
        sb.append("1 1 1 rg\n");
        sb.append(String.format(java.util.Locale.US, "%d %d %d %d re f\n", startX, startY, size, size));
        sb.append("0.8 0.8 0.8 RG 0.5 w\n");
        sb.append(String.format(java.util.Locale.US, "%d %d %d %d re S\n", startX, startY, size, size));

        // Black cells
        sb.append("0 0 0 rg\n");

        boolean[][] grid = new boolean[matrixSize][matrixSize];

        // Draw 3 position detection patterns (corners)
        drawFinderPattern(grid, 0, 0);
        drawFinderPattern(grid, 0, matrixSize - 7);
        drawFinderPattern(grid, matrixSize - 7, 0);

        // Fill data cells deterministically based on CUFE string
        int hash = (cufe != null ? cufe : "littlehorizons").hashCode();
        for (int r = 0; r < matrixSize; r++) {
            for (int c = 0; c < matrixSize; c++) {
                if (isFinderArea(r, c, matrixSize)) continue;
                // Pseudo-random deterministic bit
                int bit = ((hash ^ (r * 31 + c * 17)) >>> ((r + c) % 24)) & 1;
                grid[r][c] = (bit == 1);
            }
        }

        // Output rectangles for true cells
        for (int r = 0; r < matrixSize; r++) {
            for (int c = 0; c < matrixSize; c++) {
                if (grid[r][c]) {
                    double x = startX + c * cellSize;
                    double y = startY + (matrixSize - 1 - r) * cellSize;
                    sb.append(String.format(java.util.Locale.US, "%.2f %.2f %.2f %.2f re f\n", x, y, cellSize, cellSize));
                }
            }
        }

        return sb.toString();
    }

    private static void drawFinderPattern(boolean[][] grid, int startR, int startC) {
        for (int r = 0; r < 7; r++) {
            for (int c = 0; c < 7; c++) {
                if (r == 0 || r == 6 || c == 0 || c == 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4)) {
                    grid[startR + r][startC + c] = true;
                }
            }
        }
    }

    private static boolean isFinderArea(int r, int c, int size) {
        if (r < 8 && c < 8) return true;
        if (r < 8 && c >= size - 8) return true;
        if (r >= size - 8 && c < 8) return true;
        return false;
    }

    private static String escapePdf(String s) {
        if (s == null) return "";
        // Clean accents to ASCII for Helvetica standard font
        String normalized = Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
        return normalized.replace("\\", "\\\\")
                         .replace("(", "\\(")
                         .replace(")", "\\)");
    }
}
