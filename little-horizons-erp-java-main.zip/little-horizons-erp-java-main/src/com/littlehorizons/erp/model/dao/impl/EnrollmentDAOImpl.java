package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IEnrollmentDAO;
import com.littlehorizons.erp.model.entity.Enrollment;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAOImpl implements IEnrollmentDAO {
    private static final String COLUMNS = "id_matricula, id_estudiante, id_grado, `año_academico`, estado_matricula, "
            + "fecha_matricula, fecha_retiro, observaciones";

    @Override
    public void create(Enrollment enrollment) {
        String sql = "INSERT INTO matriculas (id_estudiante, id_grado, `año_academico`, estado_matricula, "
                + "fecha_matricula, fecha_retiro, observaciones) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, enrollment, 1);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) enrollment.setIdEnrollment(keys.getInt(1));
            }
        } catch (SQLException e) {
            throw failure("Error al registrar matrícula.", e);
        }
    }

    @Override
    public List<Enrollment> findAll() {
        return list("SELECT " + COLUMNS + " FROM matriculas ORDER BY `año_academico` DESC, id_estudiante", null);
    }

    @Override
    public List<Enrollment> findByStudentId(int studentId) {
        return list("SELECT " + COLUMNS + " FROM matriculas WHERE id_estudiante=? ORDER BY `año_academico` DESC", studentId);
    }

    @Override
    public boolean existsForStudentAndYear(int studentId, int academicYear) {
        String sql = "SELECT 1 FROM matriculas WHERE id_estudiante=? AND `año_academico`=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setInt(2, academicYear);
            try (ResultSet rs = statement.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            throw failure("Error al validar matrícula existente.", e);
        }
    }

    private List<Enrollment> list(String sql, Integer studentId) {
        List<Enrollment> enrollments = new ArrayList<>();
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            if (studentId != null) statement.setInt(1, studentId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) enrollments.add(map(rs));
            }
            return enrollments;
        } catch (SQLException e) {
            throw failure("Error al consultar matrículas.", e);
        }
    }

    private void bind(PreparedStatement statement, Enrollment enrollment, int index) throws SQLException {
        statement.setInt(index++, enrollment.getStudentId());
        statement.setInt(index++, enrollment.getGradeId());
        statement.setInt(index++, enrollment.getAcademicYear());
        statement.setString(index++, enrollment.getStatus() == null ? "Activa" : enrollment.getStatus());
        statement.setDate(index++, Date.valueOf(enrollment.getEnrollmentDate()));
        if (enrollment.getWithdrawalDate() == null) statement.setNull(index++, java.sql.Types.DATE);
        else statement.setDate(index++, Date.valueOf(enrollment.getWithdrawalDate()));
        statement.setString(index, enrollment.getObservations());
    }

    private Enrollment map(ResultSet rs) throws SQLException {
        Enrollment enrollment = new Enrollment();
        enrollment.setIdEnrollment(rs.getInt("id_matricula"));
        enrollment.setStudentId(rs.getInt("id_estudiante"));
        enrollment.setGradeId(rs.getInt("id_grado"));
        enrollment.setAcademicYear(rs.getInt("año_academico"));
        enrollment.setStatus(rs.getString("estado_matricula"));
        enrollment.setEnrollmentDate(rs.getDate("fecha_matricula").toLocalDate());
        Date withdrawalDate = rs.getDate("fecha_retiro");
        enrollment.setWithdrawalDate(withdrawalDate == null ? null : withdrawalDate.toLocalDate());
        enrollment.setObservations(rs.getString("observaciones"));
        return enrollment;
    }

    private Connection connection() { return DatabaseConnection.getInstance(); }
    private RuntimeException failure(String message, SQLException cause) {
        LoggerHelper.logError(message, cause);
        return new RuntimeException(message, cause);
    }
}
