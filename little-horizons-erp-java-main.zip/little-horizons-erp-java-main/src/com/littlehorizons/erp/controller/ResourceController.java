package com.littlehorizons.erp.controller;

import com.littlehorizons.erp.model.dao.IResourceDAO;
import com.littlehorizons.erp.model.dao.IStudentLoanDAO;
import com.littlehorizons.erp.model.dao.ITeacherLoanDAO;
import com.littlehorizons.erp.model.dao.impl.ResourceDAOImpl;
import com.littlehorizons.erp.model.dao.impl.StudentLoanDAOImpl;
import com.littlehorizons.erp.model.dao.impl.TeacherLoanDAOImpl;
import com.littlehorizons.erp.model.entity.*;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Controller orchestrating business logic and inventory lifecycle for resources and loans.
 * Adheres to Dependency Inversion (DIP) and Single Responsibility (SRP).
 */
public class ResourceController {

    private final IResourceDAO resourceDAO;
    private final IStudentLoanDAO studentLoanDAO;
    private final ITeacherLoanDAO teacherLoanDAO;

    public ResourceController() {
        this(new ResourceDAOImpl(), new StudentLoanDAOImpl(), new TeacherLoanDAOImpl());
    }

    public ResourceController(IResourceDAO resourceDAO, IStudentLoanDAO studentLoanDAO, ITeacherLoanDAO teacherLoanDAO) {
        this.resourceDAO = resourceDAO;
        this.studentLoanDAO = studentLoanDAO;
        this.teacherLoanDAO = teacherLoanDAO;
    }

    public List<Resource> getAllResources() {
        return resourceDAO.findAll();
    }

    public List<Resource> getAvailableResources() {
        return resourceDAO.findAvailable();
    }

    public List<ResourceCategory> getAllCategories() {
        return resourceDAO.findAllCategories();
    }

    public Resource getResourceById(int idResource) {
        Resource resource = resourceDAO.findById(idResource);
        if (resource == null) {
            throw new IllegalArgumentException("Recurso no encontrado con ID: " + idResource);
        }
        return resource;
    }

    /**
     * Registers a new resource in the inventory.
     */
    public Resource registerResource(String code, String name, int idCategory, String description,
                                     String location) {
        if (code == null || code.isBlank()) {
            throw new IllegalArgumentException("El codigo del recurso no puede estar vacio.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("El nombre del recurso no puede estar vacio.");
        }
        if (idCategory <= 0) {
            throw new IllegalArgumentException("Debe seleccionar una categoria valida.");
        }

        Resource existing = resourceDAO.findByCode(code.trim());
        if (existing != null) {
            throw new IllegalArgumentException("Ya existe un recurso con el codigo: " + code);
        }

        Resource resource = new Resource(
                null,
                code.trim().toUpperCase(),
                name.trim(),
                idCategory,
                description,
                LocalDate.now(),
                location != null ? location.trim() : "Biblioteca",
                "Disponible"
        );

        resourceDAO.create(resource);
        return resource;
    }

    /**
     * Loans a resource to a student.
     * Validates that the resource is currently 'Disponible' and marks it as 'Prestado'.
     */
    public StudentLoan loanToStudent(int idResource, int idStudent, LocalDate expectedReturnDate, String observations) {
        if (idStudent <= 0) {
            throw new IllegalArgumentException("ID de estudiante invalido.");
        }
        if (expectedReturnDate == null || expectedReturnDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha estimada de devolucion debe ser hoy o una fecha futura.");
        }

        Resource resource = getResourceById(idResource);
        if (!"Disponible".equalsIgnoreCase(resource.getResourceStatus())) {
            throw new IllegalStateException("El recurso '" + resource.getResourceName() + 
                    "' no esta disponible. Estado actual: " + resource.getResourceStatus());
        }

        StudentLoan loan = new StudentLoan(
                null,
                idResource,
                idStudent,
                LocalDate.now(),
                expectedReturnDate,
                null,
                "Activo",
                observations
        );

        studentLoanDAO.create(loan);
        resourceDAO.updateStatus(idResource, "Prestado");
        return loan;
    }

    /**
     * Loans a resource to a teacher.
     * Validates that the resource is currently 'Disponible' and marks it as 'Prestado'.
     */
    public TeacherLoan loanToTeacher(int idResource, int idTeacher, LocalDate expectedReturnDate, String observations) {
        if (idTeacher <= 0) {
            throw new IllegalArgumentException("ID de profesor invalido.");
        }
        if (expectedReturnDate == null || expectedReturnDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha estimada de devolucion debe ser hoy o una fecha futura.");
        }

        Resource resource = getResourceById(idResource);
        if (!"Disponible".equalsIgnoreCase(resource.getResourceStatus())) {
            throw new IllegalStateException("El recurso '" + resource.getResourceName() + 
                    "' no esta disponible. Estado actual: " + resource.getResourceStatus());
        }

        TeacherLoan loan = new TeacherLoan(
                null,
                idResource,
                idTeacher,
                LocalDate.now(),
                expectedReturnDate,
                null,
                "Activo",
                observations
        );

        teacherLoanDAO.create(loan);
        resourceDAO.updateStatus(idResource, "Prestado");
        return loan;
    }

    /**
     * Registers return of a resource by a student.
     * Marks the loan as 'Devuelto' and updates resource back to 'Disponible'.
     */
    public void returnStudentLoan(int idLoan) {
        StudentLoan loan = studentLoanDAO.findById(idLoan);
        if (loan == null) {
            throw new IllegalArgumentException("Prestamo de estudiante no encontrado con ID: " + idLoan);
        }
        if ("Devuelto".equalsIgnoreCase(loan.getLoanStatus())) {
            throw new IllegalStateException("Este prestamo ya fue devuelto con fecha: " + loan.getActualReturnDate());
        }

        studentLoanDAO.registerReturn(idLoan, LocalDate.now());
        resourceDAO.updateStatus(loan.getIdResource(), "Disponible");
    }

    /**
     * Registers return of a resource by a teacher.
     * Marks the loan as 'Devuelto' and updates resource back to 'Disponible'.
     */
    public void returnTeacherLoan(int idLoan) {
        TeacherLoan loan = teacherLoanDAO.findById(idLoan);
        if (loan == null) {
            throw new IllegalArgumentException("Prestamo de profesor no encontrado con ID: " + idLoan);
        }
        if ("Devuelto".equalsIgnoreCase(loan.getLoanStatus())) {
            throw new IllegalStateException("Este prestamo ya fue devuelto con fecha: " + loan.getActualReturnDate());
        }

        teacherLoanDAO.registerReturn(idLoan, LocalDate.now());
        resourceDAO.updateStatus(loan.getIdResource(), "Disponible");
    }

    /**
     * Retrieves all overdue loans combining students and teachers.
     * Applies Java Stream API (Lambdas) to filter and sort overdue items.
     *
     * @return List of overdue Loan objects
     */
    public List<Loan> getOverdueLoans() {
        List<StudentLoan> studentActive = studentLoanDAO.findActiveLoans();
        List<TeacherLoan> teacherActive = teacherLoanDAO.findActiveLoans();

        return Stream.concat(studentActive.stream(), teacherActive.stream())
                .filter(Loan::isOverdue)
                .sorted(Comparator.comparing(Loan::getExpectedReturnDate))
                .collect(Collectors.toList());
    }

    public List<StudentLoan> getActiveStudentLoans() {
        return studentLoanDAO.findActiveLoans();
    }

    public List<TeacherLoan> getActiveTeacherLoans() {
        return teacherLoanDAO.findActiveLoans();
    }
}
