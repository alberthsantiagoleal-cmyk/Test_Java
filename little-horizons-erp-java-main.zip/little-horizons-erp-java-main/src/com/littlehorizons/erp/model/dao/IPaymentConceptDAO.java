package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.PaymentConcept;
import java.util.List;

/**
 * Data Access Object interface for Payment Concept operations.
 * Defines the contract adhering to the Interface Segregation Principle (ISP).
 */
public interface IPaymentConceptDAO {

    /**
     * Retrieves all payment concepts registered in the catalog.
     *
     * @return List of all payment concepts
     */
    List<PaymentConcept> findAll();

    /**
     * Retrieves all active payment concepts available for charging.
     *
     * @return List of active payment concepts
     */
    List<PaymentConcept> findAllActive();

    /**
     * Finds a payment concept by its primary key.
     *
     * @param idConcept Primary key ID
     * @return PaymentConcept if found, null otherwise
     */
    PaymentConcept findById(int idConcept);

    /**
     * Finds a payment concept by its unique code (e.g., 'MAT', 'PENSION').
     *
     * @param code Concept code
     * @return PaymentConcept if found, null otherwise
     */
    PaymentConcept findByCode(String code);

    /**
     * Inserts a new payment concept into the database.
     *
     * @param concept Concept to persist
     */
    void create(PaymentConcept concept);

    /**
     * Updates an existing payment concept.
     *
     * @param concept Concept with modified fields
     */
    void update(PaymentConcept concept);
}
