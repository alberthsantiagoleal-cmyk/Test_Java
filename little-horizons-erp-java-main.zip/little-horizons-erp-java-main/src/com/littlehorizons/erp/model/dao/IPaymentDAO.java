package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Payment;
import java.util.List;

/**
 * Data Access Object interface for Payment management.
 * Adheres to Interface Segregation Principle (ISP) and Dependency Inversion Principle (DIP).
 */
public interface IPaymentDAO {

    /**
     * Persists a new payment transaction into the database.
     *
     * @param payment Payment entity to persist
     */
    void create(Payment payment);

    /**
     * Finds a payment by its primary key ID.
     *
     * @param idPayment Primary key
     * @return Payment if found, null otherwise
     */
    Payment findById(int idPayment);

    /**
     * Finds a payment by its unique receipt number.
     *
     * @param receiptNumber Unique receipt number (e.g., 'REC-2026-0001')
     * @return Payment if found, null otherwise
     */
    Payment findByReceiptNumber(String receiptNumber);

    /**
     * Retrieves all payments associated with a specific student.
     *
     * @param idStudent Student ID
     * @return List of payments
     */
    List<Payment> findByStudentId(int idStudent);

    /**
     * Retrieves all payments associated with a specific guardian (for families with multiple students).
     *
     * @param idGuardian Guardian ID
     * @return List of payments made by this guardian
     */
    List<Payment> findByGuardianId(int idGuardian);

    /**
     * Retrieves all payment records across the institution.
     *
     * @return List of all payments
     */
    List<Payment> findAll();
}
