package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Domain entity representing an institutional or extracurricular event.
 * Maps to MySQL table 'eventos'.
 */
public class SchoolEvent {

    private Integer idEvent;
    private String eventName;
    private String description;
    private String eventType; // 'Academico', 'Cultural', 'Deportivo', 'Social', 'Cientifico'
    private LocalDate eventDate;
    private String location;
    private boolean hasCompetition;
    private Integer idOrganizer;
    private boolean active;

    // Descriptive attributes from SQL joins
    private String organizerName;
    private int participantCount;

    public SchoolEvent() {
        this.active = true;
    }

    public SchoolEvent(Integer idEvent, String eventName, String description, String eventType,
                       LocalDate eventDate, String location, boolean hasCompetition,
                       Integer idOrganizer, boolean active) {
        this.idEvent = idEvent;
        this.eventName = eventName;
        this.description = description;
        this.eventType = eventType;
        this.eventDate = eventDate;
        this.location = location;
        this.hasCompetition = hasCompetition;
        this.idOrganizer = idOrganizer;
        this.active = active;
    }

    public Integer getIdEvent() {
        return idEvent;
    }

    public void setIdEvent(Integer idEvent) {
        this.idEvent = idEvent;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public LocalDate getEventDate() {
        return eventDate;
    }

    public void setEventDate(LocalDate eventDate) {
        this.eventDate = eventDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isHasCompetition() {
        return hasCompetition;
    }

    public void setHasCompetition(boolean hasCompetition) {
        this.hasCompetition = hasCompetition;
    }

    public Integer getIdOrganizer() {
        return idOrganizer;
    }

    public void setIdOrganizer(Integer idOrganizer) {
        this.idOrganizer = idOrganizer;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getOrganizerName() {
        return organizerName;
    }

    public void setOrganizerName(String organizerName) {
        this.organizerName = organizerName;
    }

    public int getParticipantCount() {
        return participantCount;
    }

    public void setParticipantCount(int participantCount) {
        this.participantCount = participantCount;
    }

    @Override
    public String toString() {
        return "SchoolEvent{" +
                "idEvent=" + idEvent +
                ", eventName='" + eventName + '\'' +
                ", eventType='" + eventType + '\'' +
                ", eventDate=" + eventDate +
                ", location='" + location + '\'' +
                ", competition=" + hasCompetition +
                ", active=" + active +
                '}';
    }
}
