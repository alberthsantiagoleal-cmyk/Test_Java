package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Subject;
import java.util.List;

public interface ISubjectDAO {
    void create(Subject subject);
    Subject findById(int id);
    List<Subject> findAll();
    List<Subject> findByGradeId(int gradeId);
    void update(Subject subject);
}
