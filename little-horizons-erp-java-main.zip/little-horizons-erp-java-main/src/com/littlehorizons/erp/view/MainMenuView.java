package com.littlehorizons.erp.view;

import com.littlehorizons.erp.util.ConsoleUI;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.ScannerHelper;

/**
 * Main console view for the Little Horizons ERP System.
 * Coordinates module navigation following the MVC pattern.
 */
public class MainMenuView {

    private final ScannerHelper scannerHelper;

    private final AcademicView academicView;
    private final FinancialView financialView;
    private final ResourceView resourceView;
    private final ExtracurricularView extracurricularView;

    public MainMenuView() {
        this.scannerHelper = ScannerHelper.getInstance();
        this.academicView = new AcademicView();
        this.financialView = new FinancialView();
        this.resourceView = new ResourceView();
        this.extracurricularView = new ExtracurricularView();
    }

    /**
     * Displays the main menu loop and dispatches user actions to corresponding views.
     */
    public void displayMainMenu() {
        int option = -1;

        while (option != 8) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("SISTEMA DE PLANIFICACION DE RECURSOS (ERP)");

            System.out.println("  1. Gestion de Estudiantes y Acudientes");
            System.out.println("  2. Gestion Academica (Materias, Notas y Asistencia)");
            System.out.println("  3. Gestion de Profesores y Carga Academica");
            System.out.println("  4. Actividades Extracurriculares (Clubes y Eventos)");
            System.out.println("  5. Gestion Financiera y Facturacion DIAN");
            System.out.println("  6. Gestion de Recursos (Biblioteca y Laboratorios)");
            System.out.println("  7. Reportes y Estadisticas del Sistema");
            System.out.println("  8. Salir");
            ConsoleUI.printDivider();

            option = scannerHelper.readInt("Seleccione una opcion", 1, 8);

            switch (option) {
                case 1 -> academicView.displayStudentsMenu();
                case 2 -> academicView.displayAcademicMenu();
                case 3 -> academicView.displayTeachersMenu();
                case 4 -> extracurricularView.displayMenu();
                case 5 -> financialView.displayMenu();
                case 6 -> resourceView.displayMenu();
                case 7 -> displayReportsMenu();
                case 8 -> exitApplication();
            }
        }
    }

    private void displayReportsMenu() {
        int option = -1;
        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("REPORTES Y ESTADISTICAS DEL SISTEMA");
            System.out.println("  1. Reportes Academicos (Promedios, Cursos y Asistencia - Stream API)");
            System.out.println("  2. Reporte de Prestamos Vencidos en Mora (Biblioteca y Laboratorios)");
            System.out.println("  3. Reporte de Clubes con Alta Ocupacion (>= 80% Cupo)");
            System.out.println("  4. Facturas Electronicas DIAN Emitidas");
            System.out.println("  0. Regresar al Menu Principal");
            ConsoleUI.printDivider();

            option = scannerHelper.readInt("Seleccione una opcion", 0, 4);

            switch (option) {
                case 1 -> academicView.displayReports();
                case 2 -> resourceView.showOverdueLoansReport();
                case 3 -> extracurricularView.showClubsNearCapacityReport();
                case 4 -> financialView.listAllInvoices();
                case 0 -> System.out.println("\nRegresando al menu principal...");
            }
        }
    }

    private void exitApplication() {
        ConsoleUI.clearScreen();
        System.out.println("\nCerrando conexiones y saliendo del sistema...");
        DatabaseConnection.closeConnection();
        scannerHelper.close();
        System.out.println("Gracias por utilizar el ERP del Colegio Little Horizons!");
    }
}
