package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IPaymentConceptDAO;
import com.littlehorizons.erp.model.entity.PaymentConcept;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of IPaymentConceptDAO using PreparedStatements.
 * Ensures SQL injection prevention and safe resource management with try-with-resources.
 */
public class PaymentConceptDAOImpl implements IPaymentConceptDAO {

    @Override
    public List<PaymentConcept> findAll() {
        String sql = "SELECT id_concepto, codigo_concepto, nombre_concepto, descripcion, monto_base, es_recurrente, esta_activo " +
                     "FROM conceptos_pago ORDER BY id_concepto ASC";
        List<PaymentConcept> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll payment concepts: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar conceptos de pago.", e);
        }
        return list;
    }

    @Override
    public List<PaymentConcept> findAllActive() {
        String sql = "SELECT id_concepto, codigo_concepto, nombre_concepto, descripcion, monto_base, es_recurrente, esta_activo " +
                     "FROM conceptos_pago WHERE esta_activo = TRUE ORDER BY id_concepto ASC";
        List<PaymentConcept> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAllActive payment concepts: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar conceptos de pago activos.", e);
        }
        return list;
    }

    @Override
    public PaymentConcept findById(int idConcept) {
        String sql = "SELECT id_concepto, codigo_concepto, nombre_concepto, descripcion, monto_base, es_recurrente, esta_activo " +
                     "FROM conceptos_pago WHERE id_concepto = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idConcept);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById payment concept [" + idConcept + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar concepto de pago por ID.", e);
        }
        return null;
    }

    @Override
    public PaymentConcept findByCode(String code) {
        String sql = "SELECT id_concepto, codigo_concepto, nombre_concepto, descripcion, monto_base, es_recurrente, esta_activo " +
                     "FROM conceptos_pago WHERE UPPER(codigo_concepto) = UPPER(?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, code);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByCode payment concept [" + code + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar concepto de pago por codigo.", e);
        }
        return null;
    }

    @Override
    public void create(PaymentConcept concept) {
        String sql = "INSERT INTO conceptos_pago (codigo_concepto, nombre_concepto, descripcion, monto_base, es_recurrente, esta_activo) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, concept.getConceptCode());
            pst.setString(2, concept.getConceptName());
            pst.setString(3, concept.getDescription());
            pst.setDouble(4, concept.getBaseAmount());
            pst.setBoolean(5, concept.isRecurring());
            pst.setBoolean(6, concept.isActive());

            pst.executeUpdate();

            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    concept.setIdConcept(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in create payment concept: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar nuevo concepto de pago.", e);
        }
    }

    @Override
    public void update(PaymentConcept concept) {
        String sql = "UPDATE conceptos_pago SET nombre_concepto = ?, descripcion = ?, monto_base = ?, " +
                     "es_recurrente = ?, esta_activo = ? WHERE id_concepto = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, concept.getConceptName());
            pst.setString(2, concept.getDescription());
            pst.setDouble(3, concept.getBaseAmount());
            pst.setBoolean(4, concept.isRecurring());
            pst.setBoolean(5, concept.isActive());
            pst.setInt(6, concept.getIdConcept());

            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error in update payment concept: " + e.getMessage(), e);
            throw new RuntimeException("Error al actualizar concepto de pago.", e);
        }
    }

    private PaymentConcept mapResultSetToEntity(ResultSet rs) throws SQLException {
        return new PaymentConcept(
                rs.getInt("id_concepto"),
                rs.getString("codigo_concepto"),
                rs.getString("nombre_concepto"),
                rs.getString("descripcion"),
                rs.getDouble("monto_base"),
                rs.getBoolean("es_recurrente"),
                rs.getBoolean("esta_activo")
        );
    }
}
