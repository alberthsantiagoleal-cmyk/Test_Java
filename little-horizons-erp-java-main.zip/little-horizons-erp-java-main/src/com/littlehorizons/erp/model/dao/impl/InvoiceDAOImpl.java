package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IInvoiceDAO;
import com.littlehorizons.erp.model.entity.Invoice;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of IInvoiceDAO for electronic invoices.
 */
public class InvoiceDAOImpl implements IInvoiceDAO {

    @Override
    public void create(Invoice invoice) {
        String sql = "INSERT INTO facturas (numero_factura, id_pago, fecha_emision, cufe, nombre_archivo_pdf, ruta_archivo) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, invoice.getInvoiceNumber());
            pst.setInt(2, invoice.getIdPayment());
            pst.setDate(3, Date.valueOf(invoice.getIssueDate()));
            pst.setString(4, invoice.getCufe());
            pst.setString(5, invoice.getPdfFileName());
            pst.setString(6, invoice.getFilePath());

            pst.executeUpdate();

            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    invoice.setIdInvoice(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in create invoice: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar la factura electronica.", e);
        }
    }

    @Override
    public Invoice findById(int idInvoice) {
        String sql = "SELECT id_factura, numero_factura, id_pago, fecha_emision, cufe, nombre_archivo_pdf, ruta_archivo " +
                     "FROM facturas WHERE id_factura = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idInvoice);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById invoice [" + idInvoice + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar factura por ID.", e);
        }
        return null;
    }

    @Override
    public Invoice findByInvoiceNumber(String invoiceNumber) {
        String sql = "SELECT id_factura, numero_factura, id_pago, fecha_emision, cufe, nombre_archivo_pdf, ruta_archivo " +
                     "FROM facturas WHERE numero_factura = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, invoiceNumber);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByInvoiceNumber [" + invoiceNumber + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar factura por numero consecutivo.", e);
        }
        return null;
    }

    @Override
    public Invoice findByPaymentId(int idPayment) {
        String sql = "SELECT id_factura, numero_factura, id_pago, fecha_emision, cufe, nombre_archivo_pdf, ruta_archivo " +
                     "FROM facturas WHERE id_pago = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idPayment);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByPaymentId [" + idPayment + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar factura por ID de pago.", e);
        }
        return null;
    }

    @Override
    public List<Invoice> findAll() {
        String sql = "SELECT id_factura, numero_factura, id_pago, fecha_emision, cufe, nombre_archivo_pdf, ruta_archivo " +
                     "FROM facturas ORDER BY id_factura ASC";
        List<Invoice> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll invoices: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar facturas electrónicas.", e);
        }
        return list;
    }

    @Override
    public int countInvoices() {
        String sql = "SELECT COUNT(*) FROM facturas";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in countInvoices: " + e.getMessage(), e);
        }
        return 0;
    }

    private Invoice mapResultSetToEntity(ResultSet rs) throws SQLException {
        return new Invoice(
                rs.getInt("id_factura"),
                rs.getString("numero_factura"),
                rs.getInt("id_pago"),
                rs.getDate("fecha_emision").toLocalDate(),
                rs.getString("cufe"),
                rs.getString("nombre_archivo_pdf"),
                rs.getString("ruta_archivo")
        );
    }
}
