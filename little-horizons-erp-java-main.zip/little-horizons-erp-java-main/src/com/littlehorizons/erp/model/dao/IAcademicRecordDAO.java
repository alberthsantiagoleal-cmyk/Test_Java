package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.AcademicRecord;
import java.util.List;

public interface IAcademicRecordDAO {
    void create(AcademicRecord record);
    List<AcademicRecord> findAll();
    List<AcademicRecord> findByStudentId(int studentId);
    boolean existsForStudentSubjectYearPeriod(int studentId, int subjectId, int year, String period);
}
