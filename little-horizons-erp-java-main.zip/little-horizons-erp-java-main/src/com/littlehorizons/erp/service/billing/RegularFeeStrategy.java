package com.littlehorizons.erp.service.billing;

/**
 * Strategy representing standard full payment with 0% discount.
 */
public class RegularFeeStrategy implements FeeCalculationStrategy {

    @Override
    public double calculateFee(double baseAmount) {
        return Math.max(0.0, baseAmount);
    }

    @Override
    public String getStrategyName() {
        return "Tarifa Regular (Sin Descuento)";
    }

    @Override
    public double getDiscountPercentage() {
        return 0.0;
    }
}
