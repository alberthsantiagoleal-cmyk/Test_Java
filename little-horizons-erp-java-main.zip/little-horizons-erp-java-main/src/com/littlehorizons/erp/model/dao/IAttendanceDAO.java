package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Attendance;
import java.time.LocalDate;
import java.util.List;

public interface IAttendanceDAO {
    void create(Attendance attendance);
    List<Attendance> findAll();
    List<Attendance> findByStudentIdAndDateRange(int studentId, LocalDate from, LocalDate to);
    boolean existsForStudentSubjectDate(int studentId, int subjectId, LocalDate date);
}
