package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IAcademicRecordDAO;
import com.littlehorizons.erp.model.entity.AcademicRecord;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AcademicRecordDAOImpl implements IAcademicRecordDAO {
    private static final String COLUMNS = "id_registro, id_estudiante, id_materia, id_profesor, `año_academico`, "
            + "periodo_academico, valor_nota, observaciones, fecha_registro";

    @Override
    public void create(AcademicRecord record) {
        String sql = "INSERT INTO registros_academicos (id_estudiante, id_materia, id_profesor, `año_academico`, "
                + "periodo_academico, valor_nota, observaciones, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, record, 1);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) record.setIdRecord(keys.getInt(1));
            }
        } catch (SQLException e) {
            throw failure("Error al registrar calificación.", e);
        }
    }

    @Override
    public List<AcademicRecord> findAll() {
        return list("SELECT " + COLUMNS + " FROM registros_academicos ORDER BY `año_academico` DESC, periodo_academico", null);
    }

    @Override
    public List<AcademicRecord> findByStudentId(int studentId) {
        return list("SELECT " + COLUMNS + " FROM registros_academicos WHERE id_estudiante=? "
                + "ORDER BY `año_academico` DESC, periodo_academico, id_materia", studentId);
    }

    @Override
    public boolean existsForStudentSubjectYearPeriod(int studentId, int subjectId, int year, String period) {
        String sql = "SELECT 1 FROM registros_academicos WHERE id_estudiante=? AND id_materia=? "
                + "AND `año_academico`=? AND periodo_academico=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setInt(2, subjectId);
            statement.setInt(3, year);
            statement.setString(4, period);
            try (ResultSet rs = statement.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            throw failure("Error al validar calificación existente.", e);
        }
    }

    private List<AcademicRecord> list(String sql, Integer studentId) {
        List<AcademicRecord> records = new ArrayList<>();
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            if (studentId != null) statement.setInt(1, studentId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) records.add(map(rs));
            }
            return records;
        } catch (SQLException e) {
            throw failure("Error al consultar calificaciones.", e);
        }
    }

    private void bind(PreparedStatement statement, AcademicRecord record, int index) throws SQLException {
        statement.setInt(index++, record.getStudentId());
        statement.setInt(index++, record.getSubjectId());
        statement.setInt(index++, record.getTeacherId());
        statement.setInt(index++, record.getAcademicYear());
        statement.setString(index++, record.getAcademicPeriod());
        statement.setBigDecimal(index++, record.getGrade());
        statement.setString(index++, record.getObservations());
        statement.setDate(index, Date.valueOf(record.getRecordDate()));
    }

    private AcademicRecord map(ResultSet rs) throws SQLException {
        AcademicRecord record = new AcademicRecord();
        record.setIdRecord(rs.getInt("id_registro"));
        record.setStudentId(rs.getInt("id_estudiante"));
        record.setSubjectId(rs.getInt("id_materia"));
        record.setTeacherId(rs.getInt("id_profesor"));
        record.setAcademicYear(rs.getInt("año_academico"));
        record.setAcademicPeriod(rs.getString("periodo_academico"));
        record.setGrade(rs.getBigDecimal("valor_nota"));
        record.setObservations(rs.getString("observaciones"));
        record.setRecordDate(rs.getDate("fecha_registro").toLocalDate());
        return record;
    }

    private Connection connection() { return DatabaseConnection.getInstance(); }
    private RuntimeException failure(String message, SQLException cause) {
        LoggerHelper.logError(message, cause);
        return new RuntimeException(message, cause);
    }
}
