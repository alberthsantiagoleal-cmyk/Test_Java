package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.ITeacherDAO;
import com.littlehorizons.erp.model.entity.Teacher;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TeacherDAOImpl implements ITeacherDAO {
    private static final String COLUMNS = "id_profesor, tipo_documento, numero_documento, primer_nombre, segundo_nombre, "
            + "primer_apellido, segundo_apellido, correo_electronico, telefono, especializacion, fecha_contratacion, estado";

    @Override
    public void create(Teacher teacher) {
        String sql = "INSERT INTO profesores (tipo_documento, numero_documento, primer_nombre, segundo_nombre, primer_apellido, "
                + "segundo_apellido, correo_electronico, telefono, especializacion, fecha_contratacion, estado) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, teacher, 1);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) teacher.setIdTeacher(keys.getInt(1));
            }
        } catch (SQLException e) {
            throw failure("Error al registrar profesor.", e);
        }
    }

    @Override
    public Teacher findById(int id) {
        String sql = "SELECT " + COLUMNS + " FROM profesores WHERE id_profesor=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException e) {
            throw failure("Error al consultar profesor.", e);
        }
    }

    @Override
    public List<Teacher> findAll() {
        List<Teacher> teachers = new ArrayList<>();
        String sql = "SELECT " + COLUMNS + " FROM profesores ORDER BY id_profesor ASC";
        try (PreparedStatement statement = connection().prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) teachers.add(map(rs));
            return teachers;
        } catch (SQLException e) {
            throw failure("Error al consultar profesores.", e);
        }
    }

    @Override
    public void update(Teacher teacher) {
        String sql = "UPDATE profesores SET tipo_documento=?, numero_documento=?, primer_nombre=?, segundo_nombre=?, "
                + "primer_apellido=?, segundo_apellido=?, correo_electronico=?, telefono=?, especializacion=?, "
                + "fecha_contratacion=?, estado=? WHERE id_profesor=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            bind(statement, teacher, 1);
            statement.setInt(12, teacher.getIdTeacher());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw failure("Error al actualizar profesor.", e);
        }
    }

    @Override
    public boolean existsByDocument(String documentNumber) {
        return exists("SELECT 1 FROM profesores WHERE numero_documento=?", documentNumber);
    }

    @Override
    public boolean existsByEmail(String email) {
        return exists("SELECT 1 FROM profesores WHERE correo_electronico=?", email);
    }

    private boolean exists(String sql, String... values) {
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            for (int i = 0; i < values.length; i++) statement.setString(i + 1, values[i]);
            try (ResultSet rs = statement.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            throw failure("Error al validar datos de profesor.", e);
        }
    }

    private void bind(PreparedStatement statement, Teacher teacher, int index) throws SQLException {
        statement.setString(index++, teacher.getDocumentType());
        statement.setString(index++, teacher.getDocumentNumber());
        statement.setString(index++, teacher.getFirstName());
        statement.setString(index++, teacher.getMiddleName());
        statement.setString(index++, teacher.getFirstSurname());
        statement.setString(index++, teacher.getSecondSurname());
        statement.setString(index++, teacher.getEmail());
        statement.setString(index++, teacher.getPhone());
        statement.setString(index++, teacher.getSpecialization());
        statement.setDate(index++, Date.valueOf(teacher.getHireDate()));
        statement.setString(index, teacher.getStatus() == null ? "Activo" : teacher.getStatus());
    }

    private Teacher map(ResultSet rs) throws SQLException {
        Teacher teacher = new Teacher();
        teacher.setIdTeacher(rs.getInt("id_profesor"));
        teacher.setDocumentType(rs.getString("tipo_documento"));
        teacher.setDocumentNumber(rs.getString("numero_documento"));
        teacher.setFirstName(rs.getString("primer_nombre"));
        teacher.setMiddleName(rs.getString("segundo_nombre"));
        teacher.setFirstSurname(rs.getString("primer_apellido"));
        teacher.setSecondSurname(rs.getString("segundo_apellido"));
        teacher.setEmail(rs.getString("correo_electronico"));
        teacher.setPhone(rs.getString("telefono"));
        teacher.setSpecialization(rs.getString("especializacion"));
        teacher.setHireDate(rs.getDate("fecha_contratacion").toLocalDate());
        teacher.setStatus(rs.getString("estado"));
        return teacher;
    }

    private Connection connection() { return DatabaseConnection.getInstance(); }
    private RuntimeException failure(String message, SQLException cause) {
        LoggerHelper.logError(message, cause);
        return new RuntimeException(message, cause);
    }
}
