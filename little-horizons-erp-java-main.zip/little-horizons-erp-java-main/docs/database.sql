-- Anexo: Script de Base de Datos

-- A continuación se presenta el script completo DDL de MySQL para crear todas las tablas necesarias. 
-- Este script debe ejecutarse en una base de datos llamada `little_horizons_erp`.
-- Si encuentra detalles que modificar o agregar, puede editar el script siempre y cuando pueda justificar sus cambios.


-- ============================================
-- Little Horizons ERP - Esquema de Base de Datos
-- Sistema de Gestión Educativa
-- Versión: 2.0 (Corregida y Mejorada)
-- Motor: MySQL 8.0 o superior (REQUERIDO)
-- ============================================

DROP DATABASE IF EXISTS erp_little_horizons;
CREATE DATABASE erp_little_horizons CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE erp_little_horizons;

-- ============================================
-- 1. MÓDULO DE ESTUDIANTES Y ACUDIENTES
-- ============================================

-- Tabla de grados académicos
CREATE TABLE grados (
    id_grado INT AUTO_INCREMENT PRIMARY KEY,
    nombre_grado VARCHAR(50) NOT NULL UNIQUE COMMENT 'Ej: Preescolar, Primero, Segundo, ... Once',
    nivel_numerico INT NOT NULL UNIQUE COMMENT 'Nivel numérico para ordenamiento (0 para preescolar, 1-11 para grados)',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB COMMENT='Catálogo de grados académicos del colegio';

-- Tabla de estudiantes
CREATE TABLE estudiantes (
    id_estudiante INT AUTO_INCREMENT PRIMARY KEY,
    tipo_documento ENUM('RC', 'TI', 'CC', 'CE', 'Pasaporte') NOT NULL DEFAULT 'TI',
    numero_documento VARCHAR(20) NOT NULL UNIQUE,
    primer_nombre VARCHAR(100) NOT NULL,
    segundo_nombre VARCHAR(100),
    primer_apellido VARCHAR(100) NOT NULL,
    segundo_apellido VARCHAR(100),
    fecha_nacimiento DATE NOT NULL,
    genero ENUM('M', 'F', 'Otro') NOT NULL,
    direccion VARCHAR(255),
    telefono VARCHAR(20),
    correo_electronico VARCHAR(100),
    tipo_sangre VARCHAR(5),
    alergias TEXT,
    condiciones_medicas TEXT,
    fecha_ingreso DATE NOT NULL,
    estado ENUM('Activo', 'Graduado', 'Retirado', 'Suspendido') DEFAULT 'Activo',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_documento (tipo_documento, numero_documento),
    INDEX idx_estado (estado),
    INDEX idx_nombre (primer_apellido, segundo_apellido, primer_nombre)
) ENGINE=InnoDB COMMENT='Información completa de estudiantes';

-- Tabla de acudientes/tutores legales
CREATE TABLE acudientes (
    id_acudiente INT AUTO_INCREMENT PRIMARY KEY,
    tipo_documento ENUM('CC', 'CE', 'Pasaporte') NOT NULL DEFAULT 'CC',
    numero_documento VARCHAR(20) NOT NULL UNIQUE,
    primer_nombre VARCHAR(100) NOT NULL,
    segundo_nombre VARCHAR(100),
    primer_apellido VARCHAR(100) NOT NULL,
    segundo_apellido VARCHAR(100),
    parentesco VARCHAR(50) NOT NULL COMMENT 'Padre, Madre, Abuelo, Tío, Tutor Legal, etc.',
    telefono_principal VARCHAR(20) NOT NULL,
    telefono_secundario VARCHAR(20),
    correo_electronico VARCHAR(100),
    direccion VARCHAR(255),
    ocupacion VARCHAR(100),
    es_responsable_financiero BOOLEAN DEFAULT TRUE COMMENT 'Indica si es responsable de pagos',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_documento (tipo_documento, numero_documento),
    INDEX idx_nombre (primer_apellido, segundo_apellido)
) ENGINE=InnoDB COMMENT='Acudientes y tutores legales';

-- Relación estudiantes-acudientes (muchos a muchos)
CREATE TABLE estudiante_acudiente (
    id_estudiante INT NOT NULL,
    id_acudiente INT NOT NULL,
    es_principal BOOLEAN DEFAULT FALSE COMMENT 'Acudiente principal para comunicaciones',
    es_contacto_emergencia BOOLEAN DEFAULT TRUE COMMENT 'Disponible para emergencias',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_estudiante, id_acudiente),
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    FOREIGN KEY (id_acudiente) REFERENCES acudientes(id_acudiente) ON DELETE CASCADE,
    INDEX idx_estudiante (id_estudiante),
    INDEX idx_acudiente (id_acudiente)
) ENGINE=InnoDB COMMENT='Relación entre estudiantes y sus acudientes';

-- Tabla de matrículas (historial de grados por año)
CREATE TABLE matriculas (
    id_matricula INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT NOT NULL,
    id_grado INT NOT NULL,
    año_academico INT NOT NULL COMMENT 'Año académico (ej: 2024)',
    estado_matricula ENUM('Activa', 'Completada', 'Retirada') DEFAULT 'Activa',
    fecha_matricula DATE NOT NULL,
    fecha_retiro DATE,
    observaciones TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    FOREIGN KEY (id_grado) REFERENCES grados(id_grado),
    UNIQUE KEY matricula_unica (id_estudiante, año_academico),
    INDEX idx_año_grado (año_academico, id_grado),
    INDEX idx_estado (estado_matricula)
) ENGINE=InnoDB COMMENT='Historial de matrículas de estudiantes por año y grado';

-- ============================================
-- 2. MÓDULO ACADÉMICO
-- ============================================

-- Tabla de materias/asignaturas
CREATE TABLE materias (
    id_materia INT AUTO_INCREMENT PRIMARY KEY,
    codigo_materia VARCHAR(20) NOT NULL UNIQUE COMMENT 'Código único de la materia (ej: MAT-5, ESP-3)',
    nombre_materia VARCHAR(100) NOT NULL,
    descripcion TEXT,
    id_grado INT NOT NULL COMMENT 'Grado al que pertenece la materia',
    horas_semanales INT DEFAULT 2 COMMENT 'Horas semanales asignadas',
    esta_activa BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_grado) REFERENCES grados(id_grado),
    INDEX idx_grado (id_grado),
    INDEX idx_activa (esta_activa),
    INDEX idx_codigo (codigo_materia)
) ENGINE=InnoDB COMMENT='Catálogo de materias por grado';

-- Tabla de profesores
CREATE TABLE profesores (
    id_profesor INT AUTO_INCREMENT PRIMARY KEY,
    tipo_documento ENUM('CC', 'CE', 'Pasaporte') NOT NULL DEFAULT 'CC',
    numero_documento VARCHAR(20) NOT NULL UNIQUE,
    primer_nombre VARCHAR(100) NOT NULL,
    segundo_nombre VARCHAR(100),
    primer_apellido VARCHAR(100) NOT NULL,
    segundo_apellido VARCHAR(100),
    correo_electronico VARCHAR(100) NOT NULL UNIQUE,
    telefono VARCHAR(20),
    especializacion VARCHAR(100) COMMENT 'Área de especialización (Matemáticas, Español, etc.)',
    fecha_contratacion DATE NOT NULL,
    estado ENUM('Activo', 'Inactivo', 'Licencia') DEFAULT 'Activo',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_documento (tipo_documento, numero_documento),
    INDEX idx_estado (estado),
    INDEX idx_nombre (primer_apellido, segundo_apellido)
) ENGINE=InnoDB COMMENT='Información de profesores';

-- Asignación de materias a profesores
CREATE TABLE asignaciones_profesor (
    id_asignacion INT AUTO_INCREMENT PRIMARY KEY,
    id_profesor INT NOT NULL,
    id_materia INT NOT NULL,
    año_academico INT NOT NULL,
    seccion VARCHAR(10) COMMENT 'Sección o grupo (A, B, C)',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_profesor) REFERENCES profesores(id_profesor) ON DELETE CASCADE,
    FOREIGN KEY (id_materia) REFERENCES materias(id_materia) ON DELETE CASCADE,
    UNIQUE KEY asignacion_unica (id_profesor, id_materia, año_academico, seccion),
    INDEX idx_profesor_año (id_profesor, año_academico),
    INDEX idx_materia_año (id_materia, año_academico)
) ENGINE=InnoDB COMMENT='Asignación de profesores a materias por año académico';

-- Inscripción de estudiantes en materias
CREATE TABLE inscripciones_materia (
    id_inscripcion INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT NOT NULL,
    id_materia INT NOT NULL,
    año_academico INT NOT NULL,
    periodo_academico ENUM('I', 'II', 'III', 'IV') NOT NULL COMMENT 'Período académico',
    seccion VARCHAR(10) COMMENT 'Sección o grupo asignado',
    fecha_inscripcion DATE NOT NULL,
    estado ENUM('Activa', 'Retirada', 'Completada') DEFAULT 'Activa',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    FOREIGN KEY (id_materia) REFERENCES materias(id_materia) ON DELETE CASCADE,
    UNIQUE KEY inscripcion_unica (id_estudiante, id_materia, año_academico, periodo_academico),
    INDEX idx_estudiante_año (id_estudiante, año_academico),
    INDEX idx_materia_periodo (id_materia, periodo_academico)
) ENGINE=InnoDB COMMENT='Inscripción de estudiantes en materias específicas';

-- Tabla de registros académicos (calificaciones/notas)
CREATE TABLE registros_academicos (
    id_registro INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT NOT NULL,
    id_materia INT NOT NULL,
    id_profesor INT NOT NULL,
    año_academico INT NOT NULL,
    periodo_academico ENUM('I', 'II', 'III', 'IV', 'Final') NOT NULL,
    valor_nota DECIMAL(2,1) NOT NULL COMMENT 'Nota de 0.0 a 5.0 según estándar colombiano',
    observaciones TEXT,
    fecha_registro DATE NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    FOREIGN KEY (id_materia) REFERENCES materias(id_materia) ON DELETE CASCADE,
    FOREIGN KEY (id_profesor) REFERENCES profesores(id_profesor),
    CHECK (valor_nota >= 0.0 AND valor_nota <= 5.0),
    UNIQUE KEY registro_unico (id_estudiante, id_materia, año_academico, periodo_academico),
    INDEX idx_estudiante_año (id_estudiante, año_academico),
    INDEX idx_materia_periodo (id_materia, periodo_academico),
    INDEX idx_valor_nota (valor_nota)
) ENGINE=InnoDB COMMENT='Registro de calificaciones de estudiantes';

-- Tabla de asistencia
CREATE TABLE asistencias (
    id_asistencia INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT NOT NULL,
    id_materia INT NOT NULL,
    fecha_asistencia DATE NOT NULL,
    estado_asistencia ENUM('Presente', 'Ausente', 'Tardanza', 'Excusa Medica') NOT NULL,
    observaciones TEXT,
    registrado_por INT COMMENT 'ID del profesor que registró la asistencia',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    FOREIGN KEY (id_materia) REFERENCES materias(id_materia) ON DELETE CASCADE,
    FOREIGN KEY (registrado_por) REFERENCES profesores(id_profesor),
    UNIQUE KEY asistencia_unica (id_estudiante, id_materia, fecha_asistencia),
    INDEX idx_estudiante_fecha (id_estudiante, fecha_asistencia),
    INDEX idx_materia_fecha (id_materia, fecha_asistencia),
    INDEX idx_estado (estado_asistencia)
) ENGINE=InnoDB COMMENT='Registro de asistencia diaria de estudiantes';

-- ============================================
-- 3. MÓDULO DE ACTIVIDADES EXTRACURRICULARES
-- ============================================

-- Tabla de clubes
CREATE TABLE clubes (
    id_club INT AUTO_INCREMENT PRIMARY KEY,
    nombre_club VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT,
    id_profesor_supervisor INT COMMENT 'Profesor encargado del club',
    capacidad_maxima INT DEFAULT 30 COMMENT 'Cupo máximo de estudiantes',
    horario_reunion VARCHAR(100) COMMENT 'Días y horario de reunión (ej: Martes 3-5 PM)',
    esta_activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_profesor_supervisor) REFERENCES profesores(id_profesor),
    INDEX idx_activo (esta_activo),
    INDEX idx_nombre (nombre_club)
) ENGINE=InnoDB COMMENT='Catálogo de clubes extracurriculares';

-- Membresías en clubes
CREATE TABLE membresias_club (
    id_membresia INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT NOT NULL,
    id_club INT NOT NULL,
    fecha_ingreso DATE NOT NULL,
    estado_membresia ENUM('Activa', 'Retirada') DEFAULT 'Activa',
    fecha_retiro DATE,
    motivo_retiro TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    FOREIGN KEY (id_club) REFERENCES clubes(id_club) ON DELETE CASCADE,
    INDEX idx_estudiante (id_estudiante),
    INDEX idx_club_estado (id_club, estado_membresia)
) ENGINE=InnoDB COMMENT='Membresías de estudiantes en clubes';

-- Tabla de eventos
CREATE TABLE eventos (
    id_evento INT AUTO_INCREMENT PRIMARY KEY,
    nombre_evento VARCHAR(150) NOT NULL,
    descripcion TEXT,
    tipo_evento ENUM('Academico', 'Cultural', 'Deportivo', 'Social', 'Cientifico') NOT NULL,
    fecha_evento DATE NOT NULL,
    lugar VARCHAR(150),
    tiene_competencia BOOLEAN DEFAULT FALSE COMMENT 'Indica si el evento tiene competencia con posiciones',
    id_organizador INT COMMENT 'Profesor organizador del evento',
    esta_activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_organizador) REFERENCES profesores(id_profesor),
    INDEX idx_fecha (fecha_evento),
    INDEX idx_tipo (tipo_evento),
    INDEX idx_activo (esta_activo)
) ENGINE=InnoDB COMMENT='Catálogo de eventos del colegio';

-- Participantes en eventos
CREATE TABLE participantes_evento (
    id_participacion INT AUTO_INCREMENT PRIMARY KEY,
    id_evento INT NOT NULL,
    id_estudiante INT NOT NULL,
    rol_participacion ENUM('Participante', 'Competidor', 'Organizador', 'Asistente') DEFAULT 'Participante',
    posicion_obtenida VARCHAR(20) COMMENT 'Posición obtenida si hay competencia (1er Lugar, 2do Lugar, 3er Lugar, Participante)',
    observaciones TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_evento) REFERENCES eventos(id_evento) ON DELETE CASCADE,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    UNIQUE KEY participacion_unica (id_evento, id_estudiante),
    INDEX idx_evento (id_evento),
    INDEX idx_estudiante (id_estudiante)
) ENGINE=InnoDB COMMENT='Registro de participación de estudiantes en eventos';

-- ============================================
-- 4. MÓDULO FINANCIERO
-- ============================================

-- Conceptos de pago (catálogo)
CREATE TABLE conceptos_pago (
    id_concepto INT AUTO_INCREMENT PRIMARY KEY,
    codigo_concepto VARCHAR(20) NOT NULL UNIQUE,
    nombre_concepto VARCHAR(100) NOT NULL,
    descripcion TEXT,
    monto_base DECIMAL(10,2) NOT NULL COMMENT 'Valor base del concepto en pesos colombianos',
    es_recurrente BOOLEAN DEFAULT FALSE COMMENT 'Indica si es un pago recurrente (ej: pensión mensual)',
    esta_activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_activo (esta_activo),
    INDEX idx_codigo (codigo_concepto)
) ENGINE=InnoDB COMMENT='Catálogo de conceptos de pago del colegio';

-- Tabla de pagos
CREATE TABLE pagos (
    id_pago INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT NOT NULL,
    id_acudiente INT COMMENT 'Acudiente que realizó el pago',
    id_concepto INT NOT NULL,
    monto_pagado DECIMAL(10,2) NOT NULL,
    fecha_pago DATE NOT NULL,
    metodo_pago ENUM('Efectivo', 'Transferencia', 'Tarjeta Debito', 'Tarjeta Credito', 'Cheque') NOT NULL,
    numero_recibo VARCHAR(50) UNIQUE,
    año_academico INT COMMENT 'Año al que aplica el pago',
    periodo_academico ENUM('I', 'II', 'III', 'IV', 'Anual') COMMENT 'Período al que aplica el pago',
    notas TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    FOREIGN KEY (id_acudiente) REFERENCES acudientes(id_acudiente),
    FOREIGN KEY (id_concepto) REFERENCES conceptos_pago(id_concepto),
    INDEX idx_estudiante_fecha (id_estudiante, fecha_pago),
    INDEX idx_concepto (id_concepto),
    INDEX idx_fecha (fecha_pago),
    INDEX idx_recibo (numero_recibo)
) ENGINE=InnoDB COMMENT='Registro de todos los pagos realizados';

-- Tabla de facturas electrónicas
CREATE TABLE facturas (
    id_factura INT AUTO_INCREMENT PRIMARY KEY,
    numero_factura VARCHAR(50) NOT NULL UNIQUE COMMENT 'Número consecutivo de factura',
    id_pago INT NOT NULL COMMENT 'Pago asociado a esta factura',
    fecha_emision DATE NOT NULL,
    cufe VARCHAR(100) COMMENT 'Código Único de Factura Electrónica (simulado)',
    nombre_archivo_pdf VARCHAR(255) COMMENT 'Nombre del archivo PDF generado',
    ruta_archivo VARCHAR(500) COMMENT 'Ruta completa donde se guardó el PDF',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pago) REFERENCES pagos(id_pago) ON DELETE CASCADE,
    INDEX idx_numero_factura (numero_factura),
    INDEX idx_fecha_emision (fecha_emision),
    INDEX idx_pago (id_pago)
) ENGINE=InnoDB COMMENT='Registro de facturas electrónicas generadas';

-- ============================================
-- 5. MÓDULO DE GESTIÓN DE RECURSOS
-- ============================================

-- Categorías de recursos
CREATE TABLE categorias_recurso (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre_categoria VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB COMMENT='Categorías de recursos (Libro, Equipo de Laboratorio, etc.)';

-- Tabla de recursos del colegio
CREATE TABLE recursos (
    id_recurso INT AUTO_INCREMENT PRIMARY KEY,
    codigo_recurso VARCHAR(50) NOT NULL UNIQUE COMMENT 'Código de inventario único',
    nombre_recurso VARCHAR(150) NOT NULL,
    id_categoria INT NOT NULL,
    descripcion TEXT,
    fecha_adquisicion DATE,
    ubicacion_fisica VARCHAR(100) COMMENT 'Ubicación física (Biblioteca, Laboratorio 1, etc.)',
    estado_recurso ENUM('Disponible', 'Prestado', 'En Mantenimiento', 'Dado de Baja') DEFAULT 'Disponible',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_categoria) REFERENCES categorias_recurso(id_categoria),
    INDEX idx_codigo (codigo_recurso),
    INDEX idx_estado (estado_recurso),
    INDEX idx_categoria (id_categoria),
    INDEX idx_nombre (nombre_recurso)
) ENGINE=InnoDB COMMENT='Inventario de recursos prestables del colegio';

-- Tabla de préstamos de recursos a ESTUDIANTES
CREATE TABLE prestamos_estudiante (
    id_prestamo INT AUTO_INCREMENT PRIMARY KEY,
    id_recurso INT NOT NULL,
    id_estudiante INT NOT NULL COMMENT 'Estudiante que toma prestado el recurso',
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion_esperada DATE NOT NULL,
    fecha_devolucion_real DATE,
    estado_prestamo ENUM('Activo', 'Devuelto', 'Vencido') DEFAULT 'Activo',
    observaciones TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_recurso) REFERENCES recursos(id_recurso) ON DELETE CASCADE,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante) ON DELETE CASCADE,
    INDEX idx_recurso_estado (id_recurso, estado_prestamo),
    INDEX idx_estudiante (id_estudiante),
    INDEX idx_estado (estado_prestamo),
    INDEX idx_fecha_devolucion (fecha_devolucion_esperada)
) ENGINE=InnoDB COMMENT='Registro de préstamos de recursos a estudiantes';

-- Tabla de préstamos de recursos a PROFESORES
CREATE TABLE prestamos_profesor (
    id_prestamo INT AUTO_INCREMENT PRIMARY KEY,
    id_recurso INT NOT NULL,
    id_profesor INT NOT NULL COMMENT 'Profesor que toma prestado el recurso',
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion_esperada DATE NOT NULL,
    fecha_devolucion_real DATE,
    estado_prestamo ENUM('Activo', 'Devuelto', 'Vencido') DEFAULT 'Activo',
    observaciones TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_recurso) REFERENCES recursos(id_recurso) ON DELETE CASCADE,
    FOREIGN KEY (id_profesor) REFERENCES profesores(id_profesor) ON DELETE CASCADE,
    INDEX idx_recurso_estado (id_recurso, estado_prestamo),
    INDEX idx_profesor (id_profesor),
    INDEX idx_estado (estado_prestamo),
    INDEX idx_fecha_devolucion (fecha_devolucion_esperada)
) ENGINE=InnoDB COMMENT='Registro de préstamos de recursos a profesores';

-- ============================================
-- DATOS INICIALES BÁSICOS
-- ============================================

-- Insertar grados académicos
INSERT INTO grados (nombre_grado, nivel_numerico) VALUES
('Preescolar', 0),
('Primero', 1),
('Segundo', 2),
('Tercero', 3),
('Cuarto', 4),
('Quinto', 5),
('Sexto', 6),
('Séptimo', 7),
('Octavo', 8),
('Noveno', 9),
('Décimo', 10),
('Once', 11);

-- Insertar categorías de recursos
INSERT INTO categorias_recurso (nombre_categoria, descripcion) VALUES
('Libro', 'Libros de la biblioteca escolar'),
('Equipo de Laboratorio', 'Equipos científicos y de laboratorio (microscopios, balanzas, etc.)'),
('Equipo Deportivo', 'Equipos y materiales deportivos (balones, conos, etc.)'),
('Dispositivo Tecnológico', 'Tablets, calculadoras científicas, computadores portátiles'),
('Material Didáctico', 'Materiales educativos diversos (mapas, modelos, etc.)');

-- Insertar conceptos de pago comunes
INSERT INTO conceptos_pago (codigo_concepto, nombre_concepto, descripcion, monto_base, es_recurrente) VALUES
('MAT', 'Matrícula', 'Pago anual de matrícula', 500000.00, FALSE),
('PENSION', 'Pensión Mensual', 'Pago mensual de pensión', 350000.00, TRUE),
('UNIFORME', 'Uniforme', 'Uniforme escolar completo', 250000.00, FALSE),
('TRANSPORTE', 'Transporte Escolar', 'Servicio de transporte mensual', 150000.00, TRUE),
('ALIMENTACION', 'Servicio de Alimentación', 'Almuerzo escolar mensual', 120000.00, TRUE),
('ACTIVIDAD', 'Actividad Especial', 'Salida pedagógica o actividad especial', 50000.00, FALSE),
('CERTIFICADO', 'Certificado', 'Certificado de estudio o constancia', 15000.00, FALSE);

-- ============================================
-- DATOS DE PRUEBA DML (MINIMO 30 REGISTROS POR TABLA PRINCIPAL)
-- ============================================

-- 1. PROFESORES (30 registros)
INSERT INTO profesores (id_profesor, tipo_documento, numero_documento, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, correo_electronico, telefono, especializacion, fecha_contratacion, estado) VALUES
(1, 'CC', '1018273641', 'Carlos', 'Alberto', 'Ramirez', 'Ospina', 'carlos.ramirez@littlehorizons.edu.co', '3104567890', 'Licenciatura en Matematicas', '2020-01-15', 'Activo'),
(2, 'CC', '1020394857', 'Maria', 'Fernanda', 'Gomez', 'Restrepo', 'maria.gomez@littlehorizons.edu.co', '3119876543', 'Licenciatura en Lengua Castellana', '2019-03-01', 'Activo'),
(3, 'CC', '1032485960', 'Jorge', 'Enrique', 'Hernandez', 'Pardo', 'jorge.hernandez@littlehorizons.edu.co', '3123456789', 'Licenciatura en Ciencias Naturales y Biologia', '2021-02-10', 'Activo'),
(4, 'CC', '1045678912', 'Ana', 'Lucia', 'Castro', 'Mendoza', 'ana.castro@littlehorizons.edu.co', '3134567891', 'Licenciatura en Idiomas (Ingles - Frances)', '2018-07-20', 'Activo'),
(5, 'CC', '1056789123', 'David', 'Esteban', 'Morales', 'Silva', 'david.morales@littlehorizons.edu.co', '3145678912', 'Licenciatura en Ciencias Sociales e Historia', '2022-01-18', 'Activo'),
(6, 'CC', '1067891234', 'Sandra', 'Patricia', 'Ortiz', 'Navarro', 'sandra.ortiz@littlehorizons.edu.co', '3156789123', 'Licenciatura en Educacion Fisica y Deportes', '2017-09-01', 'Activo'),
(7, 'CC', '1078912345', 'Andres', 'Felipe', 'Vargas', 'Guerrero', 'andres.vargas@littlehorizons.edu.co', '3167891234', 'Ingenieria de Sistemas y Tecnologia', '2021-08-15', 'Activo'),
(8, 'CC', '1089123456', 'Claudia', 'Marcela', 'Rios', 'Cardenas', 'claudia.rios@littlehorizons.edu.co', '3178912345', 'Licenciatura en Artes Plasticas', '2020-04-10', 'Activo'),
(9, 'CC', '1091234567', 'Gustavo', 'Adolfo', 'Pena', 'Lozano', 'gustavo.pena@littlehorizons.edu.co', '3189123456', 'Licenciatura en Quimica', '2019-11-05', 'Activo'),
(10, 'CC', '1102345678', 'Diana', 'Carolina', 'Mejia', 'Duarte', 'diana.mejia@littlehorizons.edu.co', '3191234567', 'Licenciatura en Musica', '2022-06-01', 'Activo'),
(11, 'CC', '1113456789', 'Ricardo', 'Jose', 'Torres', 'Montoya', 'ricardo.torres@littlehorizons.edu.co', '3102345678', 'Licenciatura en Filosofia y Etica', '2016-02-14', 'Activo'),
(12, 'CC', '1124567890', 'Monica', 'Andrea', 'Salazar', 'Vega', 'monica.salazar@littlehorizons.edu.co', '3113456789', 'Licenciatura en Pedagogia Infantil (Preescolar)', '2015-08-01', 'Activo'),
(13, 'CC', '1135678901', 'Camilo', 'Andres', 'Rojas', 'Parra', 'camilo.rojas@littlehorizons.edu.co', '3124567890', 'Licenciatura en Fisica', '2020-02-01', 'Activo'),
(14, 'CC', '1146789012', 'Paola', 'Ximena', 'Suarez', 'Camacho', 'paola.suarez@littlehorizons.edu.co', '3135678901', 'Licenciatura en Primaria', '2018-01-20', 'Activo'),
(15, 'CC', '1157890123', 'Mauricio', 'Alejandro', 'Velasquez', 'Nieto', 'mauricio.velasquez@littlehorizons.edu.co', '3146789012', 'Licenciatura en Geografia y Ciencias Politicas', '2021-03-15', 'Activo'),
(16, 'CC', '1168901234', 'Elena', 'Rocio', 'Corredor', 'Beltran', 'elena.corredor@littlehorizons.edu.co', '3157890123', 'Licenciatura en Literatura y Comunicacion', '2017-05-10', 'Activo'),
(17, 'CC', '1179012345', 'Javier', 'Orlando', 'Munoz', 'Guzman', 'javier.munoz@littlehorizons.edu.co', '3168901234', 'Licenciatura en Educacion Religiosa y Valores', '2019-09-15', 'Activo'),
(18, 'CC', '1180123456', 'Adriana', 'Lucia', 'Pardo', 'Serrano', 'adriana.pardo@littlehorizons.edu.co', '3179012345', 'Psicopedagogia y Orientacion Escolar', '2022-02-01', 'Activo'),
(19, 'CC', '1191234567', 'Hector', 'Fabio', 'Giraldo', 'Valencia', 'hector.giraldo@littlehorizons.edu.co', '3180123456', 'Licenciatura en Matematicas y Estadistica', '2020-07-01', 'Activo'),
(20, 'CC', '1202345678', 'Gloria', 'Esperanza', 'Buitrago', 'Acosta', 'gloria.buitrago@littlehorizons.edu.co', '3192345678', 'Licenciatura en Ingles Avanzado', '2016-10-15', 'Activo'),
(21, 'CC', '1213456789', 'Alvaro', 'Javier', 'Castaneda', 'Marin', 'alvaro.castaneda@littlehorizons.edu.co', '3103456789', 'Educacion Especial e Inclusion', '2021-01-15', 'Activo'),
(22, 'CC', '1224567890', 'Silvia', 'Juliana', 'Pinzon', 'Carvajal', 'silvia.pinzon@littlehorizons.edu.co', '3114567890', 'Licenciatura en Danza y Folclor', '2019-02-20', 'Activo'),
(23, 'CC', '1235678901', 'Gabriel', 'Eduardo', 'Cardona', 'Duque', 'gabriel.cardona@littlehorizons.edu.co', '3125678901', 'Licenciatura en Robotica y Tecnologia', '2022-08-01', 'Activo'),
(24, 'CC', '1246789012', 'Beatriz', 'Eugenia', 'Montes', 'Herrera', 'beatriz.montes@littlehorizons.edu.co', '3136789012', 'Licenciatura en Ecologia y Ciencias Ambientales', '2018-04-12', 'Activo'),
(25, 'CC', '1257890123', 'Julian', 'Alberto', 'Osorio', 'Botero', 'julian.osorio@littlehorizons.edu.co', '3147890123', 'Licenciatura en Entrenamiento Deportivo', '2020-09-01', 'Activo'),
(26, 'CC', '1268901234', 'Nidia', 'Constanza', 'Chavez', 'Pineda', 'nidia.chavez@littlehorizons.edu.co', '3158901234', 'Licenciatura en Teatro y Expresion Escenica', '2017-03-01', 'Activo'),
(27, 'CC', '1279012345', 'Oscar', 'Mauricio', 'Pabon', 'Florez', 'oscar.pabon@littlehorizons.edu.co', '3169012345', 'Licenciatura en Pensamiento Logico y Ajedrez', '2021-05-18', 'Activo'),
(28, 'CC', '1280123456', 'Lina', 'Marcela', 'Gallego', 'Arango', 'lina.gallego@littlehorizons.edu.co', '3170123456', 'Licenciatura en Quimica y Bioquimica', '2019-08-01', 'Activo'),
(29, 'CC', '1291234567', 'Hernan', 'Dario', 'Bedoya', 'Cano', 'hernan.bedoya@littlehorizons.edu.co', '3181234567', 'Licenciatura en Musica y Coros', '2022-03-01', 'Activo'),
(30, 'CC', '1302345678', 'Yolanda', 'Beatriz', 'Zambrano', 'Rosero', 'yolanda.zambrano@littlehorizons.edu.co', '3193456789', 'Licenciatura en Etica y Constitucion', '2015-11-20', 'Activo');

-- 2. ACUDIENTES (30 registros)
INSERT INTO acudientes (id_acudiente, tipo_documento, numero_documento, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, parentesco, telefono_principal, telefono_secundario, correo_electronico, direccion, ocupacion, es_responsable_financiero) VALUES
(1, 'CC', '79123456', 'Carlos', 'Alberto', 'Perez', 'Rodriguez', 'Padre', '3101112233', '6017891234', 'carlos.perez@empresa.com', 'Calle 134 # 19-45, Bogota', 'Ingeniero Civil', TRUE),
(2, 'CC', '52987654', 'Martha', 'Cecilia', 'Gomez', 'Lara', 'Madre', '3112223344', '6018901235', 'martha.gomez@consultoria.co', 'Carrera 15 # 104-20, Bogota', 'Abogada', TRUE),
(3, 'CC', '80456123', 'Guillermo', 'Leon', 'Restrepo', 'Hoyos', 'Padre', '3123334455', '6019012346', 'guillermo.restrepo@banco.com', 'Calle 140 # 9-60, Bogota', 'Administrador de Empresas', TRUE),
(4, 'CC', '51789012', 'Luz', 'Marina', 'Castro', 'Velez', 'Madre', '3134445566', '6010123457', 'luz.castro@salud.gov.co', 'Diagonal 127A # 58-12, Bogota', 'Medica Pediatra', TRUE),
(5, 'CC', '19345678', 'Fernando', 'Antonio', 'Vargas', 'Cely', 'Tio', '3145556677', '6011234568', 'fernando.vargas@comercio.com', 'Carrera 7 # 156-30, Bogota', 'Comerciante', TRUE),
(6, 'CC', '53012345', 'Esperanza', 'Maria', 'Morales', 'Quintero', 'Madre', '3156667788', '6012345679', 'esperanza.morales@colegio.edu.co', 'Transversal 23 # 98-15, Bogota', 'Docente Universitaria', TRUE),
(7, 'CC', '80123789', 'Jairo', 'Enrique', 'Silva', 'Bermudez', 'Padre', '3167778899', '6013456780', 'jairo.silva@arquitectos.co', 'Calle 116 # 45-80, Bogota', 'Arquitecto', TRUE),
(8, 'CC', '52345901', 'Gloria', 'Ines', 'Ortiz', 'Pena', 'Madre', '3178889900', '6014567891', 'gloria.ortiz@finanzas.com', 'Carrera 58 # 137B-10, Bogota', 'Contadora Publica', TRUE),
(9, 'CC', '79654123', 'Alonso', 'Hernando', 'Rios', 'Forero', 'Padre', '3189990011', '6015678902', 'alonso.rios@seguros.com', 'Calle 152 # 11-20, Bogota', 'Agente de Seguros', TRUE),
(10, 'CC', '51890234', 'Patricia', 'Elena', 'Mendoza', 'Romero', 'Madre', '3190001122', '6016789013', 'patricia.mendoza@farmacia.co', 'Carrera 19A # 120-40, Bogota', 'Quimica Farmaceutica', TRUE),
(11, 'CC', '80789456', 'Hernando', 'Dario', 'Lopez', 'Monroy', 'Padre', '3102223344', '6017890124', 'hernando.lopez@construccion.com', 'Calle 170 # 8-30, Bogota', 'Constructor', TRUE),
(12, 'CC', '52456789', 'Rosa', 'Isabel', 'Guerrero', 'Leon', 'Abuela', '3113334455', '6018901235', 'rosa.guerrero@pensionados.co', 'Calle 100 # 15-60, Bogota', 'Pensionada', FALSE),
(13, 'CC', '79345890', 'Alejandro', 'Jose', 'Pardo', 'Toro', 'Padre', '3124445566', '6019012346', 'alejandro.pardo@sistemas.co', 'Carrera 11 # 134-22, Bogota', 'Ingeniero de Software', TRUE),
(14, 'CC', '51234789', 'Olga', 'Lucia', 'Torres', 'Suarez', 'Madre', '3135556677', '6010123457', 'olga.torres@idiomas.com', 'Calle 147 # 19-35, Bogota', 'Traductora', TRUE),
(15, 'CC', '80890123', 'Jaime', 'Eduardo', 'Salazar', 'Reyes', 'Padre', '3146667788', '6011234568', 'jaime.salazar@transporte.co', 'Carrera 72 # 138-15, Bogota', 'Empresario Transporte', TRUE),
(16, 'CC', '52890345', 'Adriana', 'Maria', 'Cardenas', 'Chavez', 'Madre', '3157778899', '6012345679', 'adriana.cardenas@diseno.com', 'Calle 106 # 23-40, Bogota', 'Disenadora de Interiores', TRUE),
(17, 'CC', '79789234', 'Luis', 'Fernando', 'Montoya', 'Valencia', 'Padre', '3168889900', '6013456780', 'luis.montoya@alimentos.co', 'Carrera 9 # 113-18, Bogota', 'Gerente de Ventas', TRUE),
(18, 'CC', '51901456', 'Beatriz', 'Amalia', 'Duarte', 'Gallego', 'Madre', '3179990011', '6014567891', 'beatriz.duarte@clinica.com', 'Calle 122 # 15-50, Bogota', 'Enfermera Jefe', TRUE),
(19, 'CC', '80234890', 'Mauricio', 'Javier', 'Mejia', 'Buitrago', 'Padre', '3180001122', '6015678902', 'mauricio.mejia@energia.com', 'Transversal 17 # 125-30, Bogota', 'Ingeniero Electrico', TRUE),
(20, 'CC', '52123890', 'Carmenza', 'Lucia', 'Camacho', 'Velasquez', 'Madre', '3191112233', '6016789013', 'carmenza.camacho@editorial.co', 'Calle 138 # 45-12, Bogota', 'Editora', TRUE),
(21, 'CC', '79456012', 'German', 'Alonso', 'Rojas', 'Cardona', 'Padre', '3103334455', '6017890124', 'german.rojas@automotriz.com', 'Carrera 54 # 142-60, Bogota', 'Ingeniero Mecanico', TRUE),
(22, 'CC', '51678234', 'Sonia', 'Yamile', 'Parra', 'Pinzon', 'Madre', '3114445566', '6018901235', 'sonia.parra@odontologia.co', 'Calle 118 # 14A-25, Bogota', 'Odontologa', TRUE),
(23, 'CC', '80567234', 'Cesar', 'Augusto', 'Nieto', 'Montes', 'Padre', '3125556677', '6019012346', 'cesar.nieto@banca.com', 'Carrera 13 # 122-10, Bogota', 'Economista', TRUE),
(24, 'CC', '52789123', 'Maritza', 'Stella', 'Corredor', 'Munoz', 'Madre', '3136667788', '6010123457', 'maritza.corredor@turismo.co', 'Calle 160 # 14-80, Bogota', 'Administradora Turistica', TRUE),
(25, 'CC', '79890456', 'Rodrigo', 'Alberto', 'Guzman', 'Osorio', 'Padre', '3147778899', '6011234568', 'rodrigo.guzman@logistica.com', 'Carrera 18 # 147-30, Bogota', 'Director Logistico', TRUE),
(26, 'CC', '51456901', 'Amparo', 'Del Carmen', 'Beltran', 'Zambrano', 'Madre', '3158889900', '6012345679', 'amparo.beltran@gobierno.gov.co', 'Calle 108 # 17-22, Bogota', 'Funcionaria Publica', TRUE),
(27, 'CC', '80901567', 'Victor', 'Manuel', 'Serrano', 'Bedoya', 'Padre', '3169990011', '6013456780', 'victor.serrano@comunicaciones.co', 'Transversal 21 # 104-50, Bogota', 'Periodista', TRUE),
(28, 'CC', '52901234', 'Lilian', 'Rocio', 'Giraldo', 'Arango', 'Madre', '3170001122', '6014567891', 'lilian.giraldo@nutricion.com', 'Calle 129 # 18-40, Bogota', 'Nutricionista', TRUE),
(29, 'CC', '79012678', 'Fabio', 'Ernesto', 'Acosta', 'Pineda', 'Padre', '3181112233', '6015678902', 'fabio.acosta@seguridad.com', 'Carrera 15 # 134-80, Bogota', 'Consultor de Seguridad', TRUE),
(30, 'CC', '51012789', 'Cecilia', 'Ines', 'Chavez', 'Flórez', 'Madre', '3192223344', '6016789013', 'cecilia.chavez@psicologia.co', 'Calle 145 # 11-15, Bogota', 'Psicologa Clinica', TRUE);

-- 3. ESTUDIANTES (30 registros)
INSERT INTO estudiantes (id_estudiante, tipo_documento, numero_documento, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero, direccion, telefono, correo_electronico, tipo_sangre, alergias, condiciones_medicas, fecha_ingreso, estado) VALUES
(1, 'TI', '1098765431', 'Juan', 'Camilo', 'Perez', 'Gomez', '2010-04-15', 'M', 'Calle 134 # 19-45', '3101112233', 'juan.perez@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2020-01-20', 'Activo'),
(2, 'TI', '1098765432', 'Sofia', 'Valentina', 'Perez', 'Gomez', '2012-08-22', 'F', 'Calle 134 # 19-45', '3101112233', 'sofia.perez@estudiante.edu.co', 'O+', 'Polen', 'Ninguna', '2020-01-20', 'Activo'),
(3, 'TI', '1098765433', 'Mateo', 'Alejandro', 'Restrepo', 'Castro', '2009-02-10', 'M', 'Calle 140 # 9-60', '3123334455', 'mateo.restrepo@estudiante.edu.co', 'A+', 'Penicilina', 'Asma leve', '2019-01-15', 'Activo'),
(4, 'TI', '1098765434', 'Valeria', 'Isabella', 'Restrepo', 'Castro', '2011-11-05', 'F', 'Calle 140 # 9-60', '3123334455', 'valeria.restrepo@estudiante.edu.co', 'A+', 'Ninguna', 'Ninguna', '2019-01-15', 'Activo'),
(5, 'TI', '1098765435', 'Samuel', 'David', 'Vargas', 'Morales', '2010-07-18', 'M', 'Carrera 7 # 156-30', '3145556677', 'samuel.vargas@estudiante.edu.co', 'B+', 'Mani', 'Ninguna', '2021-01-20', 'Activo'),
(6, 'TI', '1098765436', 'Gabriela', 'Lucia', 'Silva', 'Ortiz', '2013-03-25', 'F', 'Calle 116 # 45-80', '3167778899', 'gabriela.silva@estudiante.edu.co', 'O-', 'Ninguna', 'Miopia', '2021-01-20', 'Activo'),
(7, 'TI', '1098765437', 'Santiago', 'Andres', 'Silva', 'Ortiz', '2015-09-12', 'M', 'Calle 116 # 45-80', '3167778899', 'santiago.silva@estudiante.edu.co', 'O-', 'Ninguna', 'Ninguna', '2022-01-20', 'Activo'),
(8, 'TI', '1098765438', 'Isabella', 'Maria', 'Rios', 'Mendoza', '2008-05-30', 'F', 'Calle 152 # 11-20', '3189990011', 'isabella.rios@estudiante.edu.co', 'AB+', 'Mariscos', 'Ninguna', '2018-01-20', 'Activo'),
(9, 'TI', '1098765439', 'Lucas', 'Felipe', 'Lopez', 'Guerrero', '2009-12-08', 'M', 'Calle 170 # 8-30', '3102223344', 'lucas.lopez@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2019-01-15', 'Activo'),
(10, 'TI', '1098765440', 'Mariana', 'Salome', 'Pardo', 'Torres', '2011-06-14', 'F', 'Carrera 11 # 134-22', '3124445566', 'mariana.pardo@estudiante.edu.co', 'A-', 'Polvo', 'Rinitis alergica', '2020-01-20', 'Activo'),
(11, 'TI', '1098765441', 'Nicolas', 'Eduardo', 'Salazar', 'Cardenas', '2010-10-02', 'M', 'Carrera 72 # 138-15', '3146667788', 'nicolas.salazar@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2020-01-20', 'Activo'),
(12, 'TI', '1098765442', 'Camila', 'Andrea', 'Montoya', 'Duarte', '2012-01-19', 'F', 'Carrera 9 # 113-18', '3168889900', 'camila.montoya@estudiante.edu.co', 'B+', 'Aspirina', 'Ninguna', '2021-01-20', 'Activo'),
(13, 'TI', '1098765443', 'Daniel', 'Esteban', 'Mejia', 'Camacho', '2008-08-11', 'M', 'Transversal 17 # 125-30', '3180001122', 'daniel.mejia@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2018-01-15', 'Activo'),
(14, 'TI', '1098765444', 'Sara', 'Juliana', 'Rojas', 'Parra', '2014-04-03', 'F', 'Carrera 54 # 142-60', '3103334455', 'sara.rojas@estudiante.edu.co', 'A+', 'Ninguna', 'Ninguna', '2022-01-20', 'Activo'),
(15, 'TI', '1098765445', 'Martin', 'Emilio', 'Nieto', 'Corredor', '2009-07-29', 'M', 'Carrera 13 # 122-10', '3125556677', 'martin.nieto@estudiante.edu.co', 'O+', 'Ninguna', 'Diabetes juvenil controlada', '2019-01-20', 'Activo'),
(16, 'TI', '1098765446', 'Luciana', 'Paz', 'Guzman', 'Beltran', '2011-09-17', 'F', 'Carrera 18 # 147-30', '3147778899', 'luciana.guzman@estudiante.edu.co', 'AB-', 'Ninguna', 'Ninguna', '2020-01-20', 'Activo'),
(17, 'TI', '1098765447', 'Joaquin', 'Alonso', 'Serrano', 'Giraldo', '2010-03-08', 'M', 'Transversal 21 # 104-50', '3169990011', 'joaquin.serrano@estudiante.edu.co', 'O+', 'Ibuprofeno', 'Ninguna', '2020-01-20', 'Activo'),
(18, 'TI', '1098765448', 'Antonella', 'Rocio', 'Acosta', 'Chavez', '2013-12-24', 'F', 'Carrera 15 # 134-80', '3181112233', 'antonella.acosta@estudiante.edu.co', 'A+', 'Ninguna', 'Ninguna', '2021-01-20', 'Activo'),
(19, 'TI', '1098765449', 'Tomas', 'Enrique', 'Perez', 'Gomez', '2018-05-14', 'M', 'Calle 134 # 19-45', '3101112233', 'tomas.perez@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2023-01-20', 'Activo'),
(20, 'TI', '1098765450', 'Emilia', 'Fernanda', 'Restrepo', 'Castro', '2019-02-28', 'F', 'Calle 140 # 9-60', '3123334455', 'emilia.restrepo@estudiante.edu.co', 'A+', 'Ninguna', 'Ninguna', '2024-01-20', 'Activo'),
(21, 'TI', '1098765451', 'Julian', 'David', 'Castro', 'Mendoza', '2008-11-19', 'M', 'Diagonal 127A # 58-12', '3134445566', 'julian.castro@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2018-01-15', 'Activo'),
(22, 'TI', '1098765452', 'Salome', 'Beatriz', 'Morales', 'Quintero', '2010-01-30', 'F', 'Transversal 23 # 98-15', '3156667788', 'salome.morales@estudiante.edu.co', 'B+', 'Ninguna', 'Ninguna', '2020-01-20', 'Activo'),
(23, 'TI', '1098765453', 'Jeronomo', 'Alberto', 'Ortiz', 'Pena', '2009-06-21', 'M', 'Carrera 58 # 137B-10', '3178889900', 'jeronimo.ortiz@estudiante.edu.co', 'O+', 'Picadura de abeja', 'Ninguna', '2019-01-15', 'Activo'),
(24, 'TI', '1098765454', 'Victoria', 'Eugenia', 'Mendoza', 'Romero', '2012-10-10', 'F', 'Carrera 19A # 120-40', '3190001122', 'victoria.mendoza@estudiante.edu.co', 'A+', 'Ninguna', 'Ninguna', '2021-01-20', 'Activo'),
(25, 'TI', '1098765455', 'Maximiliano', 'Jose', 'Lopez', 'Guerrero', '2014-08-15', 'M', 'Calle 170 # 8-30', '3102223344', 'maximiliano.lopez@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2022-01-20', 'Activo'),
(26, 'TI', '1098765456', 'Manuela', 'Ines', 'Torres', 'Suarez', '2008-04-05', 'F', 'Calle 147 # 19-35', '3135556677', 'manuela.torres@estudiante.edu.co', 'O-', 'Ninguna', 'Ninguna', '2018-01-15', 'Activo'),
(27, 'TI', '1098765457', 'Felipe', 'Andres', 'Cardenas', 'Chavez', '2010-12-12', 'M', 'Calle 106 # 23-40', '3157778899', 'felipe.cardenas@estudiante.edu.co', 'A+', 'Gluten (Celiaco)', 'Ninguna', '2020-01-20', 'Activo'),
(28, 'TI', '1098765458', 'Paulina', 'Astrid', 'Duarte', 'Gallego', '2011-05-23', 'F', 'Calle 122 # 15-50', '3179990011', 'paulina.duarte@estudiante.edu.co', 'O+', 'Ninguna', 'Ninguna', '2021-01-20', 'Activo'),
(29, 'TI', '1098765459', 'Simon', 'Eduardo', 'Camacho', 'Velasquez', '2009-09-09', 'M', 'Calle 138 # 45-12', '3191112233', 'simon.camacho@estudiante.edu.co', 'B-', 'Ninguna', 'Ninguna', '2019-01-15', 'Activo'),
(30, 'TI', '1098765460', 'Alicia', 'Victoria', 'Parra', 'Pinzon', '2013-07-07', 'F', 'Calle 118 # 14A-25', '3114445566', 'alicia.parra@estudiante.edu.co', 'A+', 'Ninguna', 'Ninguna', '2021-01-20', 'Activo');

-- 4. ESTUDIANTE_ACUDIENTE (Relaciones Familiares)
INSERT INTO estudiante_acudiente (id_estudiante, id_acudiente, es_principal, es_contacto_emergencia) VALUES
(1, 1, TRUE, TRUE),
(2, 1, TRUE, TRUE),
(3, 3, TRUE, TRUE),
(4, 3, TRUE, TRUE),
(5, 5, TRUE, TRUE),
(6, 7, TRUE, TRUE),
(7, 7, TRUE, TRUE),
(8, 9, TRUE, TRUE),
(9, 11, TRUE, TRUE),
(10, 13, TRUE, TRUE),
(11, 15, TRUE, TRUE),
(12, 17, TRUE, TRUE),
(13, 19, TRUE, TRUE),
(14, 21, TRUE, TRUE),
(15, 23, TRUE, TRUE),
(16, 25, TRUE, TRUE),
(17, 27, TRUE, TRUE),
(18, 29, TRUE, TRUE),
(19, 1, TRUE, TRUE),
(20, 3, TRUE, TRUE),
(21, 4, TRUE, TRUE),
(22, 6, TRUE, TRUE),
(23, 8, TRUE, TRUE),
(24, 10, TRUE, TRUE),
(25, 11, TRUE, TRUE),
(26, 14, TRUE, TRUE),
(27, 16, TRUE, TRUE),
(28, 18, TRUE, TRUE),
(29, 20, TRUE, TRUE),
(30, 22, TRUE, TRUE);

-- 5. MATERIAS (30 registros)
INSERT INTO materias (id_materia, codigo_materia, nombre_materia, descripcion, id_grado, horas_semanales, esta_activa) VALUES
(1, 'MAT-01', 'Matematicas Basicas I', 'Fundamentos aritmeticos y resolucion de problemas', 2, 5, TRUE),
(2, 'ESP-01', 'Lengua Castellana I', 'Lectoescritura, comprension y expresion oral', 2, 5, TRUE),
(3, 'CN-01', 'Ciencias Naturales I', 'El entorno vivo, materia y energia', 2, 3, TRUE),
(4, 'ING-01', 'Ingles Inicial A1', 'Vocabulario basico, canciones y frases cotidianas', 2, 4, TRUE),
(5, 'SOC-01', 'Ciencias Sociales I', 'Mi comunidad, historia familiar y geografia local', 2, 3, TRUE),
(6, 'EDF-01', 'Educacion Fisica I', 'Motricidad basica, coordinacion y juegos', 2, 2, TRUE),
(7, 'ART-01', 'Educacion Artistica I', 'Dibujo basico, modelado en plastilina y colores', 2, 2, TRUE),
(8, 'MAT-06', 'Matematicas y Aritmetica VI', 'Fracciones, proporciones, porcentajes y geometria', 7, 5, TRUE),
(9, 'ESP-06', 'Espanol y Literatura VI', 'Tipologias textuales, gramatica y analisis literario', 7, 4, TRUE),
(10, 'BIO-06', 'Biologia General', 'Estructura celular, taxonomia y ecologia', 7, 4, TRUE),
(11, 'ING-06', 'Ingles Intermedio A2', 'Estructuras gramaticales, lectura y conversacion', 7, 4, TRUE),
(12, 'HIS-06', 'Historia Universal y de Colombia', 'Civilizaciones antiguas y epoca precolombina', 7, 3, TRUE),
(13, 'GEO-06', 'Geografia de los Continentes', 'Relieve, hidrografia y demografia mundial', 7, 3, TRUE),
(14, 'TEC-06', 'Tecnologia e Informatica VI', 'Manejo de suites ofimaticas y pensamiento logico', 7, 2, TRUE),
(15, 'MUS-06', 'Musica y Ritmo', 'Solfeo basico, apreciacion musical e instrumentos', 7, 2, TRUE),
(16, 'ETI-06', 'Etica y Valores VI', 'Convivencia ciudadana, empatia y resolucion de conflictos', 7, 1, TRUE),
(17, 'EDF-06', 'Educacion Fisica y Salud VI', 'Acondicionamiento fisico y fundamentacion en deportes', 7, 2, TRUE),
(18, 'MAT-09', 'Algebra y Trigonometria IX', 'Factorizacion, ecuaciones lineales y funciones cuadraticas', 10, 5, TRUE),
(19, 'ESP-09', 'Lengua y Comunicacion IX', 'El ensayo argumentativo y literatura latinoamericana', 10, 4, TRUE),
(20, 'FIS-09', 'Fisica Mecanica Basica', 'Cinematica, dinamica y leyes del movimiento de Newton', 10, 4, TRUE),
(21, 'QUI-09', 'Quimica General e Inorganica', 'Tabla periodica, enlaces quimicos y estequiometria', 10, 4, TRUE),
(22, 'ING-09', 'Ingles B1 Pre-Intermedio', 'Ensayos cortos, debates guiados y listening formal', 10, 4, TRUE),
(23, 'FIL-09', 'Introduccion a la Filosofia', 'Presocraticos, Socrates, Platon y la etica clasica', 10, 2, TRUE),
(24, 'ROB-09', 'Robotica y Programacion', 'Logica algoritmica, microcontroladores y sensores', 10, 3, TRUE),
(25, 'CAL-11', 'Calculo Diferencial e Integral', 'Limites, derivadas, integrales y optimizacion', 12, 5, TRUE),
(26, 'FIS-11', 'Fisica Electromagnetica y Ondas', 'Termodinamica, ondas sonoras, electricidad y optica', 12, 4, TRUE),
(27, 'QUI-11', 'Quimica Organica y Bioquimica', 'Hidrocarburos, macromoleculas biologicas y laboratorio', 12, 4, TRUE),
(28, 'ING-11', 'Ingles Academico B2+', 'Preparacion de pruebas internacionales y oratoria', 12, 4, TRUE),
(29, 'ECO-11', 'Ciencias Economicas y Politicas', 'Macroeconomia, politicas publicas y democracia', 12, 3, TRUE),
(30, 'FIL-11', 'Filosofia Contemporanea', 'Existencialismo, epistemologia moderna y bioetica', 12, 2, TRUE);

-- Asignaciones de profesores a materias
INSERT INTO asignaciones_profesor (id_profesor, id_materia, `año_academico`, seccion) VALUES
(1, 1, 2026, 'A'),
(2, 2, 2026, 'A'),
(3, 3, 2026, 'A'),
(4, 4, 2026, 'A'),
(5, 5, 2026, 'A'),
(1, 8, 2026, 'A'),
(2, 9, 2026, 'A'),
(3, 10, 2026, 'A'),
(4, 11, 2026, 'A'),
(5, 12, 2026, 'A'),
(19, 18, 2026, 'A'),
(16, 19, 2026, 'A'),
(13, 20, 2026, 'A'),
(9, 21, 2026, 'A'),
(1, 25, 2026, 'A');

-- 6. MATRICULAS (30 registros)
INSERT INTO matriculas (id_matricula, id_estudiante, id_grado, `año_academico`, estado_matricula, fecha_matricula) VALUES
(1, 1, 8, 2026, 'Activa', '2026-01-15'),
(2, 2, 5, 2026, 'Activa', '2026-01-15'),
(3, 3, 10, 2026, 'Activa', '2026-01-16'),
(4, 4, 6, 2026, 'Activa', '2026-01-16'),
(5, 5, 8, 2026, 'Activa', '2026-01-17'),
(6, 6, 3, 2026, 'Activa', '2026-01-17'),
(7, 7, 2, 2026, 'Activa', '2026-01-18'),
(8, 8, 12, 2026, 'Activa', '2026-01-18'),
(9, 9, 10, 2026, 'Activa', '2026-01-19'),
(10, 10, 6, 2026, 'Activa', '2026-01-19'),
(11, 11, 8, 2026, 'Activa', '2026-01-20'),
(12, 12, 5, 2026, 'Activa', '2026-01-20'),
(13, 13, 12, 2026, 'Activa', '2026-01-21'),
(14, 14, 2, 2026, 'Activa', '2026-01-21'),
(15, 15, 10, 2026, 'Activa', '2026-01-22'),
(16, 16, 6, 2026, 'Activa', '2026-01-22'),
(17, 17, 8, 2026, 'Activa', '2026-01-23'),
(18, 18, 3, 2026, 'Activa', '2026-01-23'),
(19, 19, 1, 2026, 'Activa', '2026-01-24'),
(20, 20, 1, 2026, 'Activa', '2026-01-24'),
(21, 21, 12, 2026, 'Activa', '2026-01-25'),
(22, 22, 8, 2026, 'Activa', '2026-01-25'),
(23, 23, 10, 2026, 'Activa', '2026-01-26'),
(24, 24, 5, 2026, 'Activa', '2026-01-26'),
(25, 25, 2, 2026, 'Activa', '2026-01-27'),
(26, 26, 12, 2026, 'Activa', '2026-01-27'),
(27, 27, 8, 2026, 'Activa', '2026-01-28'),
(28, 28, 6, 2026, 'Activa', '2026-01-28'),
(29, 29, 10, 2026, 'Activa', '2026-01-29'),
(30, 30, 3, 2026, 'Activa', '2026-01-29');

-- 7. REGISTROS_ACADEMICOS (40 calificaciones)
INSERT INTO registros_academicos (id_registro, id_estudiante, id_materia, id_profesor, `año_academico`, periodo_academico, valor_nota, observaciones, fecha_registro) VALUES
(1, 1, 8, 1, 2026, 'I', 4.5, 'Excelente dominio conceptual en fracciones y razones.', '2026-03-20'),
(2, 1, 9, 2, 2026, 'I', 4.2, 'Buena expresion escrita y analisis textual.', '2026-03-20'),
(3, 1, 10, 3, 2026, 'I', 3.8, 'Entrega oportuna de talleres y guias de laboratorio.', '2026-03-20'),
(4, 1, 11, 4, 2026, 'I', 4.7, 'Fluidez destacada en comunicacion verbal en ingles.', '2026-03-20'),
(5, 5, 8, 1, 2026, 'I', 3.5, 'Requiere afianzar operaciones complejas con racionales.', '2026-03-20'),
(6, 5, 9, 2, 2026, 'I', 4.0, 'Buen desempeno en redaccion y ortografia.', '2026-03-20'),
(7, 5, 10, 3, 2026, 'I', 4.3, 'Gran participacion e interes en ciencias biologicas.', '2026-03-20'),
(8, 11, 8, 1, 2026, 'I', 4.8, 'Desempeno sobresaliente en olimpiadas matematicas internas.', '2026-03-20'),
(9, 11, 9, 2, 2026, 'I', 4.5, 'Excelente comprension lectora y juicio critico.', '2026-03-20'),
(10, 17, 8, 1, 2026, 'I', 2.9, 'Dificultades en resolucion de problemas algebraicos basicos.', '2026-03-20'),
(11, 17, 9, 2, 2026, 'I', 3.7, 'Cumple satisfactoriamente con los logros previstos.', '2026-03-20'),
(12, 22, 8, 1, 2026, 'I', 4.1, 'Puntual y dedicada en sus entregas academicas.', '2026-03-20'),
(13, 27, 8, 1, 2026, 'I', 3.6, 'Buen desempeno general en clase.', '2026-03-20'),
(14, 3, 18, 19, 2026, 'I', 4.6, 'Destacada habilidad en factorizacion y productos notables.', '2026-03-20'),
(15, 3, 19, 16, 2026, 'I', 4.1, 'Buena argumentacion en composicion de ensayos.', '2026-03-20'),
(16, 3, 20, 13, 2026, 'I', 4.4, 'Excelente comprension de problemas fisicos de cinematica.', '2026-03-20'),
(17, 9, 18, 19, 2026, 'I', 3.2, 'Debe reforzar despeje de formulas y ecuaciones lineales.', '2026-03-20'),
(18, 9, 20, 13, 2026, 'I', 3.5, 'Aprobado con recomendaciones para el segundo periodo.', '2026-03-20'),
(19, 15, 18, 19, 2026, 'I', 4.9, 'Rendimiento optimo, mejor promedio del curso.', '2026-03-20'),
(20, 15, 21, 9, 2026, 'I', 4.7, 'Gran destreza en estequiometria y enlaces quimicos.', '2026-03-20'),
(21, 23, 18, 19, 2026, 'I', 3.9, 'Buen trabajo en equipo y sustentaciones claras.', '2026-03-20'),
(22, 29, 18, 19, 2026, 'I', 4.3, 'Compromiso constante con el aprendizaje.', '2026-03-20'),
(23, 8, 25, 1, 2026, 'I', 4.6, 'Alta capacidad analitica en calculo de limites.', '2026-03-20'),
(24, 8, 26, 13, 2026, 'I', 4.5, 'Excelente desempeno en practicas de laboratorio de fisica.', '2026-03-20'),
(25, 8, 27, 28, 2026, 'I', 4.8, 'Proyecto de investigacion en quimica organica sobresaliente.', '2026-03-20'),
(26, 8, 28, 20, 2026, 'I', 5.0, 'Nivel de bilinguismo certificado C1 internacional.', '2026-03-20'),
(27, 13, 25, 1, 2026, 'I', 3.8, 'Buen desarrollo de talleres y evaluacion final.', '2026-03-20'),
(28, 13, 26, 13, 2026, 'I', 4.0, 'Participacion activa y buenos resultados practicos.', '2026-03-20'),
(29, 21, 25, 1, 2026, 'I', 4.2, 'Buen manejo de conceptos matematicos avanzados.', '2026-03-20'),
(30, 26, 25, 1, 2026, 'I', 4.4, 'Dedicacion y rigor en sus trabajos academicos.', '2026-03-20'),
(31, 1, 8, 1, 2026, 'II', 4.6, 'Consolida su rendimiento en proporcionalidad y porcentajes.', '2026-06-15'),
(32, 1, 9, 2, 2026, 'II', 4.4, 'Excelente produccion escrita en informe de lectura.', '2026-06-15'),
(33, 5, 8, 1, 2026, 'II', 3.9, 'Muestra una notable mejoria respecto al primer periodo.', '2026-06-15'),
(34, 11, 8, 1, 2026, 'II', 4.9, 'Sigue manteniendo el liderazgo academico del grupo.', '2026-06-15'),
(35, 17, 8, 1, 2026, 'II', 3.4, 'Supero las dificultades iniciales mediante plan de refuerzo.', '2026-06-15'),
(36, 3, 18, 19, 2026, 'II', 4.8, 'Excelente asimilacion de funciones trigonometricas.', '2026-06-15'),
(37, 15, 18, 19, 2026, 'II', 5.0, 'Calificacion perfecta en evaluacion bimestral.', '2026-06-15'),
(38, 8, 25, 1, 2026, 'II', 4.7, 'Destacada formulacion de derivadas e integrales.', '2026-06-15'),
(39, 13, 25, 1, 2026, 'II', 4.1, 'Progreso sostenido durante el periodo.', '2026-06-15'),
(40, 21, 25, 1, 2026, 'II', 4.5, 'Claridad teorica y solida argumentacion matematica.', '2026-06-15');

-- 8. ASISTENCIAS (35 registros diarios)
INSERT INTO asistencias (id_asistencia, id_estudiante, id_materia, fecha_asistencia, estado_asistencia, observaciones, registrado_por) VALUES
(1, 1, 8, '2026-03-02', 'Presente', NULL, 1),
(2, 1, 8, '2026-03-03', 'Presente', NULL, 1),
(3, 1, 8, '2026-03-04', 'Presente', NULL, 1),
(4, 5, 8, '2026-03-02', 'Presente', NULL, 1),
(5, 5, 8, '2026-03-03', 'Tardanza', 'Retraso en ruta escolar por congestion vehicular', 1),
(6, 5, 8, '2026-03-04', 'Presente', NULL, 1),
(7, 11, 8, '2026-03-02', 'Presente', NULL, 1),
(8, 11, 8, '2026-03-03', 'Presente', NULL, 1),
(9, 17, 8, '2026-03-02', 'Ausente', 'Incapacidad medica por virosis respiratoria', 1),
(10, 17, 8, '2026-03-03', 'Ausente', 'Incapacidad medica certificada por EPS', 1),
(11, 17, 8, '2026-03-04', 'Ausente', 'Continuacion de reposo medico', 1),
(12, 17, 8, '2026-03-05', 'Ausente', 'Seguimiento medico', 1),
(13, 22, 8, '2026-03-02', 'Presente', NULL, 1),
(14, 27, 8, '2026-03-02', 'Presente', NULL, 1),
(15, 3, 18, '2026-03-02', 'Presente', NULL, 19),
(16, 3, 18, '2026-03-04', 'Presente', NULL, 19),
(17, 9, 18, '2026-03-02', 'Ausente', 'Calamidad domestica familiar', 19),
(18, 9, 18, '2026-03-04', 'Presente', NULL, 19),
(19, 15, 18, '2026-03-02', 'Presente', NULL, 19),
(20, 23, 18, '2026-03-02', 'Tardanza', 'Llegada 10 minutos tarde', 19),
(21, 29, 18, '2026-03-02', 'Presente', NULL, 19),
(22, 8, 25, '2026-03-03', 'Presente', NULL, 1),
(23, 8, 25, '2026-03-05', 'Presente', NULL, 1),
(24, 13, 25, '2026-03-03', 'Presente', NULL, 1),
(25, 21, 25, '2026-03-03', 'Presente', NULL, 1),
(26, 26, 25, '2026-03-03', 'Presente', NULL, 1),
(27, 17, 9, '2026-03-02', 'Ausente', 'Permiso medico', 2),
(28, 17, 9, '2026-03-03', 'Ausente', 'Permiso medico', 2),
(29, 17, 9, '2026-03-04', 'Ausente', 'Permiso medico', 2),
(30, 17, 10, '2026-03-02', 'Ausente', 'Permiso medico', 3),
(31, 1, 9, '2026-03-02', 'Presente', NULL, 2),
(32, 2, 1, '2026-03-02', 'Presente', NULL, 1),
(33, 4, 1, '2026-03-02', 'Presente', NULL, 1),
(34, 6, 1, '2026-03-02', 'Presente', NULL, 1),
(35, 7, 1, '2026-03-02', 'Presente', NULL, 1);

-- 9. CLUBES EXTRACURRICULARES (12 registros)
INSERT INTO clubes (id_club, nombre_club, descripcion, id_profesor_supervisor, capacidad_maxima, horario_reunion, esta_activo) VALUES
(1, 'Club de Robotica y Programacion', 'Diseno de circuitos, sensores y programacion en Arduino y Python', 23, 20, 'Martes y Jueves 3:30 - 5:00 PM', TRUE),
(2, 'Club de Ajedrez Little Horizons', 'Estrategia, tactica y preparacion para torneos intercolegiados', 27, 25, 'Miercoles y Viernes 3:30 - 5:00 PM', TRUE),
(3, 'Club de Danza y Expresion Folclorica', 'Formacion en ritmos colombianos tradicionales y danza contemporanea', 22, 25, 'Lunes y Miercoles 3:30 - 5:00 PM', TRUE),
(4, 'Club de Astronomia y Ciencias Espaciales', 'Observacion telescopica, astrofisica basica y exploracion espacial', 13, 20, 'Viernes 4:00 - 6:00 PM', TRUE),
(5, 'Club de Debate y Modelo ONU (MUN)', 'Oratoria, negociacion diplomatica y analisis geopolitico internacional', 4, 30, 'Martes y Jueves 3:30 - 5:30 PM', TRUE),
(6, 'Banda Sinfonica y Coro Escolar', 'Ensamble orquestal, tecnica vocal y lectura de partituras', 29, 35, 'Lunes, Miercoles y Viernes 3:30 - 5:30 PM', TRUE),
(7, 'Club de Teatro y Artes Escenicas', 'Expresion corporal, improvisacion y montaje de obras teatrales', 26, 20, 'Martes y Jueves 3:30 - 5:00 PM', TRUE),
(8, 'Escuela Deportiva de Futbol', 'Entrenamiento tactico, preparacion fisica y torneos formativos', 25, 30, 'Lunes y Miercoles 3:30 - 5:30 PM', TRUE),
(9, 'Club de Artes Plasticas y Pintura', 'Tecnicas de oleo, acuarela, escultura y exposiciones estudiantiles', 8, 20, 'Jueves 3:30 - 5:30 PM', TRUE),
(10, 'Club de Ecologia y Huerto Escolar', 'Sostenibilidad ambiental, reciclaje y cultivo de huerta organica', 24, 25, 'Miercoles 3:30 - 5:00 PM', TRUE),
(11, 'Club de Periodismo y Revista Escolar', 'Redaccion periodistica, fotografia escolar y edicion digital', 16, 15, 'Viernes 3:30 - 5:00 PM', TRUE),
(12, 'Club de Baloncesto y Voleibol', 'Fundamentos deportivos, trabajo en equipo y partidos amistosos', 6, 25, 'Martes y Jueves 3:30 - 5:00 PM', TRUE);

-- 10. MEMBRESIAS_CLUB (30 registros)
INSERT INTO membresias_club (id_membresia, id_estudiante, id_club, fecha_ingreso, estado_membresia, fecha_retiro, motivo_retiro) VALUES
(1, 1, 1, '2026-02-01', 'Activa', NULL, NULL),
(2, 1, 2, '2026-02-01', 'Activa', NULL, NULL),
(3, 3, 1, '2026-02-02', 'Activa', NULL, NULL),
(4, 3, 5, '2026-02-02', 'Activa', NULL, NULL),
(5, 5, 8, '2026-02-03', 'Activa', NULL, NULL),
(6, 8, 5, '2026-02-03', 'Activa', NULL, NULL),
(7, 8, 6, '2026-02-03', 'Activa', NULL, NULL),
(8, 9, 8, '2026-02-04', 'Activa', NULL, NULL),
(9, 11, 2, '2026-02-04', 'Activa', NULL, NULL),
(10, 11, 4, '2026-02-04', 'Activa', NULL, NULL),
(11, 12, 3, '2026-02-05', 'Activa', NULL, NULL),
(12, 13, 1, '2026-02-05', 'Activa', NULL, NULL),
(13, 15, 4, '2026-02-06', 'Activa', NULL, NULL),
(14, 15, 10, '2026-02-06', 'Activa', NULL, NULL),
(15, 16, 7, '2026-02-07', 'Activa', NULL, NULL),
(16, 17, 8, '2026-02-07', 'Activa', NULL, NULL),
(17, 21, 5, '2026-02-08', 'Activa', NULL, NULL),
(18, 22, 9, '2026-02-08', 'Activa', NULL, NULL),
(19, 23, 2, '2026-02-09', 'Activa', NULL, NULL),
(20, 24, 3, '2026-02-09', 'Activa', NULL, NULL),
(21, 26, 6, '2026-02-10', 'Activa', NULL, NULL),
(22, 27, 12, '2026-02-10', 'Activa', NULL, NULL),
(23, 28, 11, '2026-02-11', 'Activa', NULL, NULL),
(24, 29, 8, '2026-02-11', 'Activa', NULL, NULL),
(25, 30, 9, '2026-02-12', 'Activa', NULL, NULL),
(26, 2, 7, '2026-02-12', 'Activa', NULL, NULL),
(27, 4, 3, '2026-02-13', 'Activa', NULL, NULL),
(28, 6, 9, '2026-02-13', 'Activa', NULL, NULL),
(29, 7, 8, '2026-02-14', 'Activa', NULL, NULL),
(30, 10, 1, '2026-02-01', 'Retirada', '2026-03-10', 'Cruce de horarios con clases particulares de piano');

-- 11. EVENTOS INSTITUCIONALES (10 registros)
INSERT INTO eventos (id_evento, nombre_evento, descripcion, tipo_evento, fecha_evento, lugar, tiene_competencia, id_organizador, esta_activo) VALUES
(1, 'Olimpiada Interna de Matematicas y Logica', 'Competencia de resolucion de problemas y acertijos matematicos', 'Académico', '2026-04-10', 'Auditorio Principal', TRUE, 1, TRUE),
(2, 'Feria Escolar de la Ciencia y Tecnologia', 'Exposicion de proyectos de investigacion, ecologia y robotica', 'Científico', '2026-05-22', 'Coliseo Deportivo y Patios', TRUE, 3, TRUE),
(3, 'Spelling Bee Little Horizons 2026', 'Concurso de deletreo en ingles por categorias de primaria y bachillerato', 'Académico', '2026-06-05', 'Auditorio Principal', TRUE, 4, TRUE),
(4, 'Festival de Danzas y Folclor Colombiano', 'Muestra cultural de bailes tipicos y tradiciones de las regiones', 'Cultural', '2026-06-18', 'Teatro Institucional', FALSE, 22, TRUE),
(5, 'Torneo Intercolegiado de Futbol 8', 'Campeonato deportivo con instituciones invitadas de la localidad', 'Deportivo', '2026-08-14', 'Canchas Sinteticas', TRUE, 25, TRUE),
(6, 'Torneo de Ajedrez Jaque Mate', 'Torneo suizo a 5 rondas para primaria y secundaria', 'Deportivo', '2026-08-28', 'Biblioteca Escolar', TRUE, 27, TRUE),
(7, 'Dia de la Familia y la Convivencia', 'Jornada recreativa, gastronomica y de integracion comunitaria', 'Social', '2026-09-12', 'Campus Escolar Completo', FALSE, 18, TRUE),
(8, 'Modelo de Naciones Unidas LH-MUN 2026', 'Simulacion diplomatica de comites de la ONU en ingles y espanol', 'Académico', '2026-10-08', 'Salones y Salas de Conferencias', TRUE, 5, TRUE),
(9, 'Concierto de Gala de la Banda Sinfonica', 'Presentacion musical de cierre de ano de la orquesta y coros', 'Cultural', '2026-11-20', 'Teatro Institucional', FALSE, 29, TRUE),
(10, 'Exposicion Artistica Pinceles de Esperanza', 'Galeria de pintura, escultura y fotografia realizada por estudiantes', 'Cultural', '2026-11-27', 'Salon de Eventos Culturales', TRUE, 8, TRUE);

-- 12. PARTICIPANTES_EVENTO (30 registros)
INSERT INTO participantes_evento (id_participacion, id_evento, id_estudiante, rol_participacion, posicion_obtenida, observaciones) VALUES
(1, 1, 1, 'Competidor', '1er Lugar', 'Puntaje perfecto en prueba de logica y geometria'),
(2, 1, 11, 'Competidor', '2do Lugar', 'Excelente resolucion en fase de desempate'),
(3, 1, 15, 'Competidor', '3er Lugar', 'Destacado en calculo mental y algebra'),
(4, 1, 3, 'Competidor', 'Participante', 'Participacion sobresaliente'),
(5, 1, 8, 'Organizador', NULL, 'Apoyo en logistica y cronometraje de la prueba'),
(6, 2, 1, 'Competidor', '1er Lugar', 'Proyecto: Brazo robotico controlado por Arduino'),
(7, 2, 3, 'Competidor', '2do Lugar', 'Proyecto: Sensor de calidad del aire institucional'),
(8, 2, 15, 'Competidor', '3er Lugar', 'Proyecto: Biodigestor y energia renovable escolar'),
(9, 2, 13, 'Competidor', 'Participante', 'Proyecto: Filtro purificador de agua pluvial'),
(10, 2, 8, 'Organizador', NULL, 'Coordinacion de stands y evaluacion con jurados'),
(11, 3, 4, 'Competidor', '1er Lugar', 'Ganadora invicta de la categoria junior'),
(12, 3, 10, 'Competidor', '2do Lugar', 'Finalista tras 12 rondas de palabras complejas'),
(13, 3, 2, 'Competidor', '3er Lugar', 'Excelente pronunciacion y seguridad'),
(14, 3, 16, 'Competidor', 'Participante', 'Ronda semifinal alcanzada'),
(15, 3, 28, 'Competidor', 'Participante', 'Buen desempeno en ronda inicial'),
(16, 5, 5, 'Competidor', '1er Lugar', 'Capitan del equipo campeon de futbol'),
(17, 5, 9, 'Competidor', '1er Lugar', 'Goleador del torneo con 8 anotaciones'),
(18, 5, 17, 'Competidor', '1er Lugar', 'Valla menos vencida del campeonato'),
(19, 5, 29, 'Competidor', '1er Lugar', 'Mediocampista destacado'),
(20, 5, 27, 'Competidor', '2do Lugar', 'Equipo subcampeon de la jornada'),
(21, 6, 1, 'Competidor', '1er Lugar', 'Campeon invicto con 5 puntos de 5 posibles'),
(22, 6, 11, 'Competidor', '2do Lugar', 'Subcampeon por sistema de desempate Buchholz'),
(23, 6, 23, 'Competidor', '3er Lugar', 'Gran torneo en la categoria intermedia'),
(24, 6, 22, 'Competidor', 'Participante', 'Posicion 4 en la clasificacion general'),
(25, 8, 3, 'Competidor', '1er Lugar', 'Mejor Delegado en Comite de Seguridad ONU'),
(26, 8, 8, 'Competidor', '2do Lugar', 'Delegada Sobresaliente en Comite de DDHH'),
(27, 8, 21, 'Competidor', 'Participante', 'Mejor papel de posicion diplomatica'),
(28, 8, 26, 'Organizador', NULL, 'Secretaria General del Modelo LH-MUN'),
(29, 10, 22, 'Competidor', '1er Lugar', 'Obra premiada: Atardecer en los Cerros Orientales'),
(30, 10, 30, 'Competidor', '2do Lugar', 'Escultura en arcilla de fauna andina');

-- 13. RECURSOS E INVENTARIO (30 registros)
INSERT INTO recursos (id_recurso, codigo_recurso, nombre_recurso, id_categoria, descripcion, fecha_adquisicion, ubicacion_fisica, estado_recurso) VALUES
(1, 'LIB-001', 'Cien Anos de Soledad - Gabriel Garcia Marquez', 1, 'Edicion conmemorativa ilustrada RAE', '2021-03-10', 'Biblioteca - Estante A1', 'Disponible'),
(2, 'LIB-002', 'Don Quijote de la Mancha - Miguel de Cervantes', 1, 'Edicion critica comentada', '2020-05-15', 'Biblioteca - Estante A2', 'Disponible'),
(3, 'LIB-003', 'Algebra de Baldor con CD interactivo', 1, 'Texto guia clasico para algebra de secundaria', '2022-01-20', 'Biblioteca - Estante B1', 'Prestado'),
(4, 'LIB-004', 'Fisica Universitaria - Sears y Zemansky (Vol 1)', 1, 'Mecanica, ondas y termodinamica', '2021-08-10', 'Biblioteca - Estante B2', 'Disponible'),
(5, 'LIB-005', 'Quimica General - Raymond Chang', 1, 'Texto universitario para 10 y 11', '2021-09-05', 'Biblioteca - Estante B3', 'Prestado'),
(6, 'LIB-006', 'Biologia Celular y Molecular - Karp', 1, 'Guia avanzada de citologia y genetica', '2022-02-14', 'Biblioteca - Estante B4', 'Disponible'),
(7, 'LIB-007', 'El Principito - Antoine de Saint-Exupery', 1, 'Edicion bilingue ingles-espanol', '2020-11-18', 'Biblioteca - Estante C1', 'Disponible'),
(8, 'LIB-008', 'Historia de Colombia y sus Oligarquias', 1, 'Texto ilustrado por Antonio Caballero', '2019-07-22', 'Biblioteca - Estante C2', 'Disponible'),
(9, 'LIB-009', 'Diccionario Oxford Advanced Learners', 1, 'Diccionario de referencia en lengua inglesa', '2021-02-01', 'Biblioteca - Estante D1', 'Prestado'),
(10, 'LIB-010', 'Calculo de una Variable - James Stewart', 1, 'Texto fundamental para calculo de grado 11', '2022-03-15', 'Biblioteca - Estante B1', 'Disponible'),
(11, 'LAB-001', 'Microscopio Optico Binocular Olympus CX23', 2, 'Aumentos 4x, 10x, 40x y 100x con luz LED', '2022-04-10', 'Laboratorio de Biologia - Modulo 1', 'Disponible'),
(12, 'LAB-002', 'Microscopio Optico Binocular Olympus CX23', 2, 'Aumentos 4x, 10x, 40x y 100x con luz LED', '2022-04-10', 'Laboratorio de Biologia - Modulo 2', 'Prestado'),
(13, 'LAB-003', 'Balanza Analitica Digital de Precision Ohaus', 2, 'Sensibilidad 0.0001g para practicas de quimica', '2021-06-18', 'Laboratorio de Quimica - Mesa Central', 'Disponible'),
(14, 'LAB-004', 'Kit de Sensores Pasco para Fisica Mecanica', 2, 'Fotoceldas, carritos de friccion y riel metalico', '2023-01-25', 'Laboratorio de Fisica - Armario 3', 'Disponible'),
(15, 'LAB-005', 'Centrifuga Clinica Digital 8 Tubos', 2, 'Velocidad ajustable hasta 4000 RPM', '2022-09-12', 'Laboratorio de Biologia - Modulo 3', 'En Mantenimiento'),
(16, 'LAB-006', 'Espectrofotometro UV-Visible VisibleLab', 2, 'Medicion de absorbancia y concentracion quimica', '2023-03-01', 'Laboratorio de Quimica - Armario 1', 'Disponible'),
(17, 'LAB-007', 'Kit de Diseccion Anatomica en Acero Inoxidable', 2, 'Estuche con bisturi, pinzas, tijeras y sondas', '2021-10-15', 'Laboratorio de Biologia - Armario 2', 'Disponible'),
(18, 'LAB-008', 'Telescopio Astronomico Celestron NexStar 130SLT', 2, 'Reflector computarizado con montura automatizada', '2022-07-20', 'Observatorio Escolar - Terraza', 'Disponible'),
(19, 'DEP-001', 'Balon de Futbol No. 5 Golty Profesional', 3, 'Balon oficial avalado por la Dimayor', '2023-02-10', 'Almacen Deportivo - Cesta 1', 'Disponible'),
(20, 'DEP-002', 'Balon de Baloncesto Molten BG3800 No. 7', 3, 'Cuero sintetico para duela y exteriores', '2023-02-10', 'Almacen Deportivo - Cesta 2', 'Disponible'),
(21, 'DEP-003', 'Balon de Voleibol Mikasa V200W Profesional', 3, 'Diseno de 18 paneles con microfibra', '2023-02-10', 'Almacen Deportivo - Cesta 3', 'Prestado'),
(22, 'DEP-004', 'Set de 20 Conos de Entrenamiento y Vallas', 3, 'Conos flexibles y vallas de agilidad', '2022-11-05', 'Almacen Deportivo - Estante B', 'Disponible'),
(23, 'DEP-005', 'Cronometro Digital Profesional Casio', 3, 'Memoria de 100 laps y precision centesimal', '2022-05-18', 'Oficina Educacion Fisica', 'Prestado'),
(24, 'TEC-001', 'Portatil Lenovo ThinkPad E14 Gen 4', 4, 'Intel Core i5, 16GB RAM, SSD 512GB para docentes', '2023-01-15', 'Sala de Profesores - Locker 5', 'Prestado'),
(25, 'TEC-002', 'Tablet Samsung Galaxy Tab S6 Lite con S-Pen', 4, 'Tablet para dibujo digital y proyectos escolares', '2023-04-20', 'Aula de Informatica - Carrito C1', 'Disponible'),
(26, 'TEC-003', 'Tablet Samsung Galaxy Tab S6 Lite con S-Pen', 4, 'Tablet para dibujo digital y proyectos escolares', '2023-04-20', 'Aula de Informatica - Carrito C1', 'Prestado'),
(27, 'TEC-004', 'Video Beam Epson PowerLite E20', 4, 'Proyector 3400 lumenes XGA para presentaciones', '2022-08-30', 'Coordinacion Academica', 'Prestado'),
(28, 'TEC-005', 'Kit de Robotica Lego Mindstorms EV3 Education', 4, 'Set educativo con sensores ultrasonicos y motores', '2022-06-15', 'Laboratorio de Robotica - Armario 1', 'Disponible'),
(29, 'TEC-006', 'Calculadora Cientifica Graficadora TI-84 Plus', 4, 'Calculadora para estudiantes de fisica y calculo 11', '2023-02-01', 'Biblioteca - Vitrina Tecnologica', 'Disponible'),
(30, 'MAT-001', 'Modelo Anatomico del Torso Humano Desarmable', 5, 'Modelo de 85 cm con 27 partes removibles', '2021-04-12', 'Laboratorio de Biologia - Estante 4', 'Disponible');

-- 14. PRESTAMOS_ESTUDIANTE (20 registros)
INSERT INTO prestamos_estudiante (id_prestamo, id_estudiante, id_recurso, fecha_prestamo, fecha_devolucion_esperada, fecha_devolucion_real, estado_prestamo, observaciones) VALUES
(1, 1, 3, '2026-03-01', '2026-03-08', NULL, 'Activo', 'Prestamo para preparacion de evaluacion bimestral'),
(2, 3, 5, '2026-03-02', '2026-03-09', NULL, 'Activo', 'Guia de quimica organica'),
(3, 8, 9, '2026-02-15', '2026-02-22', NULL, 'Vencido', 'Prestamo vencido pendiente de devolucion urgente'),
(4, 11, 26, '2026-03-03', '2026-03-10', NULL, 'Activo', 'Tablet para proyecto de diseno asistido'),
(5, 5, 21, '2026-02-20', '2026-02-27', NULL, 'Vencido', 'Material deportivo para practica en casa'),
(6, 15, 1, '2026-02-05', '2026-02-12', '2026-02-11', 'Devuelto', 'Entregado en perfecto estado'),
(7, 17, 2, '2026-02-08', '2026-02-15', '2026-02-14', 'Devuelto', 'Lectura completada a tiempo'),
(8, 21, 4, '2026-02-10', '2026-02-17', '2026-02-16', 'Devuelto', 'Devolucion sin novedades'),
(9, 23, 7, '2026-02-12', '2026-02-19', '2026-02-18', 'Devuelto', 'Excelente cuidado del libro'),
(10, 26, 8, '2026-02-14', '2026-02-21', '2026-02-20', 'Devuelto', 'Libro devuelto a biblioteca'),
(11, 28, 10, '2026-02-16', '2026-02-23', '2026-02-22', 'Devuelto', 'Devuelto satisfactoriamente'),
(12, 1, 14, '2026-02-18', '2026-02-25', '2026-02-24', 'Devuelto', 'Kit de sensores devuelto completo'),
(13, 3, 17, '2026-02-20', '2026-02-27', '2026-02-26', 'Devuelto', 'Estuche esterilizado y completo'),
(14, 8, 29, '2026-02-22', '2026-03-01', '2026-02-28', 'Devuelto', 'Calculadora con baterias operativas'),
(15, 11, 28, '2026-02-24', '2026-03-03', '2026-03-02', 'Devuelto', 'Set de robotica revisado por docente'),
(16, 13, 19, '2026-02-01', '2026-02-08', '2026-02-07', 'Devuelto', 'Balon limpio y calibrado'),
(17, 15, 20, '2026-02-03', '2026-02-10', '2026-02-09', 'Devuelto', 'Devuelto a utileria deportiva'),
(18, 17, 22, '2026-02-04', '2026-02-11', '2026-02-10', 'Devuelto', 'Conos completos'),
(19, 21, 25, '2026-02-06', '2026-02-13', '2026-02-12', 'Devuelto', 'Tablet sin rayones ni golpes'),
(20, 26, 30, '2026-02-07', '2026-02-14', '2026-02-13', 'Devuelto', 'Torso anatomico armado completo');

-- 15. PRESTAMOS_PROFESOR (15 registros)
INSERT INTO prestamos_profesor (id_prestamo, id_profesor, id_recurso, fecha_prestamo, fecha_devolucion_esperada, fecha_devolucion_real, estado_prestamo, observaciones) VALUES
(1, 3, 12, '2026-03-01', '2026-03-15', NULL, 'Activo', 'Microscopio para preparacion de practicas de citologia'),
(2, 6, 23, '2026-03-02', '2026-03-16', NULL, 'Activo', 'Cronometro para evaluacion de test de Cooper'),
(3, 7, 24, '2026-01-20', '2026-06-30', NULL, 'Activo', 'Portatil institucional asignado para coordinacion tecnica'),
(4, 4, 27, '2026-03-03', '2026-03-10', NULL, 'Activo', 'Video beam para sesion de cine foro en ingles'),
(5, 1, 10, '2026-01-25', '2026-02-15', '2026-02-14', 'Devuelto', 'Texto consultado para plan de estudios'),
(6, 2, 1, '2026-01-26', '2026-02-16', '2026-02-15', 'Devuelto', 'Obra utilizada en clase magistral'),
(7, 5, 8, '2026-01-27', '2026-02-17', '2026-02-16', 'Devuelto', 'Material de apoyo pedagogico'),
(8, 8, 25, '2026-02-01', '2026-02-20', '2026-02-19', 'Devuelto', 'Tablets para taller de expresion grafica'),
(9, 9, 13, '2026-02-03', '2026-02-23', '2026-02-22', 'Devuelto', 'Balanza verificada y calibrada'),
(10, 10, 15, '2026-02-05', '2026-02-25', '2026-02-24', 'Devuelto', 'Mantenimiento preventivo completado'),
(11, 11, 2, '2026-02-07', '2026-02-27', '2026-02-26', 'Devuelto', 'Texto devuelto a estanteria'),
(12, 13, 14, '2026-02-09', '2026-03-01', '2026-02-28', 'Devuelto', 'Sensores devueltos sin novedad'),
(13, 16, 7, '2026-02-10', '2026-03-02', '2026-03-01', 'Devuelto', 'Libro devuelto en optimo estado'),
(14, 23, 28, '2026-02-12', '2026-03-04', '2026-03-03', 'Devuelto', 'Kit de robotica verificado'),
(15, 27, 2, '2026-01-10', '2026-01-25', NULL, 'Vencido', 'Manual de tactica pendiente de entrega por profesor');

-- 16. PAGOS REGISTRADOS (35 registros)
INSERT INTO pagos (id_pago, id_estudiante, id_acudiente, id_concepto, monto_pagado, fecha_pago, metodo_pago, numero_recibo, año_academico, periodo_academico, notas) VALUES
(1, 1, 1, 1, 425000.0, '2026-01-20', 'Transferencia', 'REC-2026-100001', 2026, 'Anual', 'Tarifa con Descuento por Hermanos (15%)'),
(2, 2, 1, 1, 425000.0, '2026-01-20', 'Transferencia', 'REC-2026-100002', 2026, 'Anual', 'Tarifa con Descuento por Hermanos (15%)'),
(3, 3, 3, 1, 425000.0, '2026-01-21', 'Transferencia', 'REC-2026-100003', 2026, 'Anual', 'Tarifa con Descuento por Hermanos (15%)'),
(4, 4, 3, 1, 425000.0, '2026-01-21', 'Transferencia', 'REC-2026-100004', 2026, 'Anual', 'Tarifa con Descuento por Hermanos (15%)'),
(5, 5, 5, 1, 500000.0, '2026-01-22', 'Efectivo', 'REC-2026-100005', 2026, 'Anual', 'Tarifa Regular'),
(6, 6, 7, 1, 425000.0, '2026-01-22', 'Tarjeta Debito', 'REC-2026-100006', 2026, 'Anual', 'Tarifa con Descuento por Hermanos (15%)'),
(7, 7, 7, 1, 425000.0, '2026-01-22', 'Tarjeta Debito', 'REC-2026-100007', 2026, 'Anual', 'Tarifa con Descuento por Hermanos (15%)'),
(8, 8, 9, 1, 250000.0, '2026-01-23', 'Transferencia', 'REC-2026-100008', 2026, 'Anual', 'Tarifa con Beca Academica Parcial (50%)'),
(9, 9, 11, 1, 425000.0, '2026-01-23', 'Transferencia', 'REC-2026-100009', 2026, 'Anual', 'Tarifa con Descuento por Hermanos (15%)'),
(10, 10, 13, 1, 500000.0, '2026-01-24', 'Tarjeta Credito', 'REC-2026-100010', 2026, 'Anual', 'Tarifa Regular'),
(11, 11, 15, 1, 250000.0, '2026-01-24', 'Transferencia', 'REC-2026-100011', 2026, 'Anual', 'Tarifa con Beca Academica Parcial (50%)'),
(12, 12, 17, 1, 500000.0, '2026-01-25', 'Efectivo', 'REC-2026-100012', 2026, 'Anual', 'Tarifa Regular'),
(13, 13, 19, 1, 500000.0, '2026-01-25', 'Transferencia', 'REC-2026-100013', 2026, 'Anual', 'Tarifa Regular'),
(14, 14, 21, 1, 500000.0, '2026-01-26', 'Tarjeta Debito', 'REC-2026-100014', 2026, 'Anual', 'Tarifa Regular'),
(15, 15, 23, 1, 250000.0, '2026-01-26', 'Transferencia', 'REC-2026-100015', 2026, 'Anual', 'Tarifa con Beca Academica Parcial (50%)'),
(16, 16, 25, 1, 500000.0, '2026-01-27', 'Tarjeta Credito', 'REC-2026-100016', 2026, 'Anual', 'Tarifa Regular'),
(17, 17, 27, 1, 500000.0, '2026-01-27', 'Efectivo', 'REC-2026-100017', 2026, 'Anual', 'Tarifa Regular'),
(18, 18, 29, 1, 500000.0, '2026-01-28', 'Transferencia', 'REC-2026-100018', 2026, 'Anual', 'Tarifa Regular'),
(19, 19, 1, 1, 425000.0, '2026-01-28', 'Transferencia', 'REC-2026-100019', 2026, 'Anual', 'Tercer hermano matriculado (15%)'),
(20, 20, 3, 1, 425000.0, '2026-01-29', 'Transferencia', 'REC-2026-100020', 2026, 'Anual', 'Tercer hermano matriculado (15%)'),
(21, 1, 1, 2, 297500.0, '2026-02-05', 'Transferencia', 'REC-2026-100021', 2026, 'I', 'Pension Febrero con Descuento Hermanos'),
(22, 2, 1, 2, 297500.0, '2026-02-05', 'Transferencia', 'REC-2026-100022', 2026, 'I', 'Pension Febrero con Descuento Hermanos'),
(23, 3, 3, 2, 297500.0, '2026-02-05', 'Transferencia', 'REC-2026-100023', 2026, 'I', 'Pension Febrero con Descuento Hermanos'),
(24, 4, 3, 2, 297500.0, '2026-02-05', 'Transferencia', 'REC-2026-100024', 2026, 'I', 'Pension Febrero con Descuento Hermanos'),
(25, 5, 5, 2, 350000.0, '2026-02-06', 'Efectivo', 'REC-2026-100025', 2026, 'I', 'Pension Febrero Tarifa Regular'),
(26, 8, 9, 2, 175000.0, '2026-02-06', 'Transferencia', 'REC-2026-100026', 2026, 'I', 'Pension Febrero Beca Academica (50%)'),
(27, 11, 15, 2, 175000.0, '2026-02-07', 'Transferencia', 'REC-2026-100027', 2026, 'I', 'Pension Febrero Beca Academica (50%)'),
(28, 15, 23, 2, 175000.0, '2026-02-07', 'Transferencia', 'REC-2026-100028', 2026, 'I', 'Pension Febrero Beca Academica (50%)'),
(29, 1, 1, 2, 297500.0, '2026-03-05', 'Transferencia', 'REC-2026-100029', 2026, 'I', 'Pension Marzo con Descuento Hermanos'),
(30, 2, 1, 2, 297500.0, '2026-03-05', 'Transferencia', 'REC-2026-100030', 2026, 'I', 'Pension Marzo con Descuento Hermanos'),
(31, 3, 3, 2, 297500.0, '2026-03-05', 'Transferencia', 'REC-2026-100031', 2026, 'I', 'Pension Marzo con Descuento Hermanos'),
(32, 1, 1, 3, 250000.0, '2026-01-22', 'Tarjeta Debito', 'REC-2026-100032', 2026, 'Anual', 'Uniforme escolar de diario y educacion fisica'),
(33, 2, 1, 3, 250000.0, '2026-01-22', 'Tarjeta Debito', 'REC-2026-100033', 2026, 'Anual', 'Uniforme escolar de diario y educacion fisica'),
(34, 1, 1, 4, 150000.0, '2026-02-05', 'Transferencia', 'REC-2026-100034', 2026, 'I', 'Ruta de transporte escolar Febrero'),
(35, 1, 1, 5, 120000.0, '2026-02-05', 'Transferencia', 'REC-2026-100035', 2026, 'I', 'Almuerzo escolar mensual Febrero');

-- 17. FACTURAS ELECTRONICAS DIAN (20 registros con CUFE)
INSERT INTO facturas (id_factura, numero_factura, id_pago, fecha_emision, cufe, nombre_archivo_pdf, ruta_archivo) VALUES
(1, 'FE-000001', 1, '2026-01-20', '27899c14ce0c46a65b37c7b92e550350531074911e70d888fd48b02e13d8d0b3', 'factura_FE-000001.pdf', 'invoices/factura_FE-000001.pdf'),
(2, 'FE-000002', 2, '2026-01-20', 'bc989e080c072bf449cc9a186a9c9a259881c55befda9ac6d63a109424b53822', 'factura_FE-000002.pdf', 'invoices/factura_FE-000002.pdf'),
(3, 'FE-000003', 3, '2026-01-21', '9628d859b5676144a375dd15edc696d5318195baa6a5ac299fd2ad6057658e8f', 'factura_FE-000003.pdf', 'invoices/factura_FE-000003.pdf'),
(4, 'FE-000004', 4, '2026-01-21', '9436e67a3be68a38e53ab60dbac015aad592b37cb432f554a6abbc6d455d9236', 'factura_FE-000004.pdf', 'invoices/factura_FE-000004.pdf'),
(5, 'FE-000005', 5, '2026-01-22', 'b0b441934f58482b525e77dd32f3ccf1a2f783761b198ebf0fc253a52cc05450', 'factura_FE-000005.pdf', 'invoices/factura_FE-000005.pdf'),
(6, 'FE-000006', 6, '2026-01-22', '324c4d5cce08f620080255941e05ee839baeabc56cca16dcaeb8aefd1ad08cbd', 'factura_FE-000006.pdf', 'invoices/factura_FE-000006.pdf'),
(7, 'FE-000007', 7, '2026-01-22', '15905d77aa5c7fc2ba85a397a5e26e5150d8d039034e159280a3123341a7ac46', 'factura_FE-000007.pdf', 'invoices/factura_FE-000007.pdf'),
(8, 'FE-000008', 8, '2026-01-23', '0d8345e8548c726bea48ea68b6c90cdeae541258868ad3af6b4dc62a8e1f371e', 'factura_FE-000008.pdf', 'invoices/factura_FE-000008.pdf'),
(9, 'FE-000009', 9, '2026-01-23', '4aecbf09e88021d20309b86d8984f415ee40c1fadc80dc6b01c4e85cc3041fab', 'factura_FE-000009.pdf', 'invoices/factura_FE-000009.pdf'),
(10, 'FE-000010', 10, '2026-01-24', 'e2cfa10eddfc441ee5df49dddd8114fbe29245424c256e6e103a46d2ac13a6ab', 'factura_FE-000010.pdf', 'invoices/factura_FE-000010.pdf'),
(11, 'FE-000011', 11, '2026-01-24', '02369aae5d013d9a1735ba64d82214f8e5bcbe0af30d4a9078458b5c6dd3eae7', 'factura_FE-000011.pdf', 'invoices/factura_FE-000011.pdf'),
(12, 'FE-000012', 12, '2026-01-25', 'bea129423bde842b1be68df638d5740e88fad618ba2d3fa0981c8c4aed4e9a8e', 'factura_FE-000012.pdf', 'invoices/factura_FE-000012.pdf'),
(13, 'FE-000013', 13, '2026-01-25', '9e74a465ca4a3f4e621a8730e606a6dc04c761cf36e29b716e69a269957749e1', 'factura_FE-000013.pdf', 'invoices/factura_FE-000013.pdf'),
(14, 'FE-000014', 14, '2026-01-26', 'a58c4f11d622c8f64f4c7617fca044039a4afe30754ada79fed3c5fc85df491e', 'factura_FE-000014.pdf', 'invoices/factura_FE-000014.pdf'),
(15, 'FE-000015', 15, '2026-01-26', '37d2827390fd6c62f3ae7247aa32a01543288367d587d44dc6fea80cd44c2756', 'factura_FE-000015.pdf', 'invoices/factura_FE-000015.pdf'),
(16, 'FE-000016', 16, '2026-01-27', '19ab6b36f58e693df85cdb1e312810b217c133f0696024eb96a457c89003f44d', 'factura_FE-000016.pdf', 'invoices/factura_FE-000016.pdf'),
(17, 'FE-000017', 17, '2026-01-27', '84fe7888657960a44e8fc86f405d114b1809e1c8a1a205a3ea8d702b5578fd8f', 'factura_FE-000017.pdf', 'invoices/factura_FE-000017.pdf'),
(18, 'FE-000018', 18, '2026-01-28', '4634e329a61aefae688e62d053812f9fa44ff38daac59bce7e4d3b6d6aba5e65', 'factura_FE-000018.pdf', 'invoices/factura_FE-000018.pdf'),
(19, 'FE-000019', 19, '2026-01-28', '942525fd66efbfc48eaa2701e9566837323322f1c5dd3a239348b4c31b571ad2', 'factura_FE-000019.pdf', 'invoices/factura_FE-000019.pdf'),
(20, 'FE-000020', 20, '2026-01-29', '0da32c0e9c8df8eca01ca7d47383e54acac460290b3b477e253ac92d612f6668', 'factura_FE-000020.pdf', 'invoices/factura_FE-000020.pdf');

-- ============================================
-- VERIFICACION FINAL DE REGISTROS POR TABLA
-- ============================================
SELECT 'profesores' AS tabla, COUNT(*) AS total FROM profesores
UNION ALL SELECT 'acudientes', COUNT(*) FROM acudientes
UNION ALL SELECT 'estudiantes', COUNT(*) FROM estudiantes
UNION ALL SELECT 'estudiante_acudiente', COUNT(*) FROM estudiante_acudiente
UNION ALL SELECT 'materias', COUNT(*) FROM materias
UNION ALL SELECT 'asignaciones_profesor', COUNT(*) FROM asignaciones_profesor
UNION ALL SELECT 'matriculas', COUNT(*) FROM matriculas
UNION ALL SELECT 'asistencias', COUNT(*) FROM asistencias
UNION ALL SELECT 'registros_academicos', COUNT(*) FROM registros_academicos
UNION ALL SELECT 'clubes', COUNT(*) FROM clubes
UNION ALL SELECT 'membresias_club', COUNT(*) FROM membresias_club
UNION ALL SELECT 'eventos', COUNT(*) FROM eventos
UNION ALL SELECT 'participantes_evento', COUNT(*) FROM participantes_evento
UNION ALL SELECT 'categorias_recurso', COUNT(*) FROM categorias_recurso
UNION ALL SELECT 'recursos', COUNT(*) FROM recursos
UNION ALL SELECT 'prestamos_estudiante', COUNT(*) FROM prestamos_estudiante
UNION ALL SELECT 'prestamos_profesor', COUNT(*) FROM prestamos_profesor
UNION ALL SELECT 'conceptos_pago', COUNT(*) FROM conceptos_pago
UNION ALL SELECT 'pagos', COUNT(*) FROM pagos
UNION ALL SELECT 'facturas', COUNT(*) FROM facturas;
