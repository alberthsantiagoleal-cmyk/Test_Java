package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IStudentDAO;
import com.littlehorizons.erp.model.entity.Student;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements IStudentDAO {
    private static final String COLUMNS = "id_estudiante, tipo_documento, numero_documento, primer_nombre, "
            + "segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero, direccion, telefono, "
            + "correo_electronico, tipo_sangre, alergias, condiciones_medicas, fecha_ingreso, estado";

    @Override
    public void create(Student student) {
        String sql = "INSERT INTO estudiantes (tipo_documento, numero_documento, primer_nombre, segundo_nombre, "
                + "primer_apellido, segundo_apellido, fecha_nacimiento, genero, direccion, telefono, correo_electronico, "
                + "tipo_sangre, alergias, condiciones_medicas, fecha_ingreso, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, student, 1);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) student.setIdStudent(keys.getInt(1));
            }
        } catch (SQLException e) {
            throw failure("Error al registrar estudiante.", e);
        }
    }

    @Override
    public Student findById(int id) {
        return queryOne("SELECT " + COLUMNS + " FROM estudiantes WHERE id_estudiante = ?", id);
    }

    @Override
    public List<Student> findAll() {
        String sql = "SELECT " + COLUMNS + " FROM estudiantes ORDER BY id_estudiante ASC";
        List<Student> students = new ArrayList<>();
        try (PreparedStatement statement = connection().prepareStatement(sql);
             ResultSet results = statement.executeQuery()) {
            while (results.next()) students.add(map(results));
            return students;
        } catch (SQLException e) {
            throw failure("Error al consultar estudiantes.", e);
        }
    }

    @Override
    public void update(Student student) {
        String sql = "UPDATE estudiantes SET tipo_documento=?, numero_documento=?, primer_nombre=?, segundo_nombre=?, "
                + "primer_apellido=?, segundo_apellido=?, fecha_nacimiento=?, genero=?, direccion=?, telefono=?, "
                + "correo_electronico=?, tipo_sangre=?, alergias=?, condiciones_medicas=?, fecha_ingreso=?, estado=? "
                + "WHERE id_estudiante=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            bind(statement, student, 1);
            statement.setInt(17, student.getIdStudent());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw failure("Error al actualizar estudiante.", e);
        }
    }

    @Override
    public boolean existsByDocument(String documentNumber) {
        return exists("SELECT 1 FROM estudiantes WHERE numero_documento=?", documentNumber);
    }

    @Override
    public void linkGuardian(int studentId, int guardianId, boolean primary, boolean emergencyContact) {
        String sql = "INSERT INTO estudiante_acudiente (id_estudiante, id_acudiente, es_principal, es_contacto_emergencia) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setInt(2, guardianId);
            statement.setBoolean(3, primary);
            statement.setBoolean(4, emergencyContact);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw failure("Error al asociar acudiente con estudiante.", e);
        }
    }

    private Student queryOne(String sql, int id) {
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet results = statement.executeQuery()) {
                return results.next() ? map(results) : null;
            }
        } catch (SQLException e) {
            throw failure("Error al consultar estudiante por identificador.", e);
        }
    }

    private boolean exists(String sql, String documentNumber) {
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setString(1, documentNumber);
            try (ResultSet results = statement.executeQuery()) {
                return results.next();
            }
        } catch (SQLException e) {
            throw failure("Error al validar documento de estudiante.", e);
        }
    }

    private void bind(PreparedStatement statement, Student student, int index) throws SQLException {
        statement.setString(index++, student.getDocumentType());
        statement.setString(index++, student.getDocumentNumber());
        statement.setString(index++, student.getFirstName());
        statement.setString(index++, student.getMiddleName());
        statement.setString(index++, student.getFirstSurname());
        statement.setString(index++, student.getSecondSurname());
        statement.setDate(index++, Date.valueOf(student.getBirthDate()));
        statement.setString(index++, student.getGender());
        statement.setString(index++, student.getAddress());
        statement.setString(index++, student.getPhone());
        statement.setString(index++, student.getEmail());
        statement.setString(index++, student.getBloodType());
        statement.setString(index++, student.getAllergies());
        statement.setString(index++, student.getMedicalConditions());
        statement.setDate(index++, Date.valueOf(student.getAdmissionDate()));
        statement.setString(index, student.getStatus() == null ? "Activo" : student.getStatus());
    }

    private Student map(ResultSet rs) throws SQLException {
        Student student = new Student();
        student.setIdStudent(rs.getInt("id_estudiante"));
        student.setDocumentType(rs.getString("tipo_documento"));
        student.setDocumentNumber(rs.getString("numero_documento"));
        student.setFirstName(rs.getString("primer_nombre"));
        student.setMiddleName(rs.getString("segundo_nombre"));
        student.setFirstSurname(rs.getString("primer_apellido"));
        student.setSecondSurname(rs.getString("segundo_apellido"));
        student.setBirthDate(rs.getDate("fecha_nacimiento").toLocalDate());
        student.setGender(rs.getString("genero"));
        student.setAddress(rs.getString("direccion"));
        student.setPhone(rs.getString("telefono"));
        student.setEmail(rs.getString("correo_electronico"));
        student.setBloodType(rs.getString("tipo_sangre"));
        student.setAllergies(rs.getString("alergias"));
        student.setMedicalConditions(rs.getString("condiciones_medicas"));
        student.setAdmissionDate(rs.getDate("fecha_ingreso").toLocalDate());
        student.setStatus(rs.getString("estado"));
        return student;
    }

    private Connection connection() { return DatabaseConnection.getInstance(); }

    private RuntimeException failure(String message, SQLException cause) {
        LoggerHelper.logError(message, cause);
        return new RuntimeException(message, cause);
    }
}
