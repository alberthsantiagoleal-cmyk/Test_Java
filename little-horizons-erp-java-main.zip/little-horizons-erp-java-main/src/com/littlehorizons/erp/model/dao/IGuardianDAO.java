package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Guardian;
import java.util.List;

public interface IGuardianDAO {
    void create(Guardian guardian);
    Guardian findById(int id);
    List<Guardian> findAll();
    List<Guardian> findByStudentId(int studentId);
    void update(Guardian guardian);
    boolean existsByDocument(String documentNumber);
}
