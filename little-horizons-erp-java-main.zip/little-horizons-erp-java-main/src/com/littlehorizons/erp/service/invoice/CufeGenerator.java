package com.littlehorizons.erp.service.invoice;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;

/**
 * Utility to calculate the simulated CUFE (Codigo Unico de Factura Electronica)
 * compliant with DIAN technical specifications using SHA-256 hashing.
 */
public class CufeGenerator {

    private static final String NIT_EMISOR = "9005432109";
    private static final String CLAVE_TECNICA = "LH-ERP-DIAN-KEY-2024-SECURE";

    /**
     * Generates a 64-character hexadecimal SHA-256 CUFE string based on fiscal invoice data.
     *
     * @param invoiceNumber Consecutivo de la factura (e.g., 'FE-000101')
     * @param issueDate     Fecha de emision
     * @param totalAmount   Valor total pagado
     * @param studentId     ID del estudiante
     * @return 64-character lowercase hexadecimal hash
     */
    public static String generateCufe(String invoiceNumber, LocalDate issueDate, double totalAmount, int studentId) {
        String rawData = String.format("%s|%s|%s|%.2f|%d|%s",
                invoiceNumber != null ? invoiceNumber.trim() : "FE-000000",
                issueDate != null ? issueDate.toString() : LocalDate.now().toString(),
                NIT_EMISOR,
                totalAmount,
                studentId,
                CLAVE_TECNICA);

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(rawData.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            // Fallback SHA-256 should always be present in standard Java runtime
            return Long.toHexString(rawData.hashCode()) + "0123456789abcdef0123456789abcdef";
        }
    }
}
