package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.ISchoolEventDAO;
import com.littlehorizons.erp.model.entity.EventParticipant;
import com.littlehorizons.erp.model.entity.SchoolEvent;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of ISchoolEventDAO using PreparedStatements.
 */
public class SchoolEventDAOImpl implements ISchoolEventDAO {

    private static final String BASE_SELECT_EVENT =
            "SELECT e.id_evento, e.nombre_evento, e.descripcion, e.tipo_evento, e.fecha_evento, " +
            "       e.lugar, e.tiene_competencia, e.id_organizador, e.esta_activo, " +
            "       CONCAT(p.primer_nombre, ' ', COALESCE(p.primer_apellido, '')) AS nombre_organizador, " +
            "       (SELECT COUNT(*) FROM participantes_evento pe WHERE pe.id_evento = e.id_evento) AS total_participantes " +
            "FROM eventos e " +
            "LEFT JOIN profesores p ON e.id_organizador = p.id_profesor ";

    private static final String BASE_SELECT_PARTICIPANT =
            "SELECT pe.id_participacion, pe.id_evento, pe.id_estudiante, pe.rol_participacion, " +
            "       pe.posicion_obtenida, pe.observaciones, " +
            "       e.nombre_evento, " +
            "       CONCAT(es.primer_nombre, ' ', COALESCE(es.primer_apellido, '')) AS nombre_estudiante, " +
            "       es.numero_documento " +
            "FROM participantes_evento pe " +
            "INNER JOIN eventos e ON pe.id_evento = e.id_evento " +
            "INNER JOIN estudiantes es ON pe.id_estudiante = es.id_estudiante ";

    @Override
    public List<SchoolEvent> findAll() {
        String sql = BASE_SELECT_EVENT + "ORDER BY e.id_evento ASC";
        List<SchoolEvent> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToEvent(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll events: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar el catalogo de eventos.", e);
        }
        return list;
    }

    @Override
    public List<SchoolEvent> findUpcoming() {
        String sql = BASE_SELECT_EVENT + "WHERE e.fecha_evento >= CURDATE() AND e.esta_activo = TRUE ORDER BY e.fecha_evento ASC";
        List<SchoolEvent> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToEvent(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findUpcoming events: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar proximos eventos.", e);
        }
        return list;
    }

    @Override
    public SchoolEvent findById(int idEvent) {
        String sql = BASE_SELECT_EVENT + "WHERE e.id_evento = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idEvent);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEvent(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById event (" + idEvent + "): " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar evento por ID.", e);
        }
        return null;
    }

    @Override
    public void create(SchoolEvent event) {
        String sql = "INSERT INTO eventos (nombre_evento, descripcion, tipo_evento, fecha_evento, " +
                     "lugar, tiene_competencia, id_organizador, esta_activo) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, event.getEventName());
            pst.setString(2, event.getDescription());
            pst.setString(3, event.getEventType());
            pst.setDate(4, Date.valueOf(event.getEventDate() != null ? event.getEventDate() : LocalDate.now()));
            pst.setString(5, event.getLocation());
            pst.setBoolean(6, event.isHasCompetition());
            if (event.getIdOrganizer() != null && event.getIdOrganizer() > 0) {
                pst.setInt(7, event.getIdOrganizer());
            } else {
                pst.setNull(7, Types.INTEGER);
            }
            pst.setBoolean(8, event.isActive());

            pst.executeUpdate();
            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    event.setIdEvent(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error creating school event: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar nuevo evento: " + e.getMessage(), e);
        }
    }

    @Override
    public void update(SchoolEvent event) {
        String sql = "UPDATE eventos SET nombre_evento = ?, descripcion = ?, tipo_evento = ?, " +
                     "fecha_evento = ?, lugar = ?, tiene_competencia = ?, id_organizador = ?, esta_activo = ? " +
                     "WHERE id_evento = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, event.getEventName());
            pst.setString(2, event.getDescription());
            pst.setString(3, event.getEventType());
            pst.setDate(4, Date.valueOf(event.getEventDate()));
            pst.setString(5, event.getLocation());
            pst.setBoolean(6, event.isHasCompetition());
            if (event.getIdOrganizer() != null && event.getIdOrganizer() > 0) {
                pst.setInt(7, event.getIdOrganizer());
            } else {
                pst.setNull(7, Types.INTEGER);
            }
            pst.setBoolean(8, event.isActive());
            pst.setInt(9, event.getIdEvent());

            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error updating school event: " + e.getMessage(), e);
            throw new RuntimeException("Error al actualizar evento.", e);
        }
    }

    @Override
    public void registerParticipant(EventParticipant participant) {
        String sql = "INSERT INTO participantes_evento (id_evento, id_estudiante, rol_participacion, " +
                     "posicion_obtenida, observaciones) VALUES (?, ?, ?, ?, ?)";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setInt(1, participant.getIdEvent());
            pst.setInt(2, participant.getIdStudent());
            pst.setString(3, participant.getParticipationRole() != null ? participant.getParticipationRole() : "Participante");
            pst.setString(4, participant.getRankingPosition());
            pst.setString(5, participant.getRemarks());

            pst.executeUpdate();
            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    participant.setIdParticipation(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error registering event participant: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar participante en el evento: " + e.getMessage(), e);
        }
    }

    @Override
    public void updateParticipantRanking(int idParticipation, String rankingPosition, String remarks) {
        String sql = "UPDATE participantes_evento SET posicion_obtenida = ?, observaciones = ? " +
                     "WHERE id_participacion = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, rankingPosition);
            pst.setString(2, remarks);
            pst.setInt(3, idParticipation);

            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error updating participant ranking: " + e.getMessage(), e);
            throw new RuntimeException("Error al actualizar la posicion o premiacion del participante.", e);
        }
    }

    @Override
    public List<EventParticipant> findParticipantsByEvent(int idEvent) {
        String sql = BASE_SELECT_PARTICIPANT + "WHERE pe.id_evento = ? " +
                     "ORDER BY CASE " +
                     "  WHEN pe.posicion_obtenida = '1er Lugar' THEN 1 " +
                     "  WHEN pe.posicion_obtenida = '2do Lugar' THEN 2 " +
                     "  WHEN pe.posicion_obtenida = '3er Lugar' THEN 3 " +
                     "  WHEN pe.posicion_obtenida IS NOT NULL AND pe.posicion_obtenida <> '' THEN 4 " +
                     "  ELSE 5 END, es.primer_apellido ASC";
        List<EventParticipant> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idEvent);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToParticipant(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error finding participants by event: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar participantes del evento.", e);
        }
        return list;
    }

    @Override
    public List<EventParticipant> findEventsByStudent(int idStudent) {
        String sql = BASE_SELECT_PARTICIPANT + "WHERE pe.id_estudiante = ? ORDER BY e.fecha_evento DESC";
        List<EventParticipant> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idStudent);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToParticipant(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error finding events by student: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar participaciones del estudiante.", e);
        }
        return list;
    }

    @Override
    public EventParticipant findParticipation(int idEvent, int idStudent) {
        String sql = BASE_SELECT_PARTICIPANT + "WHERE pe.id_evento = ? AND pe.id_estudiante = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idEvent);
            pst.setInt(2, idStudent);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToParticipant(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error finding participation: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar participacion del estudiante en el evento.", e);
        }
        return null;
    }

    @Override
    public EventParticipant findParticipationById(int idParticipation) {
        String sql = BASE_SELECT_PARTICIPANT + "WHERE pe.id_participacion = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idParticipation);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToParticipant(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error finding participation by ID: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar participacion por ID.", e);
        }
        return null;
    }

    private SchoolEvent mapResultSetToEvent(ResultSet rs) throws SQLException {
        SchoolEvent e = new SchoolEvent();
        e.setIdEvent(rs.getInt("id_evento"));
        e.setEventName(rs.getString("nombre_evento"));
        e.setDescription(rs.getString("descripcion"));
        e.setEventType(rs.getString("tipo_evento"));
        Date d = rs.getDate("fecha_evento");
        if (d != null) {
            e.setEventDate(d.toLocalDate());
        }
        e.setLocation(rs.getString("lugar"));
        e.setHasCompetition(rs.getBoolean("tiene_competencia"));
        int idOrg = rs.getInt("id_organizador");
        if (!rs.wasNull()) {
            e.setIdOrganizer(idOrg);
        }
        e.setActive(rs.getBoolean("esta_activo"));
        e.setOrganizerName(rs.getString("nombre_organizador"));
        e.setParticipantCount(rs.getInt("total_participantes"));
        return e;
    }

    private EventParticipant mapResultSetToParticipant(ResultSet rs) throws SQLException {
        EventParticipant p = new EventParticipant();
        p.setIdParticipation(rs.getInt("id_participacion"));
        p.setIdEvent(rs.getInt("id_evento"));
        p.setIdStudent(rs.getInt("id_estudiante"));
        p.setParticipationRole(rs.getString("rol_participacion"));
        p.setRankingPosition(rs.getString("posicion_obtenida"));
        p.setRemarks(rs.getString("observaciones"));
        p.setEventName(rs.getString("nombre_evento"));
        p.setStudentName(rs.getString("nombre_estudiante"));
        p.setStudentDocument(rs.getString("numero_documento"));
        return p;
    }
}
