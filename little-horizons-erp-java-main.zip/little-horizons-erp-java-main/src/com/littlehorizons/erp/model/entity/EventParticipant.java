package com.littlehorizons.erp.model.entity;

/**
 * Domain entity representing a student's participation in a school event.
 * Maps to MySQL table 'participantes_evento'.
 */
public class EventParticipant {

    private Integer idParticipation;
    private int idEvent;
    private int idStudent;
    private String participationRole; // 'Participante', 'Competidor', 'Organizador', 'Asistente'
    private String rankingPosition; // '1er Lugar', '2do Lugar', '3er Lugar', 'Participante'
    private String remarks;

    // Descriptive attributes from SQL joins
    private String eventName;
    private String studentName;
    private String studentDocument;

    public EventParticipant() {
        this.participationRole = "Participante";
    }

    public EventParticipant(Integer idParticipation, int idEvent, int idStudent,
                            String participationRole, String rankingPosition, String remarks) {
        this.idParticipation = idParticipation;
        this.idEvent = idEvent;
        this.idStudent = idStudent;
        this.participationRole = participationRole != null ? participationRole : "Participante";
        this.rankingPosition = rankingPosition;
        this.remarks = remarks;
    }

    public Integer getIdParticipation() {
        return idParticipation;
    }

    public void setIdParticipation(Integer idParticipation) {
        this.idParticipation = idParticipation;
    }

    public int getIdEvent() {
        return idEvent;
    }

    public void setIdEvent(int idEvent) {
        this.idEvent = idEvent;
    }

    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    public String getParticipationRole() {
        return participationRole;
    }

    public void setParticipationRole(String participationRole) {
        this.participationRole = participationRole;
    }

    public String getRankingPosition() {
        return rankingPosition;
    }

    public void setRankingPosition(String rankingPosition) {
        this.rankingPosition = rankingPosition;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentDocument() {
        return studentDocument;
    }

    public void setStudentDocument(String studentDocument) {
        this.studentDocument = studentDocument;
    }

    @Override
    public String toString() {
        return "EventParticipant{" +
                "idParticipation=" + idParticipation +
                ", idEvent=" + idEvent +
                ", student='" + studentName + '\'' +
                ", role='" + participationRole + '\'' +
                ", ranking='" + rankingPosition + '\'' +
                '}';
    }
}
