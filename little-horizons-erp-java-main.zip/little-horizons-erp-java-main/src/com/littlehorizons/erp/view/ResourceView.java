package com.littlehorizons.erp.view;

import com.littlehorizons.erp.controller.ResourceController;
import com.littlehorizons.erp.model.entity.*;
import com.littlehorizons.erp.util.ConsoleUI;
import com.littlehorizons.erp.util.ScannerHelper;

import java.time.LocalDate;
import java.util.List;

/**
 * Console view for the Resource and Inventory Management module (Library & Labs).
 * Pure ASCII strings ensure compatibility across all IDEs and console encodings.
 */
public class ResourceView {

    private final ResourceController resourceController;
    private final ScannerHelper sc;

    public ResourceView() {
        this.resourceController = new ResourceController();
        this.sc = ScannerHelper.getInstance();
    }

    /**
     * Displays the resources submenu and handles user choices.
     */
    public void displayMenu() {
        int option = -1;

        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("MODULO DE RECURSOS (BIBLIOTECA Y LABORATORIOS)");

            System.out.println("  1. Consultar Catalogo General de Recursos");
            System.out.println("  2. Consultar Recursos Disponibles para Prestamo");
            System.out.println("  3. Registrar Nuevo Recurso en Inventario");
            System.out.println("  4. Prestar Recurso a Estudiante");
            System.out.println("  5. Prestar Recurso a Profesor");
            System.out.println("  6. Registrar Devolucion de Recurso");
            System.out.println("  7. Reporte de Prestamos Vencidos (Stream API)");
            System.out.println("  0. Regresar al Menu Principal");
            ConsoleUI.printDivider();

            option = sc.readInt("Seleccione una opcion", 0, 7);

            switch (option) {
                case 1 -> listAllResources();
                case 2 -> listAvailableResources();
                case 3 -> registerNewResource();
                case 4 -> loanToStudent();
                case 5 -> loanToTeacher();
                case 6 -> registerReturn();
                case 7 -> showOverdueLoansReport();
                case 0 -> System.out.println("\nRegresando al menu principal...");
            }
        }
    }

    private void listAllResources() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Catalogo General de Recursos");

        try {
            List<Resource> list = resourceController.getAllResources();
            displayResourceTable(list, "el inventario");
        } catch (Exception e) {
            ConsoleUI.printError("Error al consultar inventario: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void listAvailableResources() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Recursos Disponibles para Prestamo");

        try {
            List<Resource> list = resourceController.getAvailableResources();
            displayResourceTable(list, "disponibles");
        } catch (Exception e) {
            ConsoleUI.printError("Error al consultar recursos disponibles: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void displayResourceTable(List<Resource> list, String context) {
        if (list.isEmpty()) {
            System.out.println("[INFO] No se encontraron recursos en " + context + ".");
            return;
        }

        System.out.printf("%-5s | %-12s | %-24s | %-18s | %-14s | %-12s%n",
                "ID", "CODIGO", "NOMBRE", "CATEGORIA", "UBICACION", "ESTADO");
        ConsoleUI.printDivider();
        for (Resource r : list) {
            System.out.printf("%-5d | %-12s | %-24s | %-18s | %-14s | %-12s%n",
                    r.getIdResource(),
                    r.getResourceCode(),
                    truncate(r.getResourceName(), 24),
                    truncate(r.getCategoryName() != null ? r.getCategoryName() : "Cat " + r.getIdCategory(), 18),
                    truncate(r.getPhysicalLocation() != null ? r.getPhysicalLocation() : "N/A", 14),
                    r.getResourceStatus());
        }
        System.out.printf("%nTotal recursos listados: %d%n", list.size());
    }

    private void registerNewResource() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Registrar Nuevo Recurso en Inventario");

        try {
            List<ResourceCategory> categories = resourceController.getAllCategories();
            System.out.println("Categorias disponibles:");
            for (ResourceCategory cat : categories) {
                System.out.printf("  [%d] %s%n", cat.getIdCategory(), cat.getCategoryName());
            }
            ConsoleUI.printDivider();

            String code = sc.readString("Codigo de inventario (ej: LIB-001, MIC-010)");
            String name = sc.readString("Nombre del recurso");
            int catId = sc.readInt("ID de la categoria", 1, 100);
            String location = sc.readString("Ubicacion fisica (ej: Biblioteca Estante 2, Lab Quimica)");
            String description = sc.readOptionalString("Descripcion");

            Resource created = resourceController.registerResource(code, name, catId, description, location);
            ConsoleUI.printSuccess("Recurso registrado exitosamente con ID: " + created.getIdResource());

        } catch (Exception e) {
            ConsoleUI.printError("Error al registrar recurso: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void loanToStudent() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Prestar Recurso a Estudiante");

        try {
            int resourceId = sc.readInt("Ingrese el ID del recurso a prestar");
            int studentId = sc.readInt("Ingrese el ID del estudiante");
            LocalDate expectedDate = sc.readDate("Fecha esperada de devolucion");
            String obs = sc.readOptionalString("Observaciones del prestamo");

            StudentLoan loan = resourceController.loanToStudent(resourceId, studentId, expectedDate, obs);
            ConsoleUI.printSuccess("Prestamo registrado exitosamente!");
            System.out.println("   ID Prestamo: " + loan.getIdLoan());
            System.out.println("   Fecha Prestamo: " + loan.getLoanDate());
            System.out.println("   Fecha Devolucion: " + loan.getExpectedReturnDate());
            System.out.println("   Estado Recurso actualizado a: PRESTADO");

        } catch (Exception e) {
            ConsoleUI.printError("Error al registrar prestamo: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void loanToTeacher() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Prestar Recurso a Profesor");

        try {
            int resourceId = sc.readInt("Ingrese el ID del recurso a prestar");
            int teacherId = sc.readInt("Ingrese el ID del profesor");
            LocalDate expectedDate = sc.readDate("Fecha esperada de devolucion");
            String obs = sc.readOptionalString("Observaciones del prestamo");

            TeacherLoan loan = resourceController.loanToTeacher(resourceId, teacherId, expectedDate, obs);
            ConsoleUI.printSuccess("Prestamo a profesor registrado exitosamente!");
            System.out.println("   ID Prestamo: " + loan.getIdLoan());
            System.out.println("   Fecha Prestamo: " + loan.getLoanDate());
            System.out.println("   Fecha Devolucion: " + loan.getExpectedReturnDate());
            System.out.println("   Estado Recurso actualizado a: PRESTADO");

        } catch (Exception e) {
            ConsoleUI.printError("Error al registrar prestamo: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void registerReturn() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Registrar Devolucion de Recurso");

        System.out.println("Tipo de prestatario:");
        System.out.println("  1. Estudiante");
        System.out.println("  2. Profesor");
        int type = sc.readInt("Seleccione tipo", 1, 2);

        try {
            if (type == 1) {
                List<StudentLoan> active = resourceController.getActiveStudentLoans();
                if (active.isEmpty()) {
                    System.out.println("[INFO] No hay prestamos activos de estudiantes pendientes de devolucion.");
                } else {
                    System.out.println("\nPrestamos activos de estudiantes:");
                    for (StudentLoan sl : active) {
                        System.out.printf("  [ID Prestamo: %d] Recurso: %s | Estudiante: %s | Esperada: %s%n",
                                sl.getIdLoan(), sl.getResourceName(), sl.getBorrowerName(), sl.getExpectedReturnDate());
                    }
                    ConsoleUI.printDivider();
                    int loanId = sc.readInt("Ingrese el ID del prestamo a devolver");
                    resourceController.returnStudentLoan(loanId);
                    ConsoleUI.printSuccess("Devolucion registrada. Recurso restaurado a estado DISPONIBLE.");
                }
            } else {
                List<TeacherLoan> active = resourceController.getActiveTeacherLoans();
                if (active.isEmpty()) {
                    System.out.println("[INFO] No hay prestamos activos de profesores pendientes de devolucion.");
                } else {
                    System.out.println("\nPrestamos activos de profesores:");
                    for (TeacherLoan tl : active) {
                        System.out.printf("  [ID Prestamo: %d] Recurso: %s | Profesor: %s | Esperada: %s%n",
                                tl.getIdLoan(), tl.getResourceName(), tl.getBorrowerName(), tl.getExpectedReturnDate());
                    }
                    ConsoleUI.printDivider();
                    int loanId = sc.readInt("Ingrese el ID del prestamo a devolver");
                    resourceController.returnTeacherLoan(loanId);
                    ConsoleUI.printSuccess("Devolucion registrada. Recurso restaurado a estado DISPONIBLE.");
                }
            }
        } catch (Exception e) {
            ConsoleUI.printError("Error al registrar devolucion: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    public void showOverdueLoansReport() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Reporte de Prestamos Vencidos (Stream API)");

        try {
            List<Loan> overdue = resourceController.getOverdueLoans();

            if (overdue.isEmpty()) {
                ConsoleUI.printSuccess("No hay prestamos vencidos pendientes. Todos los recursos estan al dia!");
            } else {
                System.out.printf("%-6s | %-10s | %-20s | %-18s | %-12s | %-12s%n",
                        "ID", "TIPO", "PRESTATARIO", "RECURSO", "FECHA PREST", "FECHA VENC");
                ConsoleUI.printDivider();

                for (Loan loan : overdue) {
                    System.out.printf("%-6d | %-10s | %-20s | %-18s | %-12s | %-12s%n",
                            loan.getIdLoan(),
                            loan.getBorrowerType(),
                            truncate(loan.getBorrowerName(), 20),
                            truncate(loan.getResourceName() != null ? loan.getResourceName() : "Recurso " + loan.getIdResource(), 18),
                            loan.getLoanDate(),
                            loan.getExpectedReturnDate());
                }

                System.out.printf("%n[ALERTA] Total de prestamos vencidos sin devolver: %d%n", overdue.size());
            }

        } catch (Exception e) {
            ConsoleUI.printError("Error al generar reporte de prestamos vencidos: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        return text.length() <= maxLength ? text : text.substring(0, maxLength - 3) + "...";
    }
}
