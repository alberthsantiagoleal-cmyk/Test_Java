package com.littlehorizons.erp.controller;

import com.littlehorizons.erp.model.dao.IClubDAO;
import com.littlehorizons.erp.model.dao.ISchoolEventDAO;
import com.littlehorizons.erp.model.dao.IStudentDAO;
import com.littlehorizons.erp.model.dao.ITeacherDAO;
import com.littlehorizons.erp.model.dao.impl.ClubDAOImpl;
import com.littlehorizons.erp.model.dao.impl.SchoolEventDAOImpl;
import com.littlehorizons.erp.model.dao.impl.StudentDAOImpl;
import com.littlehorizons.erp.model.dao.impl.TeacherDAOImpl;
import com.littlehorizons.erp.model.entity.Club;
import com.littlehorizons.erp.model.entity.ClubMembership;
import com.littlehorizons.erp.model.entity.EventParticipant;
import com.littlehorizons.erp.model.entity.SchoolEvent;
import com.littlehorizons.erp.model.entity.Student;
import com.littlehorizons.erp.model.entity.Teacher;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller orchestrating business logic and capacity enforcement for Clubs and Events.
 * Follows Single Responsibility Principle (SRP) and Dependency Inversion Principle (DIP).
 */
public class ExtracurricularController {

    private final IClubDAO clubDAO;
    private final ISchoolEventDAO eventDAO;
    private final IStudentDAO studentDAO;
    private final ITeacherDAO teacherDAO;

    public ExtracurricularController() {
        this(new ClubDAOImpl(), new SchoolEventDAOImpl(), new StudentDAOImpl(), new TeacherDAOImpl());
    }

    public ExtracurricularController(IClubDAO clubDAO, ISchoolEventDAO eventDAO,
                                     IStudentDAO studentDAO, ITeacherDAO teacherDAO) {
        this.clubDAO = clubDAO;
        this.eventDAO = eventDAO;
        this.studentDAO = studentDAO;
        this.teacherDAO = teacherDAO;
    }

    // ==========================================
    // CLUB MANAGEMENT
    // ==========================================

    public List<Club> getAllClubs() {
        return clubDAO.findAll();
    }

    public List<Club> getActiveClubs() {
        return clubDAO.findActive();
    }

    public Club getClubById(int idClub) {
        Club club = clubDAO.findById(idClub);
        if (club == null) {
            throw new IllegalArgumentException("Club no encontrado con ID: " + idClub);
        }
        return club;
    }

    public Club registerClub(String name, String description, Integer idTeacherSupervisor,
                             int maxCapacity, String schedule) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("El nombre del club no puede estar vacio.");
        }
        if (maxCapacity <= 0) {
            throw new IllegalArgumentException("La capacidad maxima debe ser mayor a 0.");
        }
        if (clubDAO.findByName(name.trim()) != null) {
            throw new IllegalArgumentException("Ya existe un club registrado con el nombre: " + name.trim());
        }
        if (idTeacherSupervisor != null && idTeacherSupervisor > 0) {
            Teacher teacher = teacherDAO.findById(idTeacherSupervisor);
            if (teacher == null) {
                throw new IllegalArgumentException("El profesor supervisor especificado no existe.");
            }
        }

        Club club = new Club(null, name.trim(), description, idTeacherSupervisor, maxCapacity, schedule, true);
        clubDAO.create(club);
        return club;
    }

    /**
     * Enrolls a student into a club with strict capacity validation.
     * Enforces the business rule: active members count must not exceed maxCapacity.
     */
    public ClubMembership enrollStudentInClub(int idStudent, int idClub) {
        Student student = studentDAO.findById(idStudent);
        if (student == null) {
            throw new IllegalArgumentException("Estudiante no encontrado con ID: " + idStudent);
        }

        Club club = clubDAO.findById(idClub);
        if (club == null) {
            throw new IllegalArgumentException("Club no encontrado con ID: " + idClub);
        }
        if (!club.isActive()) {
            throw new IllegalStateException("El club '" + club.getClubName() + "' se encuentra inactivo.");
        }

        // Capacity validation rule
        int currentMembers = clubDAO.countActiveMembers(idClub);
        if (currentMembers >= club.getMaxCapacity()) {
            throw new IllegalStateException("El club '" + club.getClubName() + "' ha alcanzado su capacidad maxima (" +
                    club.getMaxCapacity() + " cupos). No es posible inscribir mas estudiantes.");
        }

        // Check if student is already actively enrolled
        if (clubDAO.isStudentActiveMember(idStudent, idClub)) {
            throw new IllegalStateException("El estudiante ya se encuentra inscrito como miembro activo en el club '" +
                    club.getClubName() + "'.");
        }

        ClubMembership membership = new ClubMembership(null, idStudent, idClub, LocalDate.now(),
                "Activa", null, null);
        clubDAO.registerMembership(membership);
        return membership;
    }

    /**
     * Withdraws a student from a club, freeing up a slot.
     */
    public void withdrawStudentFromClub(int idMembership, String reason) {
        ClubMembership membership = clubDAO.findMembershipById(idMembership);
        if (membership == null) {
            throw new IllegalArgumentException("Membresia no encontrada con ID: " + idMembership);
        }
        if (!membership.isActive()) {
            throw new IllegalStateException("La membresia ya se encuentra en estado: " + membership.getMembershipStatus());
        }

        clubDAO.withdrawMembership(idMembership, LocalDate.now(), reason);
    }

    public List<ClubMembership> getMembershipsByClub(int idClub) {
        return clubDAO.findMembershipsByClub(idClub);
    }

    public List<ClubMembership> getMembershipsByStudent(int idStudent) {
        return clubDAO.findMembershipsByStudent(idStudent);
    }

    // ==========================================
    // SCHOOL EVENT MANAGEMENT
    // ==========================================

    public List<SchoolEvent> getAllEvents() {
        return eventDAO.findAll();
    }

    public List<SchoolEvent> getUpcomingEvents() {
        return eventDAO.findUpcoming();
    }

    public SchoolEvent getEventById(int idEvent) {
        SchoolEvent event = eventDAO.findById(idEvent);
        if (event == null) {
            throw new IllegalArgumentException("Evento no encontrado con ID: " + idEvent);
        }
        return event;
    }

    public SchoolEvent registerEvent(String name, String description, String type,
                                     LocalDate date, String location, boolean hasCompetition,
                                     Integer idOrganizer) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("El nombre del evento no puede estar vacio.");
        }
        if (type == null || type.isBlank()) {
            throw new IllegalArgumentException("Debe seleccionar un tipo de evento valido.");
        }
        if (date == null) {
            throw new IllegalArgumentException("Debe especificar una fecha valida para el evento.");
        }
        if (idOrganizer != null && idOrganizer > 0) {
            Teacher teacher = teacherDAO.findById(idOrganizer);
            if (teacher == null) {
                throw new IllegalArgumentException("El profesor organizador especificado no existe.");
            }
        }

        SchoolEvent event = new SchoolEvent(null, name.trim(), description, type, date, location,
                hasCompetition, idOrganizer, true);
        eventDAO.create(event);
        return event;
    }

    /**
     * Registers a student participant in a school event.
     */
    public EventParticipant registerStudentInEvent(int idEvent, int idStudent, String role) {
        SchoolEvent event = eventDAO.findById(idEvent);
        if (event == null) {
            throw new IllegalArgumentException("Evento no encontrado con ID: " + idEvent);
        }
        if (!event.isActive()) {
            throw new IllegalStateException("El evento '" + event.getEventName() + "' se encuentra inactivo.");
        }

        Student student = studentDAO.findById(idStudent);
        if (student == null) {
            throw new IllegalArgumentException("Estudiante no encontrado con ID: " + idStudent);
        }

        EventParticipant existing = eventDAO.findParticipation(idEvent, idStudent);
        if (existing != null) {
            throw new IllegalStateException("El estudiante ya se encuentra registrado en el evento '" +
                    event.getEventName() + "'.");
        }

        EventParticipant participant = new EventParticipant(null, idEvent, idStudent,
                role != null ? role : "Participante", null, null);
        eventDAO.registerParticipant(participant);
        return participant;
    }

    /**
     * Assigns competition position and remarks to an event participant.
     */
    public void assignCompetitionRanking(int idParticipation, String rankingPosition, String remarks) {
        EventParticipant participant = eventDAO.findParticipationById(idParticipation);
        if (participant == null) {
            throw new IllegalArgumentException("Registro de participacion no encontrado con ID: " + idParticipation);
        }

        SchoolEvent event = eventDAO.findById(participant.getIdEvent());
        if (event == null || !event.isHasCompetition()) {
            throw new IllegalStateException("El evento asociado no esta configurado como evento de competencia.");
        }

        if (rankingPosition == null || rankingPosition.isBlank()) {
            throw new IllegalArgumentException("Debe ingresar una posicion o distincion valida.");
        }

        eventDAO.updateParticipantRanking(idParticipation, rankingPosition.trim(), remarks);
    }

    public List<EventParticipant> getParticipantsByEvent(int idEvent) {
        return eventDAO.findParticipantsByEvent(idEvent);
    }

    public List<EventParticipant> getEventsByStudent(int idStudent) {
        return eventDAO.findEventsByStudent(idStudent);
    }

    // ==========================================
    // STREAM API ADVANCED QUERIES
    // ==========================================

    /**
     * Retrieves clubs that have reached or exceeded a specific occupancy percentage.
     */
    public List<Club> getClubsNearCapacity(double thresholdRatio) {
        return clubDAO.findActive().stream()
                .filter(c -> c.getMaxCapacity() > 0)
                .filter(c -> ((double) c.getActiveMembersCount() / c.getMaxCapacity()) >= thresholdRatio)
                .sorted(Comparator.comparingInt(Club::getAvailableSlots))
                .collect(Collectors.toList());
    }

    /**
     * Retrieves top winners (1er Lugar, 2do Lugar, 3er Lugar) for an event using Stream API.
     */
    public List<EventParticipant> getEventPodium(int idEvent) {
        return eventDAO.findParticipantsByEvent(idEvent).stream()
                .filter(p -> p.getRankingPosition() != null && !p.getRankingPosition().isBlank())
                .filter(p -> p.getRankingPosition().equalsIgnoreCase("1er Lugar") ||
                             p.getRankingPosition().equalsIgnoreCase("2do Lugar") ||
                             p.getRankingPosition().equalsIgnoreCase("3er Lugar"))
                .sorted(Comparator.comparing(EventParticipant::getRankingPosition))
                .collect(Collectors.toList());
    }
}
