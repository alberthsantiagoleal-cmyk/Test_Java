package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IGradeDAO;
import com.littlehorizons.erp.model.entity.Grade;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GradeDAOImpl implements IGradeDAO {
    @Override
    public List<Grade> findAll() {
        List<Grade> grades = new ArrayList<>();
        String sql = "SELECT id_grado, nombre_grado, nivel_numerico FROM grados ORDER BY nivel_numerico";
        try (PreparedStatement statement = DatabaseConnection.getInstance().prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                Grade grade = new Grade();
                grade.setIdGrade(rs.getInt("id_grado"));
                grade.setName(rs.getString("nombre_grado"));
                grade.setNumericLevel(rs.getInt("nivel_numerico"));
                grades.add(grade);
            }
            return grades;
        } catch (SQLException e) {
            LoggerHelper.logError("Error al consultar grados académicos.", e);
            throw new RuntimeException("Error al consultar grados académicos.", e);
        }
    }

    @Override
    public boolean existsById(int id) {
        String sql = "SELECT 1 FROM grados WHERE id_grado=?";
        try (PreparedStatement statement = DatabaseConnection.getInstance().prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            LoggerHelper.logError("Error al validar grado académico.", e);
            throw new RuntimeException("Error al validar grado académico.", e);
        }
    }
}
