package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IGuardianDAO;
import com.littlehorizons.erp.model.entity.Guardian;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class GuardianDAOImpl implements IGuardianDAO {
    private static final String COLUMNS = "id_acudiente, tipo_documento, numero_documento, primer_nombre, segundo_nombre, "
            + "primer_apellido, segundo_apellido, parentesco, telefono_principal, telefono_secundario, correo_electronico, "
            + "direccion, ocupacion, es_responsable_financiero";

    @Override
    public void create(Guardian guardian) {
        String sql = "INSERT INTO acudientes (tipo_documento, numero_documento, primer_nombre, segundo_nombre, primer_apellido, "
                + "segundo_apellido, parentesco, telefono_principal, telefono_secundario, correo_electronico, direccion, ocupacion, "
                + "es_responsable_financiero) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, guardian, 1);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) guardian.setIdGuardian(keys.getInt(1));
            }
        } catch (SQLException e) {
            throw failure("Error al registrar acudiente.", e);
        }
    }

    @Override
    public Guardian findById(int id) {
        List<Guardian> results = list("SELECT " + COLUMNS + " FROM acudientes WHERE id_acudiente=?", id);
        return results.isEmpty() ? null : results.get(0);
    }

    @Override
    public List<Guardian> findAll() {
        return list("SELECT " + COLUMNS + " FROM acudientes ORDER BY id_acudiente ASC", null);
    }

    @Override
    public List<Guardian> findByStudentId(int studentId) {
        String sql = "SELECT a." + COLUMNS.replace(", ", ", a.")
                + " FROM acudientes a JOIN estudiante_acudiente ea ON ea.id_acudiente=a.id_acudiente "
                + "WHERE ea.id_estudiante=? ORDER BY ea.es_principal DESC, a.primer_apellido, a.primer_nombre";
        return list(sql, studentId);
    }

    @Override
    public void update(Guardian guardian) {
        String sql = "UPDATE acudientes SET tipo_documento=?, numero_documento=?, primer_nombre=?, segundo_nombre=?, "
                + "primer_apellido=?, segundo_apellido=?, parentesco=?, telefono_principal=?, telefono_secundario=?, "
                + "correo_electronico=?, direccion=?, ocupacion=?, es_responsable_financiero=? WHERE id_acudiente=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            bind(statement, guardian, 1);
            statement.setInt(14, guardian.getIdGuardian());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw failure("Error al actualizar acudiente.", e);
        }
    }

    @Override
    public boolean existsByDocument(String documentNumber) {
        String sql = "SELECT 1 FROM acudientes WHERE numero_documento=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setString(1, documentNumber);
            try (ResultSet rs = statement.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            throw failure("Error al validar documento de acudiente.", e);
        }
    }

    private List<Guardian> list(String sql, Integer id) {
        List<Guardian> guardians = new ArrayList<>();
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            if (id != null) statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) guardians.add(map(rs));
            }
            return guardians;
        } catch (SQLException e) {
            throw failure("Error al consultar acudientes.", e);
        }
    }

    private void bind(PreparedStatement statement, Guardian guardian, int index) throws SQLException {
        statement.setString(index++, guardian.getDocumentType());
        statement.setString(index++, guardian.getDocumentNumber());
        statement.setString(index++, guardian.getFirstName());
        statement.setString(index++, guardian.getMiddleName());
        statement.setString(index++, guardian.getFirstSurname());
        statement.setString(index++, guardian.getSecondSurname());
        statement.setString(index++, guardian.getRelationship());
        statement.setString(index++, guardian.getPrimaryPhone());
        statement.setString(index++, guardian.getSecondaryPhone());
        statement.setString(index++, guardian.getEmail());
        statement.setString(index++, guardian.getAddress());
        statement.setString(index++, guardian.getOccupation());
        statement.setBoolean(index, guardian.isFinancialResponsible());
    }

    private Guardian map(ResultSet rs) throws SQLException {
        Guardian guardian = new Guardian();
        guardian.setIdGuardian(rs.getInt("id_acudiente"));
        guardian.setDocumentType(rs.getString("tipo_documento"));
        guardian.setDocumentNumber(rs.getString("numero_documento"));
        guardian.setFirstName(rs.getString("primer_nombre"));
        guardian.setMiddleName(rs.getString("segundo_nombre"));
        guardian.setFirstSurname(rs.getString("primer_apellido"));
        guardian.setSecondSurname(rs.getString("segundo_apellido"));
        guardian.setRelationship(rs.getString("parentesco"));
        guardian.setPrimaryPhone(rs.getString("telefono_principal"));
        guardian.setSecondaryPhone(rs.getString("telefono_secundario"));
        guardian.setEmail(rs.getString("correo_electronico"));
        guardian.setAddress(rs.getString("direccion"));
        guardian.setOccupation(rs.getString("ocupacion"));
        guardian.setFinancialResponsible(rs.getBoolean("es_responsable_financiero"));
        return guardian;
    }

    private Connection connection() { return DatabaseConnection.getInstance(); }
    private RuntimeException failure(String message, SQLException cause) {
        LoggerHelper.logError(message, cause);
        return new RuntimeException(message, cause);
    }
}
