package com.littlehorizons.erp.view;

import com.littlehorizons.erp.controller.ExtracurricularController;
import com.littlehorizons.erp.model.entity.Club;
import com.littlehorizons.erp.model.entity.ClubMembership;
import com.littlehorizons.erp.model.entity.EventParticipant;
import com.littlehorizons.erp.model.entity.SchoolEvent;
import com.littlehorizons.erp.util.ConsoleUI;
import com.littlehorizons.erp.util.ScannerHelper;

import java.time.LocalDate;
import java.util.List;

/**
 * Console view for the Extracurricular Activities module (Clubs & Events).
 * Pure ASCII strings ensure 100% compatibility across all IDEs and console encodings.
 */
public class ExtracurricularView {

    private final ExtracurricularController controller;
    private final ScannerHelper sc;

    public ExtracurricularView() {
        this.controller = new ExtracurricularController();
        this.sc = ScannerHelper.getInstance();
    }

    /**
     * Displays the extracurricular submenu and handles user navigation.
     */
    public void displayMenu() {
        int option = -1;

        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("MODULO DE ACTIVIDADES EXTRACURRICULARES (CLUBES Y EVENTOS)");

            System.out.println("  1. Consultar Catalogo de Clubes");
            System.out.println("  2. Registrar Nuevo Club Extracurricular");
            System.out.println("  3. Inscribir Estudiante en un Club (Validacion de Cupos)");
            System.out.println("  4. Retirar Estudiante de un Club");
            System.out.println("  5. Consultar Miembros de un Club");
            System.out.println("  6. Consultar Calendario de Eventos Escolares");
            System.out.println("  7. Registrar Nuevo Evento Escolar");
            System.out.println("  8. Inscribir Estudiante a un Evento");
            System.out.println("  9. Registrar Premiacion / Posicion en Competencia");
            System.out.println(" 10. Consultar Participantes y Podio de un Evento");
            System.out.println(" 11. Clubes con Alta Ocupacion (>= 80% Cupo - Stream API)");
            System.out.println("  0. Regresar al Menu Principal");
            ConsoleUI.printDivider();

            option = sc.readInt("Seleccione una opcion", 0, 11);

            switch (option) {
                case 1 -> listClubs();
                case 2 -> registerNewClub();
                case 3 -> enrollStudentInClub();
                case 4 -> withdrawStudentFromClub();
                case 5 -> listClubMembers();
                case 6 -> listEvents();
                case 7 -> registerNewEvent();
                case 8 -> enrollStudentInEvent();
                case 9 -> registerCompetitionRanking();
                case 10 -> showEventPodiumAndParticipants();
                case 11 -> showClubsNearCapacityReport();
                case 0 -> System.out.println("\nRegresando al menu principal...");
            }
        }
    }

    // ==========================================
    // CLUB VIEW ACTIONS
    // ==========================================

    private void listClubs() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("CATALOGO DE CLUBES EXTRACURRICULARES");

        try {
            List<Club> clubs = controller.getAllClubs();
            if (clubs.isEmpty()) {
                System.out.println("\n[INFO] No hay clubes registrados en el sistema.");
            } else {
                System.out.println(String.format("\n%-5s %-25s %-12s %-10s %-20s %-22s",
                        "ID", "Nombre Club", "Cupo Ocup.", "Disp.", "Horario", "Supervisor"));
                System.out.println("-".repeat(100));

                for (Club c : clubs) {
                    String teacher = c.getTeacherSupervisorName() != null ? c.getTeacherSupervisorName() : "Por asignar";
                    String capacityStr = c.getActiveMembersCount() + " / " + c.getMaxCapacity();
                    String status = c.isActive() ? "" : " (Inactivo)";
                    System.out.println(String.format("%-5d %-25s %-12s %-10d %-20s %-22s%s",
                            c.getIdClub(),
                            truncate(c.getClubName(), 24),
                            capacityStr,
                            c.getAvailableSlots(),
                            truncate(c.getMeetingSchedule() != null ? c.getMeetingSchedule() : "N/A", 19),
                            truncate(teacher, 21),
                            status));
                }
            }
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void registerNewClub() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("REGISTRO DE NUEVO CLUB");

        try {
            String name = sc.readString("Nombre del club");
            String description = sc.readString("Descripcion del club");
            int maxCapacity = sc.readInt("Capacidad maxima de estudiantes (ej: 25)", 1, 100);
            String schedule = sc.readString("Horario de reunion (ej: Martes y Jueves 3-5 PM)");
            int idTeacher = sc.readInt("ID Profesor supervisor (0 si no aplica)", 0, 99999);

            Integer supervisor = idTeacher > 0 ? idTeacher : null;

            Club registered = controller.registerClub(name, description, supervisor, maxCapacity, schedule);
            System.out.println("\n[OK] Club registrado exitosamente con ID: " + registered.getIdClub());
            System.out.println("  Nombre: " + registered.getClubName());
            System.out.println("  Cupo maximo: " + registered.getMaxCapacity() + " estudiantes");
            System.out.println("  Horario: " + registered.getMeetingSchedule());

        } catch (Exception e) {
            System.out.println("\n[ERROR] No se pudo registrar el club: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void enrollStudentInClub() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("INSCRIPCION DE ESTUDIANTE EN CLUB");

        try {
            int idClub = sc.readInt("Ingrese el ID del club", 1, 99999);
            Club club = controller.getClubById(idClub);

            System.out.println("\nClub seleccionado: " + club.getClubName());
            System.out.println("Cupo actual: " + club.getActiveMembersCount() + " / " + club.getMaxCapacity() +
                    " (Disponibles: " + club.getAvailableSlots() + ")");

            if (club.isFull()) {
                System.out.println("\n[!] ALERTA: Este club ha alcanzado su capacidad maxima (" +
                        club.getMaxCapacity() + " cupos).");
                System.out.println("No es posible realizar nuevas inscripciones.");
                sc.pressEnterToContinue();
                return;
            }

            int idStudent = sc.readInt("Ingrese el ID del estudiante a inscribir", 1, 99999);

            ClubMembership membership = controller.enrollStudentInClub(idStudent, idClub);
            System.out.println("\n[OK] Inscripcion completada exitosamente!");
            System.out.println("  ID Membresia: " + membership.getIdMembership());
            System.out.println("  Fecha de ingreso: " + membership.getEnrollmentDate());
            System.out.println("  Estado: " + membership.getMembershipStatus());

        } catch (IllegalStateException e) {
            System.out.println("\n[REGLA DE NEGOCIO] " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void withdrawStudentFromClub() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("RETIRO DE ESTUDIANTE DE UN CLUB");

        try {
            int idMembership = sc.readInt("Ingrese el ID de la membresia a retirar", 1, 99999);
            String reason = sc.readString("Motivo del retiro");

            controller.withdrawStudentFromClub(idMembership, reason);
            System.out.println("\n[OK] Membresia retirada exitosamente. El cupo en el club ha sido liberado.");

        } catch (Exception e) {
            System.out.println("\n[ERROR] No se pudo procesar el retiro: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void listClubMembers() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("MIEMBROS DE UN CLUB");

        try {
            int idClub = sc.readInt("Ingrese el ID del club", 1, 99999);
            Club club = controller.getClubById(idClub);
            List<ClubMembership> members = controller.getMembershipsByClub(idClub);

            System.out.println("\nClub: " + club.getClubName() + " | Cupo: " +
                    club.getActiveMembersCount() + " / " + club.getMaxCapacity());
            System.out.println("-".repeat(85));

            if (members.isEmpty()) {
                System.out.println("[INFO] No hay estudiantes inscritos en este club.");
            } else {
                System.out.println(String.format("%-6s %-12s %-28s %-12s %-10s %-12s",
                        "ID Mem", "Doc.", "Estudiante", "F. Ingreso", "Estado", "F. Retiro"));
                System.out.println("-".repeat(85));

                for (ClubMembership m : members) {
                    String withDate = m.getWithdrawalDate() != null ? m.getWithdrawalDate().toString() : "-";
                    System.out.println(String.format("%-6d %-12s %-28s %-12s %-10s %-12s",
                            m.getIdMembership(),
                            m.getStudentDocument() != null ? m.getStudentDocument() : "N/A",
                            truncate(m.getStudentName(), 27),
                            m.getEnrollmentDate(),
                            m.getMembershipStatus(),
                            withDate));
                }
            }
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    // ==========================================
    // EVENT VIEW ACTIONS
    // ==========================================

    private void listEvents() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("CALENDARIO DE EVENTOS ESCOLARES");

        try {
            List<SchoolEvent> events = controller.getAllEvents();
            if (events.isEmpty()) {
                System.out.println("\n[INFO] No hay eventos registrados en el calendario.");
            } else {
                System.out.println(String.format("\n%-5s %-26s %-12s %-12s %-18s %-6s %-8s",
                        "ID", "Nombre Evento", "Tipo", "Fecha", "Lugar", "Comp.", "Partic."));
                System.out.println("-".repeat(95));

                for (SchoolEvent ev : events) {
                    String comp = ev.isHasCompetition() ? "Si" : "No";
                    System.out.println(String.format("%-5d %-26s %-12s %-12s %-18s %-6s %-8d",
                            ev.getIdEvent(),
                            truncate(ev.getEventName(), 25),
                            ev.getEventType(),
                            ev.getEventDate(),
                            truncate(ev.getLocation() != null ? ev.getLocation() : "Colegio", 17),
                            comp,
                            ev.getParticipantCount()));
                }
            }
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void registerNewEvent() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("REGISTRO DE NUEVO EVENTO ESCOLAR");

        try {
            String name = sc.readString("Nombre del evento");
            String description = sc.readString("Descripcion del evento");

            System.out.println("\nSeleccione el tipo de evento:");
            System.out.println("  1. Academico");
            System.out.println("  2. Cultural");
            System.out.println("  3. Deportivo");
            System.out.println("  4. Social");
            System.out.println("  5. Cientifico");
            int typeOpt = sc.readInt("Tipo", 1, 5);
            String typeStr = switch (typeOpt) {
                case 1 -> "Acad\u00e9mico";
                case 2 -> "Cultural";
                case 3 -> "Deportivo";
                case 4 -> "Social";
                case 5 -> "Cient\u00edfico";
                default -> "Cultural";
            };

            String dateStr = sc.readString("Fecha del evento (AAAA-MM-DD)");
            LocalDate date = LocalDate.parse(dateStr.trim());

            String location = sc.readString("Lugar o sede del evento (ej: Auditorio Principal)");
            String hasCompStr = sc.readString("Tiene competencia con premiacion/posiciones? (S/N)");
            boolean hasComp = hasCompStr.trim().equalsIgnoreCase("S");

            int idTeacher = sc.readInt("ID Profesor organizador (0 si no aplica)", 0, 99999);
            Integer organizer = idTeacher > 0 ? idTeacher : null;

            SchoolEvent created = controller.registerEvent(name, description, typeStr, date, location, hasComp, organizer);
            System.out.println("\n[OK] Evento registrado exitosamente con ID: " + created.getIdEvent());
            System.out.println("  Nombre: " + created.getEventName());
            System.out.println("  Fecha: " + created.getEventDate());
            System.out.println("  Competencia: " + (created.isHasCompetition() ? "Si" : "No"));

        } catch (Exception e) {
            System.out.println("\n[ERROR] No se pudo registrar el evento: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void enrollStudentInEvent() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("INSCRIPCION DE ESTUDIANTE A EVENTO");

        try {
            int idEvent = sc.readInt("Ingrese el ID del evento", 1, 99999);
            SchoolEvent event = controller.getEventById(idEvent);

            System.out.println("\nEvento: " + event.getEventName() + " (" + event.getEventType() + " - " + event.getEventDate() + ")");

            int idStudent = sc.readInt("Ingrese el ID del estudiante a inscribir", 1, 99999);

            System.out.println("\nSeleccione el rol de participacion:");
            System.out.println("  1. Participante");
            System.out.println("  2. Competidor");
            System.out.println("  3. Organizador");
            System.out.println("  4. Asistente");
            int roleOpt = sc.readInt("Rol", 1, 4);
            String roleStr = switch (roleOpt) {
                case 1 -> "Participante";
                case 2 -> "Competidor";
                case 3 -> "Organizador";
                case 4 -> "Asistente";
                default -> "Participante";
            };

            EventParticipant ep = controller.registerStudentInEvent(idEvent, idStudent, roleStr);
            System.out.println("\n[OK] Estudiante registrado en el evento exitosamente!");
            System.out.println("  ID Participacion: " + ep.getIdParticipation());
            System.out.println("  Rol: " + ep.getParticipationRole());

        } catch (IllegalStateException e) {
            System.out.println("\n[REGLA DE NEGOCIO] " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void registerCompetitionRanking() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("REGISTRO DE POSICION / PREMIACION");

        try {
            int idParticipation = sc.readInt("Ingrese el ID de la participacion", 1, 99999);

            System.out.println("\nSeleccione la posicion o distincion obtenida:");
            System.out.println("  1. 1er Lugar (Campeon / Oro)");
            System.out.println("  2. 2do Lugar (Subcampeon / Plata)");
            System.out.println("  3. 3er Lugar (Bronce)");
            System.out.println("  4. Mencion de Honor");
            System.out.println("  5. Participante Destacado");
            System.out.println("  6. Otra posicion personalizada");

            int posOpt = sc.readInt("Opcion", 1, 6);
            String rankingStr = switch (posOpt) {
                case 1 -> "1er Lugar";
                case 2 -> "2do Lugar";
                case 3 -> "3er Lugar";
                case 4 -> "Mencion de Honor";
                case 5 -> "Participante";
                case 6 -> sc.readString("Escriba la posicion obtenida");
                default -> "Participante";
            };

            String observations = sc.readString("Observaciones o detalles del premio/reconocimiento");

            controller.assignCompetitionRanking(idParticipation, rankingStr, observations);
            System.out.println("\n[OK] Posicion y premiacion registradas exitosamente!");
            System.out.println("  Posicion: " + rankingStr);
            System.out.println("  Detalle: " + observations);

        } catch (IllegalStateException e) {
            System.out.println("\n[REGLA DE NEGOCIO] " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void showEventPodiumAndParticipants() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("CONSULTA DE PARTICIPANTES Y PODIO DEL EVENTO");

        try {
            int idEvent = sc.readInt("Ingrese el ID del evento", 1, 99999);
            SchoolEvent event = controller.getEventById(idEvent);
            List<EventParticipant> participants = controller.getParticipantsByEvent(idEvent);

            System.out.println("\nEvento: " + event.getEventName() + " | Fecha: " + event.getEventDate());
            System.out.println("Tipo: " + event.getEventType() + " | Competencia: " + (event.isHasCompetition() ? "Si" : "No"));
            System.out.println("-".repeat(90));

            if (event.isHasCompetition()) {
                List<EventParticipant> podium = controller.getEventPodium(idEvent);
                if (!podium.isEmpty()) {
                    System.out.println("\n--- PODIO DE GANADORES ---");
                    for (EventParticipant p : podium) {
                        System.out.println("  [*] " + p.getRankingPosition() + ": " + p.getStudentName() +
                                (p.getRemarks() != null ? " (" + p.getRemarks() + ")" : ""));
                    }
                    System.out.println("-".repeat(90));
                }
            }

            if (participants.isEmpty()) {
                System.out.println("[INFO] No hay participantes registrados para este evento.");
            } else {
                System.out.println(String.format("%-6s %-12s %-26s %-14s %-15s %-20s",
                        "ID", "Doc.", "Estudiante", "Rol", "Posicion", "Observaciones"));
                System.out.println("-".repeat(90));

                for (EventParticipant p : participants) {
                    System.out.println(String.format("%-6d %-12s %-26s %-14s %-15s %-20s",
                            p.getIdParticipation(),
                            p.getStudentDocument() != null ? p.getStudentDocument() : "N/A",
                            truncate(p.getStudentName(), 25),
                            p.getParticipationRole(),
                            p.getRankingPosition() != null ? p.getRankingPosition() : "-",
                            truncate(p.getRemarks() != null ? p.getRemarks() : "-", 19)));
                }
            }

        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    public void showClubsNearCapacityReport() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("REPORTE: CLUBES CON ALTA OCUPACION (>= 80% CUPOS)");

        try {
            List<Club> saturated = controller.getClubsNearCapacity(0.80);
            if (saturated.isEmpty()) {
                System.out.println("\n[INFO] Actualmente ningun club supera el 80% de su capacidad.");
            } else {
                System.out.println(String.format("\n%-5s %-25s %-12s %-12s %-12s",
                        "ID", "Nombre Club", "Ocupados", "Capacidad", "Disp."));
                System.out.println("-".repeat(70));

                for (Club c : saturated) {
                    System.out.println(String.format("%-5d %-25s %-12d %-12d %-12d",
                            c.getIdClub(),
                            truncate(c.getClubName(), 24),
                            c.getActiveMembersCount(),
                            c.getMaxCapacity(),
                            c.getAvailableSlots()));
                }
            }
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        return text.length() <= maxLength ? text : text.substring(0, maxLength - 3) + "...";
    }
}
