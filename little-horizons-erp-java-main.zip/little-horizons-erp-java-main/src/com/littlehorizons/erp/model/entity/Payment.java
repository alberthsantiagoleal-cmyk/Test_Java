package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Domain entity representing an individual payment made for an educational concept.
 * Maps to the MySQL table 'pagos'.
 */
public class Payment {

    private Integer idPayment;
    private int idStudent;
    private Integer idGuardian; // Can be null if paid directly or unassigned
    private int idConcept;
    private double amountPaid;
    private LocalDate paymentDate;
    private String paymentMethod; // 'Efectivo', 'Transferencia', 'Tarjeta Débito', 'Tarjeta Crédito', 'Cheque'
    private String receiptNumber;
    private Integer academicYear;
    private String academicPeriod; // 'I', 'II', 'III', 'IV', 'Anual'
    private String notes;

    // Optional descriptive fields for UI display (from SQL JOINs)
    private String studentName;
    private String conceptName;

    public Payment() {
    }

    public Payment(Integer idPayment, int idStudent, Integer idGuardian, int idConcept, double amountPaid,
                   LocalDate paymentDate, String paymentMethod, String receiptNumber,
                   Integer academicYear, String academicPeriod, String notes) {
        this.idPayment = idPayment;
        this.idStudent = idStudent;
        this.idGuardian = idGuardian;
        this.idConcept = idConcept;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.receiptNumber = receiptNumber;
        this.academicYear = academicYear;
        this.academicPeriod = academicPeriod;
        this.notes = notes;
    }

    public Integer getIdPayment() {
        return idPayment;
    }

    public void setIdPayment(Integer idPayment) {
        this.idPayment = idPayment;
    }

    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    public Integer getIdGuardian() {
        return idGuardian;
    }

    public void setIdGuardian(Integer idGuardian) {
        this.idGuardian = idGuardian;
    }

    public int getIdConcept() {
        return idConcept;
    }

    public void setIdConcept(int idConcept) {
        this.idConcept = idConcept;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getReceiptNumber() {
        return receiptNumber;
    }

    public void setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber;
    }

    public Integer getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(Integer academicYear) {
        this.academicYear = academicYear;
    }

    public String getAcademicPeriod() {
        return academicPeriod;
    }

    public void setAcademicPeriod(String academicPeriod) {
        this.academicPeriod = academicPeriod;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getConceptName() {
        return conceptName;
    }

    public void setConceptName(String conceptName) {
        this.conceptName = conceptName;
    }

    @Override
    public String toString() {
        return String.format("Recibo: %-12s | Fecha: %s | Monto: $%,10.2f | Metodo: %-15s",
                receiptNumber, paymentDate, amountPaid, paymentMethod);
    }
}
