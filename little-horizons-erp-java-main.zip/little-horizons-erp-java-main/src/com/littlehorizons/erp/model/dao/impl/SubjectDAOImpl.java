package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.ISubjectDAO;
import com.littlehorizons.erp.model.entity.Subject;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAOImpl implements ISubjectDAO {
    private static final String COLUMNS = "id_materia, codigo_materia, nombre_materia, descripcion, id_grado, horas_semanales, esta_activa";

    @Override
    public void create(Subject subject) {
        String sql = "INSERT INTO materias (codigo_materia, nombre_materia, descripcion, id_grado, horas_semanales, esta_activa) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(statement, subject, 1);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) subject.setIdSubject(keys.getInt(1));
            }
        } catch (SQLException e) {
            throw failure("Error al registrar materia.", e);
        }
    }

    @Override
    public Subject findById(int id) {
        String sql = "SELECT " + COLUMNS + " FROM materias WHERE id_materia=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet rs = statement.executeQuery()) { return rs.next() ? map(rs) : null; }
        } catch (SQLException e) {
            throw failure("Error al consultar materia.", e);
        }
    }

    @Override
    public List<Subject> findAll() {
        return list("SELECT " + COLUMNS + " FROM materias ORDER BY id_materia ASC", null);
    }

    @Override
    public List<Subject> findByGradeId(int gradeId) {
        return list("SELECT " + COLUMNS + " FROM materias WHERE id_grado=? ORDER BY nombre_materia", gradeId);
    }

    @Override
    public void update(Subject subject) {
        String sql = "UPDATE materias SET codigo_materia=?, nombre_materia=?, descripcion=?, id_grado=?, "
                + "horas_semanales=?, esta_activa=? WHERE id_materia=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            bind(statement, subject, 1);
            statement.setInt(7, subject.getIdSubject());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw failure("Error al actualizar materia.", e);
        }
    }

    private List<Subject> list(String sql, Integer gradeId) {
        List<Subject> subjects = new ArrayList<>();
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            if (gradeId != null) statement.setInt(1, gradeId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) subjects.add(map(rs));
            }
            return subjects;
        } catch (SQLException e) {
            throw failure("Error al listar materias.", e);
        }
    }

    private void bind(PreparedStatement statement, Subject subject, int index) throws SQLException {
        statement.setString(index++, subject.getCode());
        statement.setString(index++, subject.getName());
        statement.setString(index++, subject.getDescription());
        statement.setInt(index++, subject.getGradeId());
        if (subject.getWeeklyHours() == null) statement.setNull(index++, java.sql.Types.INTEGER);
        else statement.setInt(index++, subject.getWeeklyHours());
        statement.setBoolean(index, subject.isActive());
    }

    private Subject map(ResultSet rs) throws SQLException {
        Subject subject = new Subject();
        subject.setIdSubject(rs.getInt("id_materia"));
        subject.setCode(rs.getString("codigo_materia"));
        subject.setName(rs.getString("nombre_materia"));
        subject.setDescription(rs.getString("descripcion"));
        subject.setGradeId(rs.getInt("id_grado"));
        int hours = rs.getInt("horas_semanales");
        subject.setWeeklyHours(rs.wasNull() ? null : hours);
        subject.setActive(rs.getBoolean("esta_activa"));
        return subject;
    }

    private Connection connection() { return DatabaseConnection.getInstance(); }
    private RuntimeException failure(String message, SQLException cause) {
        LoggerHelper.logError(message, cause);
        return new RuntimeException(message, cause);
    }
}
