package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Domain entity representing an inventory resource (Library book, lab instrument, sports item).
 * Maps to the MySQL table 'recursos'.
 */
public class Resource {

    private Integer idResource;
    private String resourceCode;
    private String resourceName;
    private int idCategory;
    private String description;
    private LocalDate acquisitionDate;
    private String physicalLocation;
    private String resourceStatus; // 'Disponible', 'Prestado', 'En Mantenimiento', 'Dado de Baja'

    // Descriptive field from SQL JOIN
    private String categoryName;

    public Resource() {
    }

    public Resource(Integer idResource, String resourceCode, String resourceName, int idCategory,
                    String description, LocalDate acquisitionDate, String physicalLocation, String resourceStatus) {
        this.idResource = idResource;
        this.resourceCode = resourceCode;
        this.resourceName = resourceName;
        this.idCategory = idCategory;
        this.description = description;
        this.acquisitionDate = acquisitionDate;
        this.physicalLocation = physicalLocation;
        this.resourceStatus = resourceStatus != null ? resourceStatus : "Disponible";
    }

    public Integer getIdResource() {
        return idResource;
    }

    public void setIdResource(Integer idResource) {
        this.idResource = idResource;
    }

    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getAcquisitionDate() {
        return acquisitionDate;
    }

    public void setAcquisitionDate(LocalDate acquisitionDate) {
        this.acquisitionDate = acquisitionDate;
    }

    public String getPhysicalLocation() {
        return physicalLocation;
    }

    public void setPhysicalLocation(String physicalLocation) {
        this.physicalLocation = physicalLocation;
    }

    public String getResourceStatus() {
        return resourceStatus;
    }

    public void setResourceStatus(String resourceStatus) {
        this.resourceStatus = resourceStatus;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    @Override
    public String toString() {
        return String.format("[%s] %-25s | Categoria: %-15s | Ubicacion: %-15s | Estado: %s",
                resourceCode, resourceName, 
                categoryName != null ? categoryName : ("Cat " + idCategory),
                physicalLocation != null ? physicalLocation : "N/A", 
                resourceStatus);
    }
}
