package com.littlehorizons.erp;

import com.littlehorizons.erp.util.LoggerHelper;
import com.littlehorizons.erp.view.MainMenuView;

/**
 * Main application entry point for the Little Horizons ERP System.
 */
public class Main {

    public static void main(String[] args) {
        try {
            LoggerHelper.logInfo("Application Little Horizons ERP started successfully.");
            MainMenuView mainMenuView = new MainMenuView();
            mainMenuView.displayMainMenu();
        } catch (Exception e) {
            LoggerHelper.logError("Unhandled critical error in application execution: " + e.getMessage(), e);
            System.err.println("\n[ERROR] Error inesperado. Consulte 'error_log.txt' para mas detalles.");
        }
    }
}
