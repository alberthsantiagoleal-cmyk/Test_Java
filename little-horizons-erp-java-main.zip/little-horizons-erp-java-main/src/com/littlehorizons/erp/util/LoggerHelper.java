package com.littlehorizons.erp.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility class to handle error and application logging.
 * Logs are written to an 'error_log.txt' file in the project root directory.
 * Follows Single Responsibility Principle (SRP).
 */
public class LoggerHelper {

    private static final String LOG_FILE_PATH = "error_log.txt";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private LoggerHelper() {
        // Private constructor for utility class
    }

    /**
     * Logs an error message to the log file.
     *
     * @param message Description of the error
     */
    public static void logError(String message) {
        log("ERROR", message, null);
    }

    /**
     * Logs an error message along with the exception stack trace.
     *
     * @param message   Description of the error
     * @param throwable Exception that triggered the log
     */
    public static void logError(String message, Throwable throwable) {
        log("ERROR", message, throwable);
    }

    /**
     * Logs an informational message.
     *
     * @param message Description of the information
     */
    public static void logInfo(String message) {
        log("INFO", message, null);
    }

    /**
     * Core logging method that safely appends formatted log entries to the file.
     *
     * @param level     Log level (INFO, WARN, ERROR)
     * @param message   Log message
     * @param throwable Optional exception
     */
    private static synchronized void log(String level, String message, Throwable throwable) {
        String timestamp = LocalDateTime.now().format(DATE_FORMATTER);
        String formattedMessage = String.format("[%s] [%s] %s", timestamp, level, message);

        try (FileWriter fw = new FileWriter(LOG_FILE_PATH, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter pw = new PrintWriter(bw)) {

            pw.println(formattedMessage);
            if (throwable != null) {
                throwable.printStackTrace(pw);
            }

        } catch (IOException e) {
            System.err.println("CRITICAL: Failed to write to log file: " + e.getMessage());
        }
    }
}
