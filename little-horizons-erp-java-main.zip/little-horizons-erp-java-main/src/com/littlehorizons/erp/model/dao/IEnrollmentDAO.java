package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.Enrollment;
import java.util.List;

public interface IEnrollmentDAO {
    void create(Enrollment enrollment);
    List<Enrollment> findAll();
    List<Enrollment> findByStudentId(int studentId);
    boolean existsForStudentAndYear(int studentId, int academicYear);
}
