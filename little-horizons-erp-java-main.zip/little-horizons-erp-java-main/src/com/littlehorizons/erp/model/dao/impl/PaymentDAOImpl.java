package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IPaymentDAO;
import com.littlehorizons.erp.model.entity.Payment;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of IPaymentDAO using PreparedStatements and transactions.
 */
public class PaymentDAOImpl implements IPaymentDAO {

    private static final String BASE_SELECT =
            "SELECT p.id_pago, p.id_estudiante, p.id_acudiente, p.id_concepto, p.monto_pagado, " +
            "       p.fecha_pago, p.metodo_pago, p.numero_recibo, p.año_academico, p.periodo_academico, p.notas, " +
            "       CONCAT(e.primer_nombre, ' ', e.primer_apellido) AS nombre_estudiante, " +
            "       c.nombre_concepto " +
            "FROM pagos p " +
            "LEFT JOIN estudiantes e ON p.id_estudiante = e.id_estudiante " +
            "LEFT JOIN conceptos_pago c ON p.id_concepto = c.id_concepto ";

    @Override
    public void create(Payment payment) {
        String sql = "INSERT INTO pagos (id_estudiante, id_acudiente, id_concepto, monto_pagado, " +
                     "fecha_pago, metodo_pago, numero_recibo, año_academico, periodo_academico, notas) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setInt(1, payment.getIdStudent());

            if (payment.getIdGuardian() != null && payment.getIdGuardian() > 0) {
                pst.setInt(2, payment.getIdGuardian());
            } else {
                pst.setNull(2, Types.INTEGER);
            }

            pst.setInt(3, payment.getIdConcept());
            pst.setDouble(4, payment.getAmountPaid());
            pst.setDate(5, Date.valueOf(payment.getPaymentDate()));
            pst.setString(6, payment.getPaymentMethod());
            pst.setString(7, payment.getReceiptNumber());

            if (payment.getAcademicYear() != null) {
                pst.setInt(8, payment.getAcademicYear());
            } else {
                pst.setNull(8, Types.INTEGER);
            }

            pst.setString(9, payment.getAcademicPeriod());
            pst.setString(10, payment.getNotes());

            pst.executeUpdate();

            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    payment.setIdPayment(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in create payment: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar el pago en la base de datos.", e);
        }
    }

    @Override
    public Payment findById(int idPayment) {
        String sql = BASE_SELECT + "WHERE p.id_pago = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idPayment);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById payment [" + idPayment + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar pago por ID.", e);
        }
        return null;
    }

    @Override
    public Payment findByReceiptNumber(String receiptNumber) {
        String sql = BASE_SELECT + "WHERE p.numero_recibo = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, receiptNumber);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByReceiptNumber [" + receiptNumber + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar pago por número de recibo.", e);
        }
        return null;
    }

    @Override
    public List<Payment> findByStudentId(int idStudent) {
        String sql = BASE_SELECT + "WHERE p.id_estudiante = ? ORDER BY p.fecha_pago DESC";
        List<Payment> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idStudent);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByStudentId [" + idStudent + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar historial de pagos del estudiante.", e);
        }
        return list;
    }

    @Override
    public List<Payment> findByGuardianId(int idGuardian) {
        String sql = BASE_SELECT + "WHERE p.id_acudiente = ? ORDER BY p.fecha_pago DESC";
        List<Payment> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idGuardian);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByGuardianId [" + idGuardian + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar historial de pagos del acudiente.", e);
        }
        return list;
    }

    @Override
    public List<Payment> findAll() {
        String sql = BASE_SELECT + "ORDER BY p.id_pago ASC";
        List<Payment> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll payments: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar todos los pagos.", e);
        }
        return list;
    }

    private Payment mapResultSetToEntity(ResultSet rs) throws SQLException {
        Integer guardianId = rs.getInt("id_acudiente");
        if (rs.wasNull()) {
            guardianId = null;
        }

        Integer year = rs.getInt("año_academico");
        if (rs.wasNull()) {
            year = null;
        }

        Payment payment = new Payment(
                rs.getInt("id_pago"),
                rs.getInt("id_estudiante"),
                guardianId,
                rs.getInt("id_concepto"),
                rs.getDouble("monto_pagado"),
                rs.getDate("fecha_pago").toLocalDate(),
                rs.getString("metodo_pago"),
                rs.getString("numero_recibo"),
                year,
                rs.getString("periodo_academico"),
                rs.getString("notas")
        );

        payment.setStudentName(rs.getString("nombre_estudiante"));
        payment.setConceptName(rs.getString("nombre_concepto"));
        return payment;
    }
}
