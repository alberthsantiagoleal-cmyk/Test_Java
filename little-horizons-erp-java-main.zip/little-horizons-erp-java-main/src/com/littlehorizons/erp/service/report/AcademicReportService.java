package com.littlehorizons.erp.service.report;

import com.littlehorizons.erp.model.entity.AcademicRecord;
import com.littlehorizons.erp.model.entity.Attendance;
import com.littlehorizons.erp.model.entity.Enrollment;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Objects;

public class AcademicReportService {
    public record CriticalAbsence(int studentId, long absenceCount) { }

    public OptionalDouble averageByStudentAndSubject(List<AcademicRecord> records, int studentId,
            int subjectId, int year, String period) {
        return uniqueGrades(records.stream()
                .filter(record -> record != null
                        && record.getStudentId() == studentId
                        && record.getSubjectId() == subjectId
                        && record.getAcademicYear() == year
                        && Objects.equals(record.getAcademicPeriod(), period)))
                .mapToDouble(record -> record.getGrade().doubleValue())
                .average();
    }

    public OptionalDouble averageByStudentAndPeriod(List<AcademicRecord> records, int studentId,
            int year, String period) {
        return uniqueGrades(records.stream()
                .filter(record -> record != null
                        && record.getStudentId() == studentId
                        && record.getAcademicYear() == year
                        && Objects.equals(record.getAcademicPeriod(), period)))
                .mapToDouble(record -> record.getGrade().doubleValue())
                .average();
    }

    public OptionalDouble averageByCourseSubjectAndPeriod(List<AcademicRecord> records,
            List<Enrollment> enrollments, int gradeId, int subjectId, int year, String period) {
        Set<Integer> courseStudentIds = enrollments.stream()
                .filter(enrollment -> enrollment != null
                        && enrollment.getGradeId() == gradeId
                        && enrollment.getAcademicYear() == year
                        && !"Retirada".equals(enrollment.getStatus()))
                .map(Enrollment::getStudentId)
                .collect(Collectors.toSet());
        return uniqueGrades(records.stream()
                .filter(record -> record != null
                        && courseStudentIds.contains(record.getStudentId())
                        && record.getSubjectId() == subjectId
                        && record.getAcademicYear() == year
                        && Objects.equals(record.getAcademicPeriod(), period)))
                .mapToDouble(record -> record.getGrade().doubleValue())
                .average();
    }

    public List<CriticalAbsence> criticalWeeklyAbsences(List<Attendance> attendances, LocalDate dateInWeek) {
        if (dateInWeek == null) throw new IllegalArgumentException("La fecha de la semana es obligatoria.");
        LocalDate start = dateInWeek.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate end = start.plusDays(6);
        Map<Integer, Long> absencesByStudent = attendances.stream()
                .filter(attendance -> attendance != null
                        && "Ausente".equals(attendance.getStatus())
                        && attendance.getAttendanceDate() != null
                        && !attendance.getAttendanceDate().isBefore(start)
                        && !attendance.getAttendanceDate().isAfter(end))
                .collect(Collectors.groupingBy(Attendance::getStudentId,
                        Collectors.mapping(this::absenceIdentity, Collectors.toSet())))
                .entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> (long) entry.getValue().size()));
        return absencesByStudent.entrySet().stream()
                .filter(entry -> entry.getValue() > 3)
                .map(entry -> new CriticalAbsence(entry.getKey(), entry.getValue()))
                .sorted(Comparator.comparingInt(CriticalAbsence::studentId))
                .collect(Collectors.toList());
    }

    private Stream<AcademicRecord> uniqueGrades(Stream<AcademicRecord> records) {
        return records.filter(record -> record != null && record.getGrade() != null)
                .collect(Collectors.toMap(
                        record -> record.getStudentId() + ":" + record.getSubjectId() + ":"
                                + record.getAcademicYear() + ":" + record.getAcademicPeriod(),
                        record -> record,
                        (first, ignored) -> first))
                .values().stream();
    }

    private String absenceIdentity(Attendance attendance) {
        return attendance.getStudentId() + ":" + attendance.getSubjectId() + ":" + attendance.getAttendanceDate();
    }
}
