package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IClubDAO;
import com.littlehorizons.erp.model.entity.Club;
import com.littlehorizons.erp.model.entity.ClubMembership;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of IClubDAO using PreparedStatements.
 */
public class ClubDAOImpl implements IClubDAO {

    private static final String BASE_SELECT_CLUB =
            "SELECT c.id_club, c.nombre_club, c.descripcion, c.id_profesor_supervisor, " +
            "       c.capacidad_maxima, c.horario_reunion, c.esta_activo, " +
            "       CONCAT(p.primer_nombre, ' ', COALESCE(p.primer_apellido, '')) AS nombre_profesor, " +
            "       (SELECT COUNT(*) FROM membresias_club m WHERE m.id_club = c.id_club AND m.estado_membresia = 'Activa') AS miembros_activos " +
            "FROM clubes c " +
            "LEFT JOIN profesores p ON c.id_profesor_supervisor = p.id_profesor ";

    private static final String BASE_SELECT_MEMBERSHIP =
            "SELECT m.id_membresia, m.id_estudiante, m.id_club, m.fecha_ingreso, " +
            "       m.estado_membresia, m.fecha_retiro, m.motivo_retiro, " +
            "       CONCAT(e.primer_nombre, ' ', COALESCE(e.primer_apellido, '')) AS nombre_estudiante, " +
            "       e.numero_documento, c.nombre_club " +
            "FROM membresias_club m " +
            "INNER JOIN estudiantes e ON m.id_estudiante = e.id_estudiante " +
            "INNER JOIN clubes c ON m.id_club = c.id_club ";

    @Override
    public List<Club> findAll() {
        String sql = BASE_SELECT_CLUB + "ORDER BY c.id_club ASC";
        List<Club> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToClub(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll clubs: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar catalogo de clubes.", e);
        }
        return list;
    }

    @Override
    public List<Club> findActive() {
        String sql = BASE_SELECT_CLUB + "WHERE c.esta_activo = TRUE ORDER BY c.id_club ASC";
        List<Club> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToClub(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findActive clubs: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar clubes activos.", e);
        }
        return list;
    }

    @Override
    public Club findById(int idClub) {
        String sql = BASE_SELECT_CLUB + "WHERE c.id_club = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idClub);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToClub(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById club (" + idClub + "): " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar el club por ID.", e);
        }
        return null;
    }

    @Override
    public Club findByName(String name) {
        String sql = BASE_SELECT_CLUB + "WHERE LOWER(c.nombre_club) = LOWER(?)";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, name != null ? name.trim() : "");
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToClub(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByName club (" + name + "): " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar club por nombre.", e);
        }
        return null;
    }

    @Override
    public void create(Club club) {
        String sql = "INSERT INTO clubes (nombre_club, descripcion, id_profesor_supervisor, " +
                     "capacidad_maxima, horario_reunion, esta_activo) VALUES (?, ?, ?, ?, ?, ?)";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, club.getClubName());
            pst.setString(2, club.getDescription());
            if (club.getIdTeacherSupervisor() != null && club.getIdTeacherSupervisor() > 0) {
                pst.setInt(3, club.getIdTeacherSupervisor());
            } else {
                pst.setNull(3, Types.INTEGER);
            }
            pst.setInt(4, club.getMaxCapacity() > 0 ? club.getMaxCapacity() : 30);
            pst.setString(5, club.getMeetingSchedule());
            pst.setBoolean(6, club.isActive());

            pst.executeUpdate();
            try (ResultSet generatedKeys = pst.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    club.setIdClub(generatedKeys.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error creating club: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar el nuevo club: " + e.getMessage(), e);
        }
    }

    @Override
    public void update(Club club) {
        String sql = "UPDATE clubes SET nombre_club = ?, descripcion = ?, id_profesor_supervisor = ?, " +
                     "capacidad_maxima = ?, horario_reunion = ?, esta_activo = ? WHERE id_club = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, club.getClubName());
            pst.setString(2, club.getDescription());
            if (club.getIdTeacherSupervisor() != null && club.getIdTeacherSupervisor() > 0) {
                pst.setInt(3, club.getIdTeacherSupervisor());
            } else {
                pst.setNull(3, Types.INTEGER);
            }
            pst.setInt(4, club.getMaxCapacity());
            pst.setString(5, club.getMeetingSchedule());
            pst.setBoolean(6, club.isActive());
            pst.setInt(7, club.getIdClub());

            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error updating club: " + e.getMessage(), e);
            throw new RuntimeException("Error al actualizar la informacion del club.", e);
        }
    }

    @Override
    public int countActiveMembers(int idClub) {
        String sql = "SELECT COUNT(*) FROM membresias_club WHERE id_club = ? AND estado_membresia = 'Activa'";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idClub);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error counting active members for club (" + idClub + "): " + e.getMessage(), e);
            throw new RuntimeException("Error al contar miembros activos del club.", e);
        }
        return 0;
    }

    @Override
    public void registerMembership(ClubMembership membership) {
        String sql = "INSERT INTO membresias_club (id_estudiante, id_club, fecha_ingreso, estado_membresia) " +
                     "VALUES (?, ?, ?, ?)";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setInt(1, membership.getIdStudent());
            pst.setInt(2, membership.getIdClub());
            pst.setDate(3, Date.valueOf(membership.getEnrollmentDate() != null ? membership.getEnrollmentDate() : LocalDate.now()));
            pst.setString(4, membership.getMembershipStatus() != null ? membership.getMembershipStatus() : "Activa");

            pst.executeUpdate();
            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    membership.setIdMembership(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error registering club membership: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar la membresia en el club: " + e.getMessage(), e);
        }
    }

    @Override
    public void withdrawMembership(int idMembership, LocalDate withdrawalDate, String reason) {
        String sql = "UPDATE membresias_club SET estado_membresia = 'Retirada', fecha_retiro = ?, motivo_retiro = ? " +
                     "WHERE id_membresia = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setDate(1, Date.valueOf(withdrawalDate != null ? withdrawalDate : LocalDate.now()));
            pst.setString(2, reason != null ? reason.trim() : "Retiro voluntario");
            pst.setInt(3, idMembership);

            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error withdrawing club membership: " + e.getMessage(), e);
            throw new RuntimeException("Error al retirar al estudiante del club.", e);
        }
    }

    @Override
    public List<ClubMembership> findMembershipsByClub(int idClub) {
        String sql = BASE_SELECT_MEMBERSHIP + "WHERE m.id_club = ? ORDER BY m.estado_membresia ASC, m.fecha_ingreso DESC";
        List<ClubMembership> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idClub);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToMembership(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error finding memberships by club: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar miembros del club.", e);
        }
        return list;
    }

    @Override
    public List<ClubMembership> findMembershipsByStudent(int idStudent) {
        String sql = BASE_SELECT_MEMBERSHIP + "WHERE m.id_estudiante = ? ORDER BY m.fecha_ingreso DESC";
        List<ClubMembership> list = new ArrayList<>();
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idStudent);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToMembership(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error finding memberships by student: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar clubes del estudiante.", e);
        }
        return list;
    }

    @Override
    public ClubMembership findMembershipById(int idMembership) {
        String sql = BASE_SELECT_MEMBERSHIP + "WHERE m.id_membresia = ?";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idMembership);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToMembership(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error finding membership by ID: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar membresia por ID.", e);
        }
        return null;
    }

    @Override
    public boolean isStudentActiveMember(int idStudent, int idClub) {
        String sql = "SELECT COUNT(*) FROM membresias_club WHERE id_estudiante = ? AND id_club = ? AND estado_membresia = 'Activa'";
        Connection con = DatabaseConnection.getInstance();

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idStudent);
            pst.setInt(2, idClub);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error checking if student is active member: " + e.getMessage(), e);
            throw new RuntimeException("Error al validar membresia activa del estudiante.", e);
        }
        return false;
    }

    private Club mapResultSetToClub(ResultSet rs) throws SQLException {
        Club club = new Club();
        club.setIdClub(rs.getInt("id_club"));
        club.setClubName(rs.getString("nombre_club"));
        club.setDescription(rs.getString("descripcion"));
        int idTeacher = rs.getInt("id_profesor_supervisor");
        if (!rs.wasNull()) {
            club.setIdTeacherSupervisor(idTeacher);
        }
        club.setMaxCapacity(rs.getInt("capacidad_maxima"));
        club.setMeetingSchedule(rs.getString("horario_reunion"));
        club.setActive(rs.getBoolean("esta_activo"));
        club.setTeacherSupervisorName(rs.getString("nombre_profesor"));
        club.setActiveMembersCount(rs.getInt("miembros_activos"));
        return club;
    }

    private ClubMembership mapResultSetToMembership(ResultSet rs) throws SQLException {
        ClubMembership m = new ClubMembership();
        m.setIdMembership(rs.getInt("id_membresia"));
        m.setIdStudent(rs.getInt("id_estudiante"));
        m.setIdClub(rs.getInt("id_club"));
        Date enrollmentDate = rs.getDate("fecha_ingreso");
        if (enrollmentDate != null) {
            m.setEnrollmentDate(enrollmentDate.toLocalDate());
        }
        m.setMembershipStatus(rs.getString("estado_membresia"));
        Date withdrawalDate = rs.getDate("fecha_retiro");
        if (withdrawalDate != null) {
            m.setWithdrawalDate(withdrawalDate.toLocalDate());
        }
        m.setWithdrawalReason(rs.getString("motivo_retiro"));
        m.setStudentName(rs.getString("nombre_estudiante"));
        m.setStudentDocument(rs.getString("numero_documento"));
        m.setClubName(rs.getString("nombre_club"));
        return m;
    }
}
