package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Domain entity representing a resource loan granted to a Student.
 * Maps to the MySQL table 'prestamos_estudiante'.
 */
public class StudentLoan extends Loan {

    private int idStudent;
    private String studentName;

    public StudentLoan() {
        super();
    }

    public StudentLoan(Integer idLoan, int idResource, int idStudent, LocalDate loanDate,
                       LocalDate expectedReturnDate, LocalDate actualReturnDate,
                       String loanStatus, String observations) {
        super(idLoan, idResource, loanDate, expectedReturnDate, actualReturnDate, loanStatus, observations);
        this.idStudent = idStudent;
    }

    @Override
    public String getBorrowerType() {
        return "Estudiante";
    }

    @Override
    public String getBorrowerName() {
        return studentName != null ? studentName : ("Estudiante ID: " + idStudent);
    }

    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    @Override
    public String toString() {
        return String.format("Prestamo #%d | Recurso: %s | Estudiante: %s | Prestado: %s | Devolucion: %s | Estado: %s",
                idLoan, 
                resourceName != null ? resourceName : ("Recurso " + idResource),
                getBorrowerName(),
                loanDate, expectedReturnDate, loanStatus);
    }
}
