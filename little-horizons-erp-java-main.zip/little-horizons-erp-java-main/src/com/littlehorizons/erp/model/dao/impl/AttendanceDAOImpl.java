package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IAttendanceDAO;
import com.littlehorizons.erp.model.entity.Attendance;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAOImpl implements IAttendanceDAO {
    private static final String COLUMNS = "id_asistencia, id_estudiante, id_materia, fecha_asistencia, "
            + "estado_asistencia, observaciones, registrado_por";

    @Override
    public void create(Attendance attendance) {
        String sql = "INSERT INTO asistencias (id_estudiante, id_materia, fecha_asistencia, estado_asistencia, "
                + "observaciones, registrado_por) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setInt(1, attendance.getStudentId());
            statement.setInt(2, attendance.getSubjectId());
            statement.setDate(3, Date.valueOf(attendance.getAttendanceDate()));
            statement.setString(4, attendance.getStatus());
            statement.setString(5, attendance.getObservations());
            if (attendance.getRegisteredBy() == null) statement.setNull(6, java.sql.Types.INTEGER);
            else statement.setInt(6, attendance.getRegisteredBy());
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) attendance.setIdAttendance(keys.getInt(1));
            }
        } catch (SQLException e) {
            throw failure("Error al registrar asistencia.", e);
        }
    }

    @Override
    public List<Attendance> findAll() {
        return list("SELECT " + COLUMNS + " FROM asistencias ORDER BY fecha_asistencia DESC, id_estudiante",
                null, null, null);
    }

    @Override
    public List<Attendance> findByStudentIdAndDateRange(int studentId, LocalDate from, LocalDate to) {
        String sql = "SELECT " + COLUMNS + " FROM asistencias WHERE id_estudiante=? "
                + "AND fecha_asistencia BETWEEN ? AND ? ORDER BY fecha_asistencia, id_materia";
        return list(sql, studentId, from, to);
    }

    @Override
    public boolean existsForStudentSubjectDate(int studentId, int subjectId, LocalDate date) {
        String sql = "SELECT 1 FROM asistencias WHERE id_estudiante=? AND id_materia=? AND fecha_asistencia=?";
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            statement.setInt(1, studentId);
            statement.setInt(2, subjectId);
            statement.setDate(3, Date.valueOf(date));
            try (ResultSet rs = statement.executeQuery()) { return rs.next(); }
        } catch (SQLException e) {
            throw failure("Error al validar asistencia existente.", e);
        }
    }

    private List<Attendance> list(String sql, Integer studentId, LocalDate from, LocalDate to) {
        List<Attendance> attendances = new ArrayList<>();
        try (PreparedStatement statement = connection().prepareStatement(sql)) {
            if (studentId != null) {
                statement.setInt(1, studentId);
                if (from != null && to != null) {
                    statement.setDate(2, Date.valueOf(from));
                    statement.setDate(3, Date.valueOf(to));
                }
            }
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) attendances.add(map(rs));
            }
            return attendances;
        } catch (SQLException e) {
            throw failure("Error al consultar asistencias.", e);
        }
    }

    private Attendance map(ResultSet rs) throws SQLException {
        Attendance attendance = new Attendance();
        attendance.setIdAttendance(rs.getInt("id_asistencia"));
        attendance.setStudentId(rs.getInt("id_estudiante"));
        attendance.setSubjectId(rs.getInt("id_materia"));
        attendance.setAttendanceDate(rs.getDate("fecha_asistencia").toLocalDate());
        attendance.setStatus(rs.getString("estado_asistencia"));
        attendance.setObservations(rs.getString("observaciones"));
        int teacherId = rs.getInt("registrado_por");
        attendance.setRegisteredBy(rs.wasNull() ? null : teacherId);
        return attendance;
    }

    private Connection connection() { return DatabaseConnection.getInstance(); }
    private RuntimeException failure(String message, SQLException cause) {
        LoggerHelper.logError(message, cause);
        return new RuntimeException(message, cause);
    }
}
