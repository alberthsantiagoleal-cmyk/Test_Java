package com.littlehorizons.erp.model.entity;

public class Subject {
    private Integer idSubject;
    private String code;
    private String name;
    private String description;
    private int gradeId;
    private Integer weeklyHours = 2;
    private boolean active = true;

    public Subject() {
    }

    public Integer getIdSubject() { return idSubject; }
    public void setIdSubject(Integer idSubject) { this.idSubject = idSubject; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getGradeId() { return gradeId; }
    public void setGradeId(int gradeId) { this.gradeId = gradeId; }
    public Integer getWeeklyHours() { return weeklyHours; }
    public void setWeeklyHours(Integer weeklyHours) { this.weeklyHours = weeklyHours; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
