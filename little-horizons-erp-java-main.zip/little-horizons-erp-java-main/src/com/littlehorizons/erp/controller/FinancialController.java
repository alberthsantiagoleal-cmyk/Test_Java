package com.littlehorizons.erp.controller;

import com.littlehorizons.erp.model.dao.IInvoiceDAO;
import com.littlehorizons.erp.model.dao.IPaymentConceptDAO;
import com.littlehorizons.erp.model.dao.IPaymentDAO;
import com.littlehorizons.erp.model.dao.impl.InvoiceDAOImpl;
import com.littlehorizons.erp.model.dao.impl.PaymentConceptDAOImpl;
import com.littlehorizons.erp.model.dao.impl.PaymentDAOImpl;
import com.littlehorizons.erp.model.entity.Invoice;
import com.littlehorizons.erp.model.entity.Payment;
import com.littlehorizons.erp.model.entity.PaymentConcept;
import com.littlehorizons.erp.service.billing.FeeCalculationStrategy;
import com.littlehorizons.erp.service.invoice.ElectronicInvoiceService;

import java.time.LocalDate;
import java.util.List;
import java.util.Random;

/**
 * Controller orchestrating business logic and validations for the Financial Module.
 * Follows Single Responsibility (SRP) and Dependency Inversion (DIP) principles.
 */
public class FinancialController {

    private final IPaymentConceptDAO paymentConceptDAO;
    private final IPaymentDAO paymentDAO;
    private final IInvoiceDAO invoiceDAO;
    private final ElectronicInvoiceService invoiceService;

    public FinancialController() {
        this(new PaymentConceptDAOImpl(), new PaymentDAOImpl(), new InvoiceDAOImpl(), new ElectronicInvoiceService());
    }

    public FinancialController(IPaymentConceptDAO paymentConceptDAO, IPaymentDAO paymentDAO,
                               IInvoiceDAO invoiceDAO, ElectronicInvoiceService invoiceService) {
        this.paymentConceptDAO = paymentConceptDAO;
        this.paymentDAO = paymentDAO;
        this.invoiceDAO = invoiceDAO;
        this.invoiceService = invoiceService;
    }

    /**
     * Lists all active concepts available in the school's catalog.
     *
     * @return List of active payment concepts
     */
    public List<PaymentConcept> getActivePaymentConcepts() {
        return paymentConceptDAO.findAllActive();
    }

    /**
     * Finds a payment concept by its database ID.
     *
     * @param idConcept Concept ID
     * @return PaymentConcept
     */
    public PaymentConcept getConceptById(int idConcept) {
        PaymentConcept concept = paymentConceptDAO.findById(idConcept);
        if (concept == null) {
            throw new IllegalArgumentException("Concepto de pago no encontrado con ID: " + idConcept);
        }
        return concept;
    }

    /**
     * Applies a calculation strategy to adjust the payment amount (discounts/scholarships).
     *
     * @param baseAmount Base fee
     * @param strategy   Calculation strategy instance
     * @return Calculated final amount
     */
    public double calculateAdjustedAmount(double baseAmount, FeeCalculationStrategy strategy) {
        if (strategy == null) {
            throw new IllegalArgumentException("La estrategia de calculo no puede ser nula.");
        }
        return strategy.calculateFee(baseAmount);
    }

    /**
     * Calculates the final discounted fee using the Strategy design pattern.
     *
     * @param strategy Chosen discount algorithm
     * @param baseFee  Base concept fee in COP
     * @return Final amount after applying policies
     */
    public double calculateFeeWithStrategy(FeeCalculationStrategy strategy, double baseFee) {
        return calculateAdjustedAmount(baseFee, strategy);
    }

    /**
     * Registers a confirmed payment into the ERP system.
     * Generates a unique sequential receipt number and validates payment method.
     *
     * @param studentId       Student ID
     * @param guardianId      Guardian ID who made the payment
     * @param conceptId       Concept being paid
     * @param amount          Amount paid
     * @param method          Payment method ('Efectivo', 'Transferencia', etc.)
     * @param academicYear    Academic year
     * @param academicPeriod  Academic period ('I', 'II', 'III', 'IV', 'Anual')
     * @param notes           Notes or discount justifications
     * @return Created and persisted Payment entity
     */
    public Payment processPayment(int studentId, Integer guardianId, int conceptId, double amount,
                                  String method, Integer academicYear, String academicPeriod, String notes) {
        if (studentId <= 0) {
            throw new IllegalArgumentException("El ID del estudiante debe ser mayor a 0.");
        }
        if (conceptId <= 0) {
            throw new IllegalArgumentException("El ID del concepto debe ser mayor a 0.");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("El monto a pagar debe ser mayor a cero.");
        }

        // Validate payment method
        String validMethod = validatePaymentMethod(method);

        // Generate unique receipt number (e.g., 'REC-2026-482910')
        String receiptNumber = "REC-" + LocalDate.now().getYear() + "-" + (100000 + new Random().nextInt(900000));

        Payment payment = new Payment(
                null,
                studentId,
                guardianId,
                conceptId,
                amount,
                LocalDate.now(),
                validMethod,
                receiptNumber,
                academicYear != null ? academicYear : LocalDate.now().getYear(),
                academicPeriod != null ? academicPeriod : "Anual",
                notes
        );

        paymentDAO.create(payment);
        return payment;
    }

    /**
     * Consults payment history for an individual student.
     *
     * @param studentId Student ID
     * @return List of payments
     */
    public List<Payment> getPaymentsByStudent(int studentId) {
        return paymentDAO.findByStudentId(studentId);
    }

    /**
     * Consults payment history for a parent/guardian (for multi-sibling families).
     *
     * @param guardianId Guardian ID
     * @return List of payments
     */
    public List<Payment> getPaymentsByGuardian(int guardianId) {
        return paymentDAO.findByGuardianId(guardianId);
    }

    /**
     * Lists all registered payments in the system.
     *
     * @return List of all payments
     */
    public List<Payment> getAllPayments() {
        return paymentDAO.findAll();
    }

    /**
     * Lists all generated electronic invoices.
     *
     * @return List of invoices
     */
    public List<Invoice> getAllInvoices() {
        return invoiceDAO.findAll();
    }

    /**
     * Emits a DIAN Electronic Invoice in PDF with CUFE and QR code.
     *
     * @param paymentId ID of the payment
     * @return Generated Invoice entity
     */
    public Invoice emitElectronicInvoice(int paymentId) {
        return invoiceService.generateInvoiceForPayment(paymentId);
    }

    public Invoice getInvoiceByPaymentId(int paymentId) {
        return invoiceService.getInvoiceByPaymentId(paymentId);
    }

    public Invoice getInvoiceById(int invoiceId) {
        return invoiceService.getInvoiceById(invoiceId);
    }

    private String validatePaymentMethod(String method) {
        if (method == null) {
            return "Efectivo";
        }
        String normalized = method.trim();
        List<String> validMethods = List.of("Efectivo", "Transferencia", "Tarjeta Debito", "Tarjeta Credito", "Cheque");
        for (String vm : validMethods) {
            if (vm.equalsIgnoreCase(normalized)) {
                return vm;
            }
        }
        return "Efectivo";
    }
}
