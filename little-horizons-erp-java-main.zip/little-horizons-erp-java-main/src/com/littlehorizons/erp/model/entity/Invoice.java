package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Domain entity representing an Electronic Invoice compliant with DIAN standards.
 * Maps to the MySQL table 'facturas'.
 */
public class Invoice {

    private Integer idInvoice;
    private String invoiceNumber;
    private int idPayment;
    private LocalDate issueDate;
    private String cufe; // Simulated Unique Electronic Invoice Code (SHA-256)
    private String pdfFileName;
    private String filePath;

    public Invoice() {
    }

    public Invoice(Integer idInvoice, String invoiceNumber, int idPayment, LocalDate issueDate, 
                   String cufe, String pdfFileName, String filePath) {
        this.idInvoice = idInvoice;
        this.invoiceNumber = invoiceNumber;
        this.idPayment = idPayment;
        this.issueDate = issueDate;
        this.cufe = cufe;
        this.pdfFileName = pdfFileName;
        this.filePath = filePath;
    }

    public Integer getIdInvoice() {
        return idInvoice;
    }

    public void setIdInvoice(Integer idInvoice) {
        this.idInvoice = idInvoice;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public int getIdPayment() {
        return idPayment;
    }

    public void setIdPayment(int idPayment) {
        this.idPayment = idPayment;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public String getCufe() {
        return cufe;
    }

    public void setCufe(String cufe) {
        this.cufe = cufe;
    }

    public String getPdfFileName() {
        return pdfFileName;
    }

    public void setPdfFileName(String pdfFileName) {
        this.pdfFileName = pdfFileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public String toString() {
        return String.format("Factura: %-15s | Emision: %s | PDF: %s", 
                invoiceNumber, issueDate, pdfFileName);
    }
}
