package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

public class Teacher {
    private Integer idTeacher;
    private String documentType;
    private String documentNumber;
    private String firstName;
    private String middleName;
    private String firstSurname;
    private String secondSurname;
    private String email;
    private String phone;
    private String specialization;
    private LocalDate hireDate;
    private String status;

    public Teacher() {
    }

    public Integer getIdTeacher() { return idTeacher; }
    public void setIdTeacher(Integer idTeacher) { this.idTeacher = idTeacher; }
    public String getDocumentType() { return documentType; }
    public void setDocumentType(String documentType) { this.documentType = documentType; }
    public String getDocumentNumber() { return documentNumber; }
    public void setDocumentNumber(String documentNumber) { this.documentNumber = documentNumber; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getMiddleName() { return middleName; }
    public void setMiddleName(String middleName) { this.middleName = middleName; }
    public String getFirstSurname() { return firstSurname; }
    public void setFirstSurname(String firstSurname) { this.firstSurname = firstSurname; }
    public String getSecondSurname() { return secondSurname; }
    public void setSecondSurname(String secondSurname) { this.secondSurname = secondSurname; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }
    public LocalDate getHireDate() { return hireDate; }
    public void setHireDate(LocalDate hireDate) { this.hireDate = hireDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getFullName() {
        return String.join(" ", firstName != null ? firstName : "",
                middleName == null ? "" : middleName,
                firstSurname != null ? firstSurname : "",
                secondSurname == null ? "" : secondSurname).trim().replaceAll("\\s+", " ");
    }
}
