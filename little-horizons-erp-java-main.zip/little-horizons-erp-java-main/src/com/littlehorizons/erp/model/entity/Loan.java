package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Base abstract class representing an educational resource loan.
 * Demonstrates Inheritance and Liskov Substitution Principle (LSP).
 */
public abstract class Loan {

    protected Integer idLoan;
    protected int idResource;
    protected LocalDate loanDate;
    protected LocalDate expectedReturnDate;
    protected LocalDate actualReturnDate;
    protected String loanStatus; // 'Activo', 'Devuelto', 'Vencido'
    protected String observations;

    // Joined descriptive fields for UI reporting
    protected String resourceName;
    protected String resourceCode;

    public Loan() {
    }

    public Loan(Integer idLoan, int idResource, LocalDate loanDate, LocalDate expectedReturnDate,
                LocalDate actualReturnDate, String loanStatus, String observations) {
        this.idLoan = idLoan;
        this.idResource = idResource;
        this.loanDate = loanDate;
        this.expectedReturnDate = expectedReturnDate;
        this.actualReturnDate = actualReturnDate;
        this.loanStatus = loanStatus != null ? loanStatus : "Activo";
        this.observations = observations;
    }

    public abstract String getBorrowerType();
    public abstract String getBorrowerName();

    public boolean isOverdue() {
        if ("Devuelto".equalsIgnoreCase(loanStatus)) {
            return false;
        }
        return expectedReturnDate != null && expectedReturnDate.isBefore(LocalDate.now());
    }

    public Integer getIdLoan() {
        return idLoan;
    }

    public void setIdLoan(Integer idLoan) {
        this.idLoan = idLoan;
    }

    public int getIdResource() {
        return idResource;
    }

    public void setIdResource(int idResource) {
        this.idResource = idResource;
    }

    public LocalDate getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(LocalDate loanDate) {
        this.loanDate = loanDate;
    }

    public LocalDate getExpectedReturnDate() {
        return expectedReturnDate;
    }

    public void setExpectedReturnDate(LocalDate expectedReturnDate) {
        this.expectedReturnDate = expectedReturnDate;
    }

    public LocalDate getActualReturnDate() {
        return actualReturnDate;
    }

    public void setActualReturnDate(LocalDate actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }

    public String getLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(String loanStatus) {
        this.loanStatus = loanStatus;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getResourceCode() {
        return resourceCode;
    }

    public void setResourceCode(String resourceCode) {
        this.resourceCode = resourceCode;
    }
}
