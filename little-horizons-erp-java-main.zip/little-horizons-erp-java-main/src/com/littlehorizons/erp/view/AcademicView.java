package com.littlehorizons.erp.view;

import com.littlehorizons.erp.controller.AcademicController;
import com.littlehorizons.erp.model.entity.AcademicRecord;
import com.littlehorizons.erp.model.entity.Attendance;
import com.littlehorizons.erp.model.entity.Enrollment;
import com.littlehorizons.erp.model.entity.Guardian;
import com.littlehorizons.erp.model.entity.Student;
import com.littlehorizons.erp.model.entity.Teacher;
import com.littlehorizons.erp.service.report.AcademicReportService;
import com.littlehorizons.erp.util.ConsoleUI;
import com.littlehorizons.erp.util.ScannerHelper;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.OptionalDouble;

public class AcademicView {
    private final ScannerHelper scanner = ScannerHelper.getInstance();
    private final AcademicController controller;
    private final AcademicReportService reports = new AcademicReportService();

    public AcademicView() {
        this(new AcademicController());
    }

    public AcademicView(AcademicController controller) {
        this.controller = controller;
    }

    public void displayStudentsMenu() {
        int option = -1;
        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("GESTION DE ESTUDIANTES Y ACUDIENTES");
            System.out.println("  1. Registrar Nuevo Estudiante");
            System.out.println("  2. Consultar Catalogo de Estudiantes");
            System.out.println("  3. Registrar Nuevo Acudiente");
            System.out.println("  4. Asociar Acudiente a Estudiante");
            System.out.println("  5. Consultar Acudientes de un Estudiante");
            System.out.println("  0. Regresar al Menu Principal");
            ConsoleUI.printDivider();
            option = scanner.readInt("Seleccione una opcion", 0, 5);
            switch (option) {
                case 1 -> execute(this::registerStudent);
                case 2 -> execute(this::listStudents);
                case 3 -> execute(this::registerGuardian);
                case 4 -> execute(this::linkGuardian);
                case 5 -> execute(this::listGuardians);
                case 0 -> System.out.println("\nRegresando al menu principal...");
                default -> ConsoleUI.printError("Opcion inexistente.");
            }
            if (option != 0) scanner.pressEnterToContinue();
        }
    }

    public void displayAcademicMenu() {
        int option = -1;
        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("GESTION ACADEMICA (MATERIAS, NOTAS Y ASISTENCIA)");
            System.out.println("  1. Consultar Catalogo de Materias");
            System.out.println("  2. Registrar Nueva Matricula");
            System.out.println("  3. Consultar Matriculas de Estudiante");
            System.out.println("  4. Registrar Calificacion Academica");
            System.out.println("  5. Consultar Historial Academico y Promedio");
            System.out.println("  6. Registrar Asistencia a Clase");
            System.out.println("  7. Reportes y Consulta de Asistencia");
            System.out.println("  0. Regresar al Menu Principal");
            ConsoleUI.printDivider();
            option = scanner.readInt("Seleccione una opcion", 0, 7);
            switch (option) {
                case 1 -> execute(this::listSubjects);
                case 2 -> execute(this::registerEnrollment);
                case 3 -> execute(this::listEnrollments);
                case 4 -> execute(this::registerAcademicRecord);
                case 5 -> execute(this::showStudentHistory);
                case 6 -> execute(this::registerAttendance);
                case 7 -> execute(this::showReports);
                case 0 -> System.out.println("\nRegresando al menu principal...");
                default -> ConsoleUI.printError("Opcion inexistente.");
            }
            if (option != 0) scanner.pressEnterToContinue();
        }
    }

    public void displayTeachersMenu() {
        int option = -1;
        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("GESTION DE PROFESORES Y CARGA ACADEMICA");
            System.out.println("  1. Registrar Nuevo Profesor");
            System.out.println("  2. Consultar Catalogo de Profesores");
            System.out.println("  3. Consultar Materias por Grado");
            System.out.println("  0. Regresar al Menu Principal");
            ConsoleUI.printDivider();
            option = scanner.readInt("Seleccione una opcion", 0, 3);
            switch (option) {
                case 1 -> execute(this::registerTeacher);
                case 2 -> execute(this::listTeachers);
                case 3 -> execute(this::listSubjects);
                case 0 -> System.out.println("\nRegresando al menu principal...");
                default -> ConsoleUI.printError("Opcion inexistente.");
            }
            if (option != 0) scanner.pressEnterToContinue();
        }
    }

    public void displayMenu() {
        int option = 0;
        while (option != 15) {
            ConsoleUI.clearScreen();
            ConsoleUI.printSectionHeader("Gestion academica");
            System.out.println(" 1. Registrar estudiante");
            System.out.println(" 2. Consultar estudiantes");
            System.out.println(" 3. Registrar acudiente");
            System.out.println(" 4. Asociar acudiente a estudiante");
            System.out.println(" 5. Consultar acudientes de estudiante");
            System.out.println(" 6. Registrar profesor");
            System.out.println(" 7. Consultar profesores");
            System.out.println(" 8. Consultar materias");
            System.out.println(" 9. Registrar matricula");
            System.out.println("10. Consultar matriculas de estudiante");
            System.out.println("11. Registrar calificacion");
            System.out.println("12. Consultar historial y promedio");
            System.out.println("13. Registrar asistencia");
            System.out.println("14. Reportes y consulta de asistencia");
            System.out.println("15. Volver");
            ConsoleUI.printDivider();
            option = scanner.readInt("Seleccione una opcion", 1, 15);
            switch (option) {
                case 1 -> execute(this::registerStudent);
                case 2 -> execute(this::listStudents);
                case 3 -> execute(this::registerGuardian);
                case 4 -> execute(this::linkGuardian);
                case 5 -> execute(this::listGuardians);
                case 6 -> execute(this::registerTeacher);
                case 7 -> execute(this::listTeachers);
                case 8 -> execute(this::listSubjects);
                case 9 -> execute(this::registerEnrollment);
                case 10 -> execute(this::listEnrollments);
                case 11 -> execute(this::registerAcademicRecord);
                case 12 -> execute(this::showStudentHistory);
                case 13 -> execute(this::registerAttendance);
                case 14 -> execute(this::showReports);
                case 15 -> { }
                default -> ConsoleUI.printError("Opcion inexistente.");
            }
            if (option != 15) scanner.pressEnterToContinue();
        }
    }

    public void displayReports() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Reportes academicos");
        execute(this::showReports);
        scanner.pressEnterToContinue();
    }

    private void registerStudent() {
        Student student = new Student();
        student.setDocumentType(scanner.readString("Tipo de documento (TI, CC, CE, Pasaporte)"));
        student.setDocumentNumber(scanner.readString("Numero de documento"));
        student.setFirstName(scanner.readString("Primer nombre"));
        student.setMiddleName(optional("Segundo nombre"));
        student.setFirstSurname(scanner.readString("Primer apellido"));
        student.setSecondSurname(optional("Segundo apellido"));
        student.setBirthDate(scanner.readDate("Fecha de nacimiento"));
        student.setGender(scanner.readString("Genero (M, F, Otro)"));
        student.setAddress(optional("Direccion"));
        student.setPhone(optional("Telefono"));
        student.setEmail(optional("Correo electronico"));
        student.setBloodType(optional("Tipo de sangre"));
        student.setAllergies(optional("Alergias"));
        student.setMedicalConditions(optional("Condiciones medicas"));
        student.setAdmissionDate(scanner.readDate("Fecha de ingreso"));
        controller.registerStudent(student);
        ConsoleUI.printSuccess("Estudiante registrado con ID " + student.getIdStudent() + ".");
    }

    private void listStudents() {
        controller.getStudents().forEach(student -> System.out.printf("%d | %s | %s%n",
                student.getIdStudent(), student.getFullName(), student.getDocumentNumber()));
    }

    private void registerGuardian() {
        Guardian guardian = new Guardian();
        guardian.setDocumentType(scanner.readString("Tipo de documento (CC, CE, Pasaporte)"));
        guardian.setDocumentNumber(scanner.readString("Numero de documento"));
        guardian.setFirstName(scanner.readString("Primer nombre"));
        guardian.setMiddleName(optional("Segundo nombre"));
        guardian.setFirstSurname(scanner.readString("Primer apellido"));
        guardian.setSecondSurname(optional("Segundo apellido"));
        guardian.setRelationship(scanner.readString("Parentesco"));
        guardian.setPrimaryPhone(scanner.readString("Telefono principal"));
        guardian.setSecondaryPhone(optional("Telefono secundario"));
        guardian.setEmail(optional("Correo electronico"));
        guardian.setAddress(optional("Direccion"));
        guardian.setOccupation(optional("Ocupacion"));
        controller.registerGuardian(guardian);
        ConsoleUI.printSuccess("Acudiente registrado con ID " + guardian.getIdGuardian() + ".");
    }

    private void linkGuardian() {
        int studentId = scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE);
        int guardianId = scanner.readInt("ID del acudiente", 1, Integer.MAX_VALUE);
        controller.linkGuardianToStudent(studentId, guardianId, true, true);
        ConsoleUI.printSuccess("Acudiente asociado correctamente.");
    }

    private void listGuardians() {
        int studentId = scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE);
        controller.getGuardiansForStudent(studentId).forEach(guardian -> System.out.printf("%d | %s %s | %s%n",
                guardian.getIdGuardian(), guardian.getFirstName(), guardian.getFirstSurname(), guardian.getPrimaryPhone()));
    }

    private void registerTeacher() {
        Teacher teacher = new Teacher();
        teacher.setDocumentType(scanner.readString("Tipo de documento (CC, CE, Pasaporte)"));
        teacher.setDocumentNumber(scanner.readString("Numero de documento"));
        teacher.setFirstName(scanner.readString("Primer nombre"));
        teacher.setMiddleName(optional("Segundo nombre"));
        teacher.setFirstSurname(scanner.readString("Primer apellido"));
        teacher.setSecondSurname(optional("Segundo apellido"));
        teacher.setEmail(scanner.readString("Correo electronico"));
        teacher.setPhone(optional("Telefono"));
        teacher.setSpecialization(optional("Especializacion"));
        teacher.setHireDate(scanner.readDate("Fecha de contratacion"));
        controller.registerTeacher(teacher);
        ConsoleUI.printSuccess("Profesor registrado con ID " + teacher.getIdTeacher() + ".");
    }

    private void listTeachers() {
        controller.getTeachers().forEach(teacher -> System.out.printf("%d | %s %s | %s%n",
                teacher.getIdTeacher(), teacher.getFirstName(), teacher.getFirstSurname(), teacher.getEmail()));
    }

    private void listSubjects() {
        controller.getSubjects().forEach(subject -> System.out.printf("%d | %s | %s | grado %d%n",
                subject.getIdSubject(), subject.getCode(), subject.getName(), subject.getGradeId()));
    }

    private void registerEnrollment() {
        Enrollment enrollment = new Enrollment();
        enrollment.setStudentId(scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE));
        showGrades();
        enrollment.setGradeId(scanner.readInt("ID del grado", 1, Integer.MAX_VALUE));
        enrollment.setAcademicYear(scanner.readInt("Ano academico", 2000, 9999));
        enrollment.setEnrollmentDate(scanner.readDate("Fecha de matricula"));
        enrollment.setStatus("Activa");
        enrollment.setObservations(optional("Observaciones"));
        controller.registerEnrollment(enrollment);
        ConsoleUI.printSuccess("Matricula registrada con ID " + enrollment.getIdEnrollment() + ".");
    }

    private void showGrades() {
        controller.getGrades().forEach(grade -> System.out.printf("%d | %s%n", grade.getIdGrade(), grade.getName()));
    }

    private void listEnrollments() {
        int studentId = scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE);
        controller.getEnrollmentsForStudent(studentId).forEach(enrollment ->
                System.out.printf("%d | ano %d | grado %d | %s%n", enrollment.getIdEnrollment(),
                        enrollment.getAcademicYear(), enrollment.getGradeId(), enrollment.getStatus()));
    }

    private void registerAcademicRecord() {
        AcademicRecord record = new AcademicRecord();
        record.setStudentId(scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE));
        record.setSubjectId(scanner.readInt("ID de la materia", 1, Integer.MAX_VALUE));
        record.setTeacherId(scanner.readInt("ID del profesor", 1, Integer.MAX_VALUE));
        record.setAcademicYear(scanner.readInt("Ano academico", 2000, 9999));
        record.setAcademicPeriod(scanner.readString("Periodo (I, II, III, IV, Final)"));
        record.setGrade(BigDecimal.valueOf(scanner.readDouble("Calificacion (0.0 a 5.0)", 0.0, 5.0)));
        record.setObservations(optional("Observaciones"));
        record.setRecordDate(scanner.readDate("Fecha de registro"));
        controller.registerAcademicRecord(record);
        ConsoleUI.printSuccess("Calificacion registrada.");
    }

    private void showStudentHistory() {
        int studentId = scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE);
        var history = controller.getAcademicHistory(studentId);
        history.forEach(record -> System.out.printf("%d | materia %d | %d | %s | %s%n",
                record.getIdRecord(), record.getSubjectId(), record.getAcademicYear(),
                record.getAcademicPeriod(), record.getGrade()));
        int year = scanner.readInt("Ano para calcular el promedio", 2000, 9999);
        String period = scanner.readString("Periodo (I, II, III, IV, Final)");
        showAverage("Promedio general", reports.averageByStudentAndPeriod(history, studentId, year, period));
    }

    private void registerAttendance() {
        Attendance attendance = new Attendance();
        attendance.setStudentId(scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE));
        attendance.setSubjectId(scanner.readInt("ID de la materia", 1, Integer.MAX_VALUE));
        attendance.setAttendanceDate(scanner.readDate("Fecha de asistencia"));
        attendance.setStatus(scanner.readString("Estado (Presente, Ausente, Tardanza, Excusa Medica)"));
        attendance.setObservations(optional("Observaciones"));
        String registeredBy = optional("ID del profesor que registra");
        if (!registeredBy.isEmpty()) attendance.setRegisteredBy(Integer.valueOf(registeredBy));
        controller.registerAttendance(attendance);
        ConsoleUI.printSuccess("Asistencia registrada.");
    }

    private void showReports() {
        System.out.println("1. Promedio de un estudiante por materia");
        System.out.println("2. Promedio general de un estudiante por periodo");
        System.out.println("3. Promedio de materia por curso");
        System.out.println("4. Ausencias criticas de la semana actual");
        System.out.println("5. Consultar asistencia de un estudiante por fechas");
        int option = scanner.readInt("Seleccione reporte", 1, 5);
        switch (option) {
            case 1 -> {
                int studentId = scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE);
                int subjectId = scanner.readInt("ID de la materia", 1, Integer.MAX_VALUE);
                int year = scanner.readInt("Ano academico", 2000, 9999);
                String period = scanner.readString("Periodo (I, II, III, IV, Final)");
                showAverage("Promedio por materia", reports.averageByStudentAndSubject(
                        controller.getAcademicHistory(studentId), studentId, subjectId, year, period));
            }
            case 2 -> showStudentHistory();
            case 3 -> {
                int gradeId = scanner.readInt("ID del grado", 1, Integer.MAX_VALUE);
                int subjectId = scanner.readInt("ID de la materia", 1, Integer.MAX_VALUE);
                int year = scanner.readInt("Ano academico", 2000, 9999);
                String period = scanner.readString("Periodo (I, II, III, IV, Final)");
                showAverage("Promedio del curso", reports.averageByCourseSubjectAndPeriod(
                        controller.getAllAcademicRecords(), controller.getEnrollments(), gradeId,
                        subjectId, year, period));
            }
            case 4 -> reports.criticalWeeklyAbsences(controller.getAllAttendance(), LocalDate.now())
                    .forEach(report -> System.out.printf("Estudiante %d: %d ausencias%n",
                            report.studentId(), report.absenceCount()));
            case 5 -> {
                int studentId = scanner.readInt("ID del estudiante", 1, Integer.MAX_VALUE);
                LocalDate from = scanner.readDate("Desde");
                LocalDate to = scanner.readDate("Hasta");
                controller.getAttendanceForStudent(studentId, from, to).forEach(attendance ->
                        System.out.printf("%s | materia %d | %s%n", attendance.getAttendanceDate(),
                                attendance.getSubjectId(), attendance.getStatus()));
            }
            default -> ConsoleUI.printError("Opcion inexistente.");
        }
    }

    private String optional(String label) {
        String value = scanner.readOptionalString(label);
        return value.isEmpty() ? null : value;
    }

    private void showAverage(String label, OptionalDouble average) {
        if (average.isPresent()) System.out.printf("%s: %.2f%n", label, average.getAsDouble());
        else System.out.println(label + ": sin calificaciones registradas para ese periodo.");
    }

    private void execute(Runnable operation) {
        try {
            operation.run();
        } catch (IllegalArgumentException e) {
            ConsoleUI.printError(e.getMessage());
        } catch (RuntimeException e) {
            ConsoleUI.printError("No se pudo completar la operacion: " + e.getMessage());
        }
    }
}
