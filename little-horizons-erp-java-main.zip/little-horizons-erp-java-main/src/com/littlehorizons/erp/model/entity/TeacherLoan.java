package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Domain entity representing a resource loan granted to a Teacher.
 * Maps to the MySQL table 'prestamos_profesor'.
 */
public class TeacherLoan extends Loan {

    private int idTeacher;
    private String teacherName;

    public TeacherLoan() {
        super();
    }

    public TeacherLoan(Integer idLoan, int idResource, int idTeacher, LocalDate loanDate,
                       LocalDate expectedReturnDate, LocalDate actualReturnDate,
                       String loanStatus, String observations) {
        super(idLoan, idResource, loanDate, expectedReturnDate, actualReturnDate, loanStatus, observations);
        this.idTeacher = idTeacher;
    }

    @Override
    public String getBorrowerType() {
        return "Profesor";
    }

    @Override
    public String getBorrowerName() {
        return teacherName != null ? teacherName : ("Profesor ID: " + idTeacher);
    }

    public int getIdTeacher() {
        return idTeacher;
    }

    public void setIdTeacher(int idTeacher) {
        this.idTeacher = idTeacher;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    @Override
    public String toString() {
        return String.format("Prestamo #%d | Recurso: %s | Profesor: %s | Prestado: %s | Devolucion: %s | Estado: %s",
                idLoan, 
                resourceName != null ? resourceName : ("Recurso " + idResource),
                getBorrowerName(),
                loanDate, expectedReturnDate, loanStatus);
    }
}
