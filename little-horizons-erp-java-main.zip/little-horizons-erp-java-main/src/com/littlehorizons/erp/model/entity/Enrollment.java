package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

public class Enrollment {
    private Integer idEnrollment;
    private int studentId;
    private int gradeId;
    private int academicYear;
    private String status;
    private LocalDate enrollmentDate;
    private LocalDate withdrawalDate;
    private String observations;

    public Enrollment() {
    }

    public Integer getIdEnrollment() { return idEnrollment; }
    public void setIdEnrollment(Integer idEnrollment) { this.idEnrollment = idEnrollment; }
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public int getGradeId() { return gradeId; }
    public void setGradeId(int gradeId) { this.gradeId = gradeId; }
    public int getAcademicYear() { return academicYear; }
    public void setAcademicYear(int academicYear) { this.academicYear = academicYear; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDate getEnrollmentDate() { return enrollmentDate; }
    public void setEnrollmentDate(LocalDate enrollmentDate) { this.enrollmentDate = enrollmentDate; }
    public LocalDate getWithdrawalDate() { return withdrawalDate; }
    public void setWithdrawalDate(LocalDate withdrawalDate) { this.withdrawalDate = withdrawalDate; }
    public String getObservations() { return observations; }
    public void setObservations(String observations) { this.observations = observations; }
}
