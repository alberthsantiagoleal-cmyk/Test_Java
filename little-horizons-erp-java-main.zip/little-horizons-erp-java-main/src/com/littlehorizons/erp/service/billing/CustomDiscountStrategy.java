package com.littlehorizons.erp.service.billing;

/**
 * Strategy representing a custom discount percentage specified dynamically by administrative staff.
 */
public class CustomDiscountStrategy implements FeeCalculationStrategy {

    private final double discountPercentage;
    private final String justification;

    public CustomDiscountStrategy(double discountPercentage, String justification) {
        // Enforce percentage bounds between 0% and 100%
        this.discountPercentage = Math.max(0.0, Math.min(100.0, discountPercentage));
        this.justification = (justification == null || justification.isBlank()) 
                ? "Ajuste Personalizado" 
                : justification.trim();
    }

    @Override
    public double calculateFee(double baseAmount) {
        double discounted = baseAmount * (1.0 - (discountPercentage / 100.0));
        return Math.max(0.0, discounted);
    }

    @Override
    public String getStrategyName() {
        return String.format("Ajuste Especial (%.1f%%) - %s", discountPercentage, justification);
    }

    @Override
    public double getDiscountPercentage() {
        return discountPercentage;
    }
}
