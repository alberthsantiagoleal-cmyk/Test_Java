# 📅 Plan de Trabajo Detallado (5 Días)
## ERP Colegio Little Horizons - Pareja de Desarrollo

* **Integrantes:** Santiago & Compañero
* **Objetivo:** 123 / 123 Puntos (100% de cumplimiento en la Rúbrica de Evaluación)
* **Duración:** 5 Días

---

## 🎯 Distribución de la Rúbrica de Evaluación

| Criterio | Puntos | Ponderación | Responsable Principal / Estrategia |
| :--- | :---: | :---: | :--- |
| **Dominio y conocimiento del código** | **49** | **39.8%** | **AMBOS**: Cada integrante domina sus módulos y repasan juntos los patrones y consultas |
| **Poblado de Datos de Prueba (DML)** | **5** | **4.1%** | Santiago: `database.sql` con >= 30 registros coherentes por tabla |
| **Arquitectura MVC y Separación** | **10** | **8.1%** | Separación estricta (`model`, `controller`, `view`, `util`, `service`) |
| **Aplicación de Principios SOLID** | **10** | **8.1%** | SRP en clases, OCP en Strategy de pagos, LSP/ISP/DIP en DAOs |
| **Aplicación de Patrones de Diseño** | **10** | **8.1%** | Singleton, DAO, Strategy, Builder, Factory |
| **Uso de Lambdas y Stream API** | **10** | **8.1%** | Promedios, filtros de morosos, asistencias críticas y ordenamientos |
| **Manejo de Archivos y Sistema de Logs** | **8** | **6.5%** | `error_log.txt` centralizado + Generación de facturas PDF |
| **Persistencia de Datos con JDBC** | **5** | **4.1%** | 100% `PreparedStatement` + `try-with-resources` |
| **Interfaz de Usuario y Consola** | **10** | **8.1%** | Menú ASCII estructurado, validaciones anti-fallos y navegación limpia |
| **Documentación y Gestión de Repo** | **6** | **4.9%** | `README.md` (16 secciones), commits atómicos en inglés, entrega de SHA |
| **TOTAL** | **123** | **100%** | **Nota Máxima** |

---

## 🗓️ Cronograma Diario de Actividades

### 🟢 DÍA 1: Cimientos, Base de Datos y Utilidades Compartidas
* **Meta:** Tener el entorno listo, la base de datos poblada en MySQL y la base de código compilando.

* **Tareas - Santiago:**
  1. Preparar `docs/database.sql` con el DDL corregido y el DML con **mínimo 30 registros reales y coherentes por cada tabla principal** (`estudiantes`, `acudientes`, `profesores`, `materias`, `registros_academicos`, `pagos`, `clubes`, `recursos`).
  2. Ejecutar y verificar el script en MySQL 8.0 local (`erp_little_horizons`).
  3. Asegurar que las llaves foráneas y checks no tengan conflictos.

* **Tareas - Compañero:**
  1. Configurar la estructura de paquetes Java (`com.littlehorizons.erp`).
  2. Desarrollar las clases del paquete `util`:
     * `DatabaseConnection.java` (Patrón **Singleton** con JDBC).
     * `ScannerHelper.java` (Patrón **Singleton** con validaciones numéricas y de cadenas).
     * `LoggerHelper.java` (Escritura en `error_log.txt`).
     * `ConsoleUI.java` (Diseño de menús y utilidades de consola).
  3. Crear `Main.java` y `MainMenuView.java` con el esqueleto del menú principal.

* **Hito de Verificación Día 1:**
  * Prueba de conexión exitosa entre Java y MySQL `erp_little_horizons`.
  * Menú principal navegable.
  * Primer commit atómico en GitHub: `feat: initialize project architecture and database schema`.

---

### 🟡 DÍA 2: Módulos Nucleares (Académico Base vs. Financiero Base)
* **Meta:** CRUDs y persistencia funcional de entidades principales.

* **Tareas - Santiago (Módulo Académico Base):**
  1. Entidades: `Student`, `Guardian`, `Teacher`, `Subject`, `Enrollment`.
  2. DAOs e Implementaciones JDBC: `IStudentDAO`, `IGuardianDAO`, `ITeacherDAO`, `ISubjectDAO`.
  3. `AcademicController`: Validaciones de campos (documentos únicos, correos válidos, relaciones acudiente-estudiante).
  4. `AcademicView`: Submenú para registro y consulta de estudiantes, acudientes y profesores.

* **Tareas - Compañero (Módulo Financiero Base & Strategy):**
  1. Entidades: `PaymentConcept`, `Payment`, `Invoice`.
  2. DAOs e Implementaciones JDBC: `IPaymentConceptDAO`, `IPaymentDAO`, `IInvoiceDAO`.
  3. Patrón **Strategy** para cálculo de tarifas/descuentos:
     * Interfaz `FeeCalculationStrategy`.
     * `RegularFeeStrategy`, `SiblingDiscountStrategy` (descuento hermanos), `ScholarshipDiscountStrategy` (beca).
  4. `FinancialController`: Registro de pagos y validación de montos.
  5. `FinancialView`: Submenú para consulta de conceptos y registro de pagos.

* **Hito de Verificación Día 2:**
  * Registrar un estudiante y su acudiente desde consola y verlo reflejado en MySQL.
  * Registrar un pago con cálculo de descuento y verificar el recibo en base de datos.
  * Commits atómicos: `feat(academic): implement student and teacher dao with controllers`, `feat(financial): implement payment dao and fee strategy`.

---

### 🟠 DÍA 3: Calificaciones, Asistencia, Recursos y Actividades Extracurriculares
* **Meta:** Procesamiento de reglas de negocio específicas y control de cupos/préstamos.

* **Tareas - Santiago (Notas y Asistencia):**
  1. Entidades y DAOs: `AcademicRecord` (calificaciones) y `Attendance` (asistencia).
  2. Reglas de negocio:
     * Calificación válida de `0.0` a `5.0`.
     * Períodos: `I`, `II`, `III`, `IV`, `Final`.
  3. Registro diario de asistencia por materia (`Presente`, `Ausente`, `Tardanza`, `Excusa Médica`).
  4. Vistas de ingreso de notas e historial académico de un estudiante.

* **Tareas - Compañero (Recursos y Extracurriculares):**
  1. Módulo Recursos:
     * Entidades y DAOs: `Resource`, `StudentLoan` (`prestamos_estudiante`), `TeacherLoan` (`prestamos_profesor`).
     * Control de inventario: cambiar estado a `Prestado` al prestar y a `Disponible` al devolver.
  2. Módulo Extracurriculares:
     * Entidades y DAOs: `Club`, `ClubMembership`, `SchoolEvent`, `EventParticipant`.
     * Validación de negocio: **No exceder cupo máximo del club** (`capacidad_maxima`).
     * Eventos con registro de posiciones (`1er Lugar`, `2do Lugar`, etc.).

* **Hito de Verificación Día 3:**
  * Intentar inscribir más estudiantes del cupo en un club y verificar que el sistema lo rechaza.
  * Prestar un recurso a un estudiante y verificar que su estado cambia a `Prestado`.
  * Registrar notas y consultar el historial completo de un estudiante.

---

### 🔴 DÍA 4: Lambdas, Stream API, Facturación DIAN en PDF y Logs
* **Meta:** Cumplir los requisitos más técnicos y avanzados de la rúbrica.

* **Tareas - Santiago (Procesamiento con Stream API y Lambdas):**
  1. Promedios automáticos usando Streams:
     * Promedio por materia de un estudiante (`mapToDouble`, `average`).
     * Promedio general del estudiante en el período.
     * Promedio general del curso en cada materia.
  2. Reporte de inasistencias preocupantes con Streams: Estudiantes con más de 3 ausencias en la semana (`filter`, `collect`).
  3. Reporte de morosos: Estudiantes con pagos pendientes de más de un mes.
  4. Integración de `LoggerHelper.logError(...)` en todos los controladores.

* **Tareas - Compañero (Facturación Electrónica DIAN y Manejo de Archivos):**
  1. Servicio de generación de Factura Electrónica:
     * Formato visual que cumpla normativa DIAN (Razón social, NIT, Acudiente, Conceptos, Subtotal, IVA, Total).
     * Generación de **CUFE simulado** (algoritmo SHA-256 a partir de número de factura + NIT + fecha).
     * Generación de **código QR simulado**.
     * Exportación en archivo PDF guardado en la carpeta `/invoices/factura_XXXX.pdf`.
     * Registro automático en la tabla `facturas`.
  2. Submenú de generación e impresión de facturas desde consola.

* **Hito de Verificación Día 4:**
  * Realizar un pago y ver cómo se genera físicamente el archivo PDF en `/invoices/` con su CUFE.
  * Consultar reportes estadísticos y verificar que los promedios y filtros usan Stream API.
  * Forzar un error controlado y comprobar que se escribió en `error_log.txt`.

---

### 🟣 DÍA 5: Integración Final, README Exhaustivo y Ensayo de Sustentación
* **Meta:** Asegurar los 49 puntos de dominio de código y dejar la entrega lista.

* **Tareas - Compañero:**
  1. Redactar el `README.md` final con las **16 secciones obligatorias**.
  2. Documentar los ejemplos de código para cada principio SOLID y patrón de diseño.
  3. Verificar que todas las rutas relativas funcionen en cualquier máquina.

* **Tareas - Santiago:**
  1. Pruebas de caja negra: Ejecutar el proyecto en **Apache NetBeans** y en **IntelliJ IDEA** desde cero.
  2. Verificar que las entradas inválidas en consola muestren mensajes amigables y no rompan la aplicación.
  3. Verificar que el script `database.sql` corra limpio en una base de datos vacía.

* **Actividad Conjunta (Simulación de Sustentación - 49 Puntos):**
  * Preguntarse mutuamente:
    * *¿Por qué `DatabaseConnection` es Singleton y cómo evita fugas de conexiones?*
    * *¿Dónde y por qué aplicamos el principio de Inversión de Dependencias (DIP)?*
    * *¿Cómo funciona el `PreparedStatement` para prevenir inyección SQL?*
    * *¿Explica este pipeline de Stream API para calcular los promedios?*
  * Hacer el último commit en la rama `main` y guardar el **Commit Hash SHA** para la entrega.
