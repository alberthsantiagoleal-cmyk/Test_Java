package com.littlehorizons.erp.model.dao;

import com.littlehorizons.erp.model.entity.StudentLoan;
import java.time.LocalDate;
import java.util.List;

/**
 * Data Access Object interface for Student resource loans.
 * Maps to 'prestamos_estudiante' table.
 */
public interface IStudentLoanDAO {

    void create(StudentLoan loan);

    StudentLoan findById(int idLoan);

    List<StudentLoan> findActiveLoans();

    List<StudentLoan> findByStudentId(int idStudent);

    void registerReturn(int idLoan, LocalDate returnDate);

    List<StudentLoan> findAll();
}
