package com.littlehorizons.erp.service.billing;

/**
 * Strategy representing a 15% discount policy for families with multiple siblings enrolled.
 */
public class SiblingDiscountStrategy implements FeeCalculationStrategy {

    private static final double DISCOUNT_PERCENTAGE = 15.0;

    @Override
    public double calculateFee(double baseAmount) {
        double discounted = baseAmount * (1.0 - (DISCOUNT_PERCENTAGE / 100.0));
        return Math.max(0.0, discounted);
    }

    @Override
    public String getStrategyName() {
        return "Descuento por Hermanos (15%)";
    }

    @Override
    public double getDiscountPercentage() {
        return DISCOUNT_PERCENTAGE;
    }
}
