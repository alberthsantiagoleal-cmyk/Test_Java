package com.littlehorizons.erp.service.invoice;

import com.littlehorizons.erp.model.dao.IGuardianDAO;
import com.littlehorizons.erp.model.dao.IInvoiceDAO;
import com.littlehorizons.erp.model.dao.IPaymentConceptDAO;
import com.littlehorizons.erp.model.dao.IPaymentDAO;
import com.littlehorizons.erp.model.dao.IStudentDAO;
import com.littlehorizons.erp.model.dao.impl.GuardianDAOImpl;
import com.littlehorizons.erp.model.dao.impl.InvoiceDAOImpl;
import com.littlehorizons.erp.model.dao.impl.PaymentConceptDAOImpl;
import com.littlehorizons.erp.model.dao.impl.PaymentDAOImpl;
import com.littlehorizons.erp.model.dao.impl.StudentDAOImpl;
import com.littlehorizons.erp.model.entity.*;
import com.littlehorizons.erp.util.LoggerHelper;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * Service orchestrating Electronic Invoicing generation, CUFE hashing,
 * and DIAN-compliant PDF file creation.
 */
public class ElectronicInvoiceService {

    private final IInvoiceDAO invoiceDAO;
    private final IPaymentDAO paymentDAO;
    private final IPaymentConceptDAO conceptDAO;
    private final IStudentDAO studentDAO;
    private final IGuardianDAO guardianDAO;

    public ElectronicInvoiceService() {
        this(new InvoiceDAOImpl(), new PaymentDAOImpl(), new PaymentConceptDAOImpl(),
             new StudentDAOImpl(), new GuardianDAOImpl());
    }

    public ElectronicInvoiceService(IInvoiceDAO invoiceDAO, IPaymentDAO paymentDAO,
                                    IPaymentConceptDAO conceptDAO, IStudentDAO studentDAO,
                                    IGuardianDAO guardianDAO) {
        this.invoiceDAO = invoiceDAO;
        this.paymentDAO = paymentDAO;
        this.conceptDAO = conceptDAO;
        this.studentDAO = studentDAO;
        this.guardianDAO = guardianDAO;
    }

    /**
     * Emits a DIAN Electronic Invoice for a confirmed payment, generates its PDF,
     * calculates the CUFE hash, and records the invoice into the database.
     *
     * @param paymentId ID of the payment being invoiced
     * @return Generated Invoice entity
     */
    public Invoice generateInvoiceForPayment(int paymentId) {
        Payment payment = paymentDAO.findById(paymentId);
        if (payment == null) {
            throw new IllegalArgumentException("No se encontro un pago con ID: " + paymentId);
        }

        // Check if an invoice was already issued for this payment
        Invoice existingInvoice = invoiceDAO.findByPaymentId(paymentId);
        if (existingInvoice != null) {
            File existingFile = new File(existingInvoice.getFilePath());
            if (!existingFile.exists()) {
                // Re-render PDF if missing
                renderInvoicePdf(existingInvoice, payment);
            }
            return existingInvoice;
        }

        // Generate consecutive invoice number (e.g. FE-000001)
        int invoiceCount = invoiceDAO.countInvoices();
        String invoiceNumber = String.format("FE-%06d", invoiceCount + 1);

        LocalDate issueDate = LocalDate.now();
        String cufe = CufeGenerator.generateCufe(invoiceNumber, issueDate, payment.getAmountPaid(), payment.getIdStudent());
        String pdfFileName = "factura_" + invoiceNumber + ".pdf";
        String filePath = "invoices" + File.separator + pdfFileName;

        Invoice invoice = new Invoice(null, invoiceNumber, paymentId, issueDate, cufe, pdfFileName, filePath);

        // Generate PDF physical file
        renderInvoicePdf(invoice, payment);

        // Persist to database
        invoiceDAO.create(invoice);
        return invoice;
    }

    /**
     * Re-renders the PDF for an existing invoice.
     */
    public void renderInvoicePdf(Invoice invoice, Payment payment) {
        Student student = studentDAO.findById(payment.getIdStudent());
        Guardian guardian = payment.getIdGuardian() != null ? guardianDAO.findById(payment.getIdGuardian()) : null;
        PaymentConcept concept = conceptDAO.findById(payment.getIdConcept());

        PdfInvoiceGenerator.InvoiceData data = new PdfInvoiceGenerator.InvoiceData();
        data.invoiceNumber = invoice.getInvoiceNumber();
        data.issueDate = invoice.getIssueDate() != null ? invoice.getIssueDate().toString() : LocalDate.now().toString();
        data.receiptNumber = payment.getReceiptNumber();

        if (student != null) {
            data.studentName = student.getFullName();
            data.studentDocument = student.getDocumentType() + " " + student.getDocumentNumber();
        } else {
            data.studentName = "Estudiante ID #" + payment.getIdStudent();
            data.studentDocument = "N/A";
        }

        if (guardian != null) {
            data.guardianName = guardian.getFullName();
            data.guardianDocument = guardian.getDocumentType() + " " + guardian.getDocumentNumber();
        } else {
            data.guardianName = data.studentName;
            data.guardianDocument = data.studentDocument;
        }

        if (concept != null) {
            data.conceptCode = concept.getConceptCode();
            data.conceptName = concept.getConceptName();
            data.baseAmount = concept.getBaseAmount();
        } else {
            data.conceptCode = "SRV";
            data.conceptName = "Concepto de Pago ID #" + payment.getIdConcept();
            data.baseAmount = payment.getAmountPaid();
        }

        data.totalPaid = payment.getAmountPaid();
        data.discountAmount = Math.max(0.0, data.baseAmount - data.totalPaid);
        data.academicPeriod = payment.getAcademicPeriod();
        data.academicYear = payment.getAcademicYear() != null ? payment.getAcademicYear() : LocalDate.now().getYear();
        data.paymentMethod = payment.getPaymentMethod();
        data.notes = payment.getNotes();
        data.cufe = invoice.getCufe();

        File targetFile = new File(invoice.getFilePath());
        try {
            PdfInvoiceGenerator.generatePdf(data, targetFile);
        } catch (IOException e) {
            LoggerHelper.logError("Error rendering invoice PDF for " + invoice.getInvoiceNumber() + ": " + e.getMessage(), e);
            throw new RuntimeException("Error al generar el archivo fisico PDF de la factura: " + e.getMessage(), e);
        }
    }

    public List<Invoice> getAllInvoices() {
        return invoiceDAO.findAll();
    }

    public Invoice getInvoiceById(int idInvoice) {
        return invoiceDAO.findById(idInvoice);
    }

    public Invoice getInvoiceByPaymentId(int idPayment) {
        return invoiceDAO.findByPaymentId(idPayment);
    }
}
