package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

/**
 * Domain entity representing a student's membership in an extracurricular club.
 * Maps to MySQL table 'membresias_club'.
 */
public class ClubMembership {

    private Integer idMembership;
    private int idStudent;
    private int idClub;
    private LocalDate enrollmentDate;
    private String membershipStatus; // 'Activa', 'Retirada'
    private LocalDate withdrawalDate;
    private String withdrawalReason;

    // Descriptive attributes from SQL joins
    private String studentName;
    private String studentDocument;
    private String clubName;

    public ClubMembership() {
        this.enrollmentDate = LocalDate.now();
        this.membershipStatus = "Activa";
    }

    public ClubMembership(Integer idMembership, int idStudent, int idClub, LocalDate enrollmentDate,
                          String membershipStatus, LocalDate withdrawalDate, String withdrawalReason) {
        this.idMembership = idMembership;
        this.idStudent = idStudent;
        this.idClub = idClub;
        this.enrollmentDate = enrollmentDate != null ? enrollmentDate : LocalDate.now();
        this.membershipStatus = membershipStatus != null ? membershipStatus : "Activa";
        this.withdrawalDate = withdrawalDate;
        this.withdrawalReason = withdrawalReason;
    }

    public Integer getIdMembership() {
        return idMembership;
    }

    public void setIdMembership(Integer idMembership) {
        this.idMembership = idMembership;
    }

    public int getIdStudent() {
        return idStudent;
    }

    public void setIdStudent(int idStudent) {
        this.idStudent = idStudent;
    }

    public int getIdClub() {
        return idClub;
    }

    public void setIdClub(int idClub) {
        this.idClub = idClub;
    }

    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(LocalDate enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }

    public String getMembershipStatus() {
        return membershipStatus;
    }

    public void setMembershipStatus(String membershipStatus) {
        this.membershipStatus = membershipStatus;
    }

    public LocalDate getWithdrawalDate() {
        return withdrawalDate;
    }

    public void setWithdrawalDate(LocalDate withdrawalDate) {
        this.withdrawalDate = withdrawalDate;
    }

    public String getWithdrawalReason() {
        return withdrawalReason;
    }

    public void setWithdrawalReason(String withdrawalReason) {
        this.withdrawalReason = withdrawalReason;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentDocument() {
        return studentDocument;
    }

    public void setStudentDocument(String studentDocument) {
        this.studentDocument = studentDocument;
    }

    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public boolean isActive() {
        return "Activa".equalsIgnoreCase(membershipStatus);
    }

    @Override
    public String toString() {
        return "ClubMembership{" +
                "idMembership=" + idMembership +
                ", idStudent=" + idStudent +
                ", studentName='" + studentName + '\'' +
                ", idClub=" + idClub +
                ", clubName='" + clubName + '\'' +
                ", enrollmentDate=" + enrollmentDate +
                ", status='" + membershipStatus + '\'' +
                '}';
    }
}
