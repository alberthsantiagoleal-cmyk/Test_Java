package com.littlehorizons.erp.model.dao.impl;

import com.littlehorizons.erp.model.dao.IStudentLoanDAO;
import com.littlehorizons.erp.model.entity.StudentLoan;
import com.littlehorizons.erp.util.DatabaseConnection;
import com.littlehorizons.erp.util.LoggerHelper;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC implementation of IStudentLoanDAO using PreparedStatements.
 */
public class StudentLoanDAOImpl implements IStudentLoanDAO {

    private static final String BASE_SELECT =
            "SELECT p.id_prestamo, p.id_recurso, p.id_estudiante, p.fecha_prestamo, " +
            "       p.fecha_devolucion_esperada, p.fecha_devolucion_real, p.estado_prestamo, p.observaciones, " +
            "       r.nombre_recurso, r.codigo_recurso, " +
            "       CONCAT(e.primer_nombre, ' ', e.primer_apellido) AS nombre_estudiante " +
            "FROM prestamos_estudiante p " +
            "LEFT JOIN recursos r ON p.id_recurso = r.id_recurso " +
            "LEFT JOIN estudiantes e ON p.id_estudiante = e.id_estudiante ";

    @Override
    public void create(StudentLoan loan) {
        String sql = "INSERT INTO prestamos_estudiante (id_recurso, id_estudiante, fecha_prestamo, " +
                     "fecha_devolucion_esperada, estado_prestamo, observaciones) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setInt(1, loan.getIdResource());
            pst.setInt(2, loan.getIdStudent());
            pst.setDate(3, Date.valueOf(loan.getLoanDate()));
            pst.setDate(4, Date.valueOf(loan.getExpectedReturnDate()));
            pst.setString(5, loan.getLoanStatus());
            pst.setString(6, loan.getObservations());

            pst.executeUpdate();

            try (ResultSet rs = pst.getGeneratedKeys()) {
                if (rs.next()) {
                    loan.setIdLoan(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in create student loan: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar el prestamo a estudiante.", e);
        }
    }

    @Override
    public StudentLoan findById(int idLoan) {
        String sql = BASE_SELECT + "WHERE p.id_prestamo = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idLoan);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToEntity(rs);
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findById student loan [" + idLoan + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al buscar prestamo de estudiante por ID.", e);
        }
        return null;
    }

    @Override
    public List<StudentLoan> findActiveLoans() {
        String sql = BASE_SELECT + "WHERE p.estado_prestamo = 'Activo' ORDER BY p.fecha_devolucion_esperada ASC";
        List<StudentLoan> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findActiveLoans student: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar prestamos activos de estudiantes.", e);
        }
        return list;
    }

    @Override
    public List<StudentLoan> findByStudentId(int idStudent) {
        String sql = BASE_SELECT + "WHERE p.id_estudiante = ? ORDER BY p.fecha_prestamo DESC";
        List<StudentLoan> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idStudent);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToEntity(rs));
                }
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findByStudentId [" + idStudent + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al consultar historial de prestamos del estudiante.", e);
        }
        return list;
    }

    @Override
    public void registerReturn(int idLoan, LocalDate returnDate) {
        String sql = "UPDATE prestamos_estudiante SET fecha_devolucion_real = ?, estado_prestamo = 'Devuelto' " +
                     "WHERE id_prestamo = ?";

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setDate(1, Date.valueOf(returnDate));
            pst.setInt(2, idLoan);
            pst.executeUpdate();
        } catch (SQLException e) {
            LoggerHelper.logError("Error in registerReturn student loan [" + idLoan + "]: " + e.getMessage(), e);
            throw new RuntimeException("Error al registrar la devolucion del recurso por estudiante.", e);
        }
    }

    @Override
    public List<StudentLoan> findAll() {
        String sql = BASE_SELECT + "ORDER BY p.id_prestamo ASC";
        List<StudentLoan> list = new ArrayList<>();

        Connection con = DatabaseConnection.getInstance();
        try (PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntity(rs));
            }
        } catch (SQLException e) {
            LoggerHelper.logError("Error in findAll student loans: " + e.getMessage(), e);
            throw new RuntimeException("Error al listar los prestamos a estudiantes.", e);
        }
        return list;
    }

    private StudentLoan mapResultSetToEntity(ResultSet rs) throws SQLException {
        Date actualRet = rs.getDate("fecha_devolucion_real");

        StudentLoan loan = new StudentLoan(
                rs.getInt("id_prestamo"),
                rs.getInt("id_recurso"),
                rs.getInt("id_estudiante"),
                rs.getDate("fecha_prestamo").toLocalDate(),
                rs.getDate("fecha_devolucion_esperada").toLocalDate(),
                actualRet != null ? actualRet.toLocalDate() : null,
                rs.getString("estado_prestamo"),
                rs.getString("observaciones")
        );

        loan.setResourceName(rs.getString("nombre_recurso"));
        loan.setResourceCode(rs.getString("codigo_recurso"));
        loan.setStudentName(rs.getString("nombre_estudiante"));
        return loan;
    }
}
