package com.littlehorizons.erp.view;

import com.littlehorizons.erp.controller.FinancialController;
import com.littlehorizons.erp.model.entity.Invoice;
import com.littlehorizons.erp.model.entity.Payment;
import com.littlehorizons.erp.model.entity.PaymentConcept;
import com.littlehorizons.erp.service.billing.*;
import com.littlehorizons.erp.util.ConsoleUI;
import com.littlehorizons.erp.util.ScannerHelper;

import java.io.File;
import java.util.List;

/**
 * Console view for the Financial Management and DIAN Electronic Invoicing module.
 * Provides user interaction for payments, catalog lookup, discount strategies,
 * and PDF electronic invoice generation with CUFE and simulated QR code.
 * Pure ASCII strings ensure compatibility across all IDEs and console encodings.
 */
public class FinancialView {

    private final FinancialController financialController;
    private final ScannerHelper sc;

    public FinancialView() {
        this.financialController = new FinancialController();
        this.sc = ScannerHelper.getInstance();
    }

    /**
     * Displays the financial submenu and handles user choices.
     */
    public void displayMenu() {
        int option = -1;

        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printMainHeader("MODULO DE GESTION FINANCIERA Y FACTURACION DIAN");

            System.out.println("  1. Consultar Catalogo de Conceptos de Pago");
            System.out.println("  2. Registrar Nuevo Pago (con Politicas de Descuento)");
            System.out.println("  3. Consultar Historial de Pagos por Estudiante");
            System.out.println("  4. Consultar Historial de Pagos por Acudiente (Familia)");
            System.out.println("  5. Listar Todos los Pagos Registrados");
            System.out.println("  6. Facturacion Electronica DIAN (Emision / Consulta PDF)");
            System.out.println("  0. Regresar al Menu Principal");
            ConsoleUI.printDivider();

            option = sc.readInt("Seleccione una opcion", 0, 6);

            switch (option) {
                case 1 -> listPaymentConcepts();
                case 2 -> registerNewPayment();
                case 3 -> viewPaymentsByStudent();
                case 4 -> viewPaymentsByGuardian();
                case 5 -> viewAllPayments();
                case 6 -> manageElectronicInvoices();
                case 0 -> System.out.println("\nRegresando al menu principal...");
            }
        }
    }

    private void listPaymentConcepts() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Catalogo de Conceptos de Cobro");

        try {
            List<PaymentConcept> concepts = financialController.getActivePaymentConcepts();
            if (concepts.isEmpty()) {
                System.out.println("[INFO] No hay conceptos de pago activos registrados en el catalogo.");
            } else {
                System.out.printf("%-6s | %-12s | %-25s | %-14s | %-10s%n",
                        "ID", "CODIGO", "CONCEPTO", "VALOR BASE", "RECURRENTE");
                ConsoleUI.printDivider();
                for (PaymentConcept c : concepts) {
                    System.out.printf("%-6d | %-12s | %-25s | $%,12.2f | %-10s%n",
                            c.getIdConcept(), c.getConceptCode(), c.getConceptName(),
                            c.getBaseAmount(), c.isRecurring() ? "Si (Mensual)" : "No (Unico)");
                }
            }
        } catch (Exception e) {
            ConsoleUI.printError("No se pudo conectar a la base de datos o consultar los conceptos: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void registerNewPayment() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Registro de Nuevo Pago Educativo");

        try {
            List<PaymentConcept> concepts = financialController.getActivePaymentConcepts();
            if (concepts.isEmpty()) {
                ConsoleUI.printError("No existen conceptos de pago en la base de datos. Por favor cargue el catalogo primero.");
                sc.pressEnterToContinue();
                return;
            }

            System.out.println("Conceptos disponibles:");
            for (PaymentConcept c : concepts) {
                System.out.printf("  [%d] %s ($%,.2f)%n", c.getIdConcept(), c.getConceptName(), c.getBaseAmount());
            }
            ConsoleUI.printDivider();

            int conceptId = sc.readInt("Seleccione el ID del concepto a pagar");
            PaymentConcept selectedConcept = financialController.getConceptById(conceptId);

            int studentId = sc.readInt("Ingrese el ID del estudiante");

            System.out.println("El pago lo realiza el acudiente registrado? (1: Si, 2: Mismo estudiante / directo)");
            int whoPays = sc.readInt("Opcion", 1, 2);
            Integer guardianId = null;
            if (whoPays == 1) {
                guardianId = sc.readInt("Ingrese el ID del acudiente");
            }

            // Select Discount Strategy (Patron Strategy en accion)
            FeeCalculationStrategy strategy = selectDiscountStrategy();
            double finalAmount = financialController.calculateAdjustedAmount(selectedConcept.getBaseAmount(), strategy);

            System.out.printf("\n[RESUMEN] Resumen de Liquidacion:%n");
            System.out.printf("   Monto Base: $%,12.2f%n", selectedConcept.getBaseAmount());
            System.out.printf("   Estrategia: %s%n", strategy.getStrategyName());
            System.out.printf("   TOTAL A PAGAR: $%,12.2f%n%n", finalAmount);

            System.out.println("Metodos de Pago:");
            System.out.println("  1. Efectivo");
            System.out.println("  2. Transferencia");
            System.out.println("  3. Tarjeta Debito");
            System.out.println("  4. Tarjeta Credito");
            System.out.println("  5. Cheque");
            int methodOption = sc.readInt("Seleccione metodo de pago", 1, 5);
            String[] methods = {"Efectivo", "Transferencia", "Tarjeta Debito", "Tarjeta Credito", "Cheque"};
            String paymentMethod = methods[methodOption - 1];

            int year = sc.readInt("Ano Academico (ej: 2026)", 2020, 2030);

            System.out.println("Periodo Academico: 1: I, 2: II, 3: III, 4: IV, 5: Anual");
            int periodOpt = sc.readInt("Seleccione periodo", 1, 5);
            String[] periods = {"I", "II", "III", "IV", "Anual"};
            String period = periods[periodOpt - 1];

            String notes = sc.readOptionalString("Notas adicionales o justificacion");

            Payment created = financialController.processPayment(
                    studentId, guardianId, conceptId, finalAmount,
                    paymentMethod, year, period,
                    notes.isEmpty() ? strategy.getStrategyName() : (strategy.getStrategyName() + " | " + notes)
            );

            ConsoleUI.printSuccess("Pago registrado exitosamente!");
            System.out.println("   ID Pago:          " + created.getIdPayment());
            System.out.println("   Numero de Recibo: " + created.getReceiptNumber());
            System.out.println("   Monto Cobrado:    $" + String.format("%,.2f", created.getAmountPaid()));
            System.out.println("   Fecha de Pago:    " + created.getPaymentDate());

            // Immediate DIAN Electronic Invoice emission option
            System.out.println("\n-------------------------------------------------------------");
            String genInvoice = sc.readString("Desea generar la Factura Electronica DIAN en PDF? (S/N)");
            if (genInvoice.trim().equalsIgnoreCase("S")) {
                try {
                    Invoice inv = financialController.emitElectronicInvoice(created.getIdPayment());
                    ConsoleUI.printSuccess("Factura Electronica DIAN generada exitosamente!");
                    System.out.println("   Factura No.:     " + inv.getInvoiceNumber());
                    System.out.println("   CUFE:            " + inv.getCufe());
                    System.out.println("   Archivo PDF:     " + inv.getFilePath());
                } catch (Exception ex) {
                    ConsoleUI.printError("Error al generar la factura electronica: " + ex.getMessage());
                }
            }

        } catch (Exception e) {
            ConsoleUI.printError("Error al procesar el pago: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private FeeCalculationStrategy selectDiscountStrategy() {
        System.out.println("\nSeleccione la Politica de Cobro / Descuento (Patron Strategy):");
        System.out.println("  1. Tarifa Regular (100% tarifa plena)");
        System.out.println("  2. Descuento por Hermanos (15% de descuento)");
        System.out.println("  3. Beca Academica Parcial (50% de descuento)");
        System.out.println("  4. Ajuste Especial Personalizado (%)");
        
        int opt = sc.readInt("Seleccione opcion de liquidacion", 1, 4);
        return switch (opt) {
            case 2 -> new SiblingDiscountStrategy();
            case 3 -> new ScholarshipDiscountStrategy();
            case 4 -> {
                double pct = sc.readDouble("Ingrese el porcentaje de descuento a aplicar (0.0 a 100.0)", 0.0, 100.0);
                String reason = sc.readString("Ingrese el motivo del ajuste especial");
                yield new CustomDiscountStrategy(pct, reason);
            }
            default -> new RegularFeeStrategy();
        };
    }

    private void viewPaymentsByStudent() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Historial de Pagos por Estudiante");

        int studentId = sc.readInt("Ingrese el ID del estudiante");
        try {
            List<Payment> payments = financialController.getPaymentsByStudent(studentId);
            displayPaymentsList(payments, "el estudiante ID: " + studentId);
        } catch (Exception e) {
            ConsoleUI.printError("Error al consultar pagos del estudiante: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void viewPaymentsByGuardian() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Historial de Pagos por Acudiente (Familiar)");

        int guardianId = sc.readInt("Ingrese el ID del acudiente");
        try {
            List<Payment> payments = financialController.getPaymentsByGuardian(guardianId);
            displayPaymentsList(payments, "el acudiente ID: " + guardianId);
        } catch (Exception e) {
            ConsoleUI.printError("Error al consultar pagos del acudiente: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void viewAllPayments() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("Registro General de Todos los Pagos");

        try {
            List<Payment> payments = financialController.getAllPayments();
            displayPaymentsList(payments, "la institucion");
        } catch (Exception e) {
            ConsoleUI.printError("Error al consultar los pagos: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    // ==========================================
    // DIAN ELECTRONIC INVOICING SUBMENU
    // ==========================================

    private void manageElectronicInvoices() {
        int option = -1;

        while (option != 0) {
            ConsoleUI.clearScreen();
            ConsoleUI.printSectionHeader("FACTURACION ELECTRONICA DIAN (PDF, CUFE & QR)");

            System.out.println("  1. Consultar Facturas Electronicas Emitidas");
            System.out.println("  2. Emitir Factura Electronica para un Pago Registrado");
            System.out.println("  3. Consultar Detalle y CUFE de una Factura");
            System.out.println("  4. Regenerar / Verificar Archivo PDF");
            System.out.println("  0. Regresar al Menu Financiero");
            ConsoleUI.printDivider();

            option = sc.readInt("Seleccione una opcion", 0, 4);

            switch (option) {
                case 1 -> listAllInvoices();
                case 2 -> emitInvoiceForExistingPayment();
                case 3 -> viewInvoiceDetails();
                case 4 -> verifyOrRegeneratePdf();
                case 0 -> System.out.println("\nRegresando...");
            }
        }
    }

    public void listAllInvoices() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("FACTURAS ELECTRONICAS EMITIDAS");

        try {
            List<Invoice> invoices = financialController.getAllInvoices();
            if (invoices.isEmpty()) {
                System.out.println("\n[INFO] No se han emitido facturas electronicas en el sistema.");
            } else {
                System.out.println(String.format("\n%-5s %-12s %-8s %-12s %-28s %-10s",
                        "ID", "No. Factura", "ID Pago", "F. Emision", "Archivo PDF", "Existe PDF"));
                System.out.println("-".repeat(85));

                for (Invoice inv : invoices) {
                    boolean fileExists = inv.getFilePath() != null && new File(inv.getFilePath()).exists();
                    String status = fileExists ? "Si (OK)" : "No (Falta)";
                    System.out.println(String.format("%-5d %-12s %-8d %-12s %-28s %-10s",
                            inv.getIdInvoice(),
                            inv.getInvoiceNumber(),
                            inv.getIdPayment(),
                            inv.getIssueDate(),
                            truncate(inv.getPdfFileName(), 27),
                            status));
                }
            }
        } catch (Exception e) {
            ConsoleUI.printError("Error al consultar las facturas: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void emitInvoiceForExistingPayment() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("EMISION DE FACTURA ELECTRONICA PARA UN PAGO");

        try {
            int paymentId = sc.readInt("Ingrese el ID del pago registrado", 1, 99999);
            Invoice inv = financialController.emitElectronicInvoice(paymentId);

            ConsoleUI.printSuccess("Factura emitida exitosamente!");
            System.out.println("   Factura No.: " + inv.getInvoiceNumber());
            System.out.println("   Fecha:       " + inv.getIssueDate());
            System.out.println("   CUFE:        " + inv.getCufe());
            System.out.println("   Ruta PDF:    " + inv.getFilePath());

        } catch (Exception e) {
            ConsoleUI.printError("No se pudo emitir la factura electronica: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void viewInvoiceDetails() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("CONSULTA DE DETALLE Y CUFE DE FACTURA");

        try {
            int invoiceId = sc.readInt("Ingrese el ID de la factura a consultar", 1, 99999);
            Invoice inv = financialController.getInvoiceById(invoiceId);

            if (inv == null) {
                System.out.println("\n[ERROR] No se encontro ninguna factura con ID: " + invoiceId);
            } else {
                System.out.println("\n============================================================");
                System.out.println("            COLEGIO LITTLE HORIZONS - FACTURA DIAN          ");
                System.out.println("============================================================");
                System.out.println("   ID Factura:         " + inv.getIdInvoice());
                System.out.println("   Numero Consecutivo: " + inv.getInvoiceNumber());
                System.out.println("   ID Pago Asociado:   " + inv.getIdPayment());
                System.out.println("   Fecha de Emision:   " + inv.getIssueDate());
                System.out.println("   Archivo PDF:        " + inv.getPdfFileName());
                System.out.println("   Ruta en Disco:      " + inv.getFilePath());
                System.out.println("   CUFE (SHA-256):     " + inv.getCufe());
                System.out.println("============================================================");

                File f = new File(inv.getFilePath());
                if (f.exists()) {
                    System.out.println("   [OK] El archivo fisico PDF existe en disco (" + f.length() + " bytes).");
                } else {
                    System.out.println("   [!] El archivo fisico no existe en disco. Utilice la opcion 4 para regenerarlo.");
                }
            }

        } catch (Exception e) {
            ConsoleUI.printError("Error al consultar la factura: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void verifyOrRegeneratePdf() {
        ConsoleUI.clearScreen();
        ConsoleUI.printSectionHeader("VERIFICAR O REGENERAR ARCHIVO PDF");

        try {
            int invoiceId = sc.readInt("Ingrese el ID de la factura", 1, 99999);
            Invoice inv = financialController.getInvoiceById(invoiceId);

            if (inv == null) {
                System.out.println("\n[ERROR] No se encontro la factura.");
            } else {
                Invoice refreshed = financialController.emitElectronicInvoice(inv.getIdPayment());
                File f = new File(refreshed.getFilePath());
                ConsoleUI.printSuccess("Archivo PDF verificado y sincronizado correctamente!");
                System.out.println("   Ruta:   " + f.getAbsolutePath());
                System.out.println("   Tamano: " + f.length() + " bytes");
            }
        } catch (Exception e) {
            ConsoleUI.printError("Error al regenerar el archivo PDF: " + e.getMessage());
        }

        sc.pressEnterToContinue();
    }

    private void displayPaymentsList(List<Payment> payments, String context) {
        if (payments.isEmpty()) {
            System.out.println("[INFO] No se encontraron registros de pagos para " + context + ".");
            return;
        }

        System.out.printf("%-6s | %-14s | %-10s | %-18s | %-20s | %-12s | %-15s%n",
                "ID", "RECIBO", "FECHA", "ESTUDIANTE", "CONCEPTO", "MONTO", "METODO");
        ConsoleUI.printDivider();
        for (Payment p : payments) {
            String student = (p.getStudentName() != null && !p.getStudentName().isBlank()) 
                    ? p.getStudentName() 
                    : ("ID: " + p.getIdStudent());
            String concept = (p.getConceptName() != null && !p.getConceptName().isBlank()) 
                    ? p.getConceptName() 
                    : ("ID: " + p.getIdConcept());

            System.out.printf("%-6d | %-14s | %-10s | %-18s | %-20s | $%,10.2f | %-15s%n",
                    p.getIdPayment(),
                    p.getReceiptNumber(), p.getPaymentDate(),
                    truncate(student, 18), truncate(concept, 20),
                    p.getAmountPaid(), p.getPaymentMethod());
        }
        System.out.printf("%nTotal de pagos registrados: %d%n", payments.size());
    }

    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        return text.length() <= maxLength ? text : text.substring(0, maxLength - 3) + "...";
    }
}
