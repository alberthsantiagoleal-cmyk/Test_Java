package com.littlehorizons.erp.model.entity;

import java.time.LocalDate;

public class Attendance {
    private Integer idAttendance;
    private int studentId;
    private int subjectId;
    private LocalDate attendanceDate;
    private String status;
    private String observations;
    private Integer registeredBy;

    public Attendance() {
    }

    public Integer getIdAttendance() { return idAttendance; }
    public void setIdAttendance(Integer idAttendance) { this.idAttendance = idAttendance; }
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public int getSubjectId() { return subjectId; }
    public void setSubjectId(int subjectId) { this.subjectId = subjectId; }
    public LocalDate getAttendanceDate() { return attendanceDate; }
    public void setAttendanceDate(LocalDate attendanceDate) { this.attendanceDate = attendanceDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getObservations() { return observations; }
    public void setObservations(String observations) { this.observations = observations; }
    public Integer getRegisteredBy() { return registeredBy; }
    public void setRegisteredBy(Integer registeredBy) { this.registeredBy = registeredBy; }
}
